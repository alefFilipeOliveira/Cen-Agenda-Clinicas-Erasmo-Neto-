<?php
declare(strict_types=1);
/**
 * E-mail da Cen Agenda: cliente SMTP mínimo (sem bibliotecas) e envio dos lembretes de eventos.
 * Configuração no .env (CEN_AGENDA_SMTP_*). Segurança: auto = usa STARTTLS se o servidor oferecer.
 */

function mail_cfg(): array {
    return [
        'host' => app_env('CEN_AGENDA_SMTP_HOST', ''),
        'port' => (int)app_env('CEN_AGENDA_SMTP_PORT', '587'),
        'secure' => strtolower(app_env('CEN_AGENDA_SMTP_SECURE', 'auto')), // auto | none | ssl
        'verify' => env_bool(app_env('CEN_AGENDA_SMTP_TLS_VERIFY', 'false'), false),
        'user' => app_env('CEN_AGENDA_SMTP_USER', ''),
        'pass' => app_env('CEN_AGENDA_SMTP_PASS', ''),
        'from' => app_env('CEN_AGENDA_SMTP_FROM', app_env('CEN_AGENDA_SMTP_USER', '')),
        'name' => app_env('CEN_AGENDA_SMTP_FROM_NAME', 'Cen Agenda'),
        'timeout' => 12,
    ];
}

function mail_configured(): bool {
    $c = mail_cfg();
    return $c['host'] !== '' && $c['from'] !== '';
}

/** Aceita texto ("a@x.com, b@y.com") ou lista; devolve só e-mails válidos, sem repetição. */
function parse_emails($v): array {
    $parts = is_array($v) ? $v : preg_split('/[\s,;]+/', (string)$v, -1, PREG_SPLIT_NO_EMPTY);
    $out = [];
    foreach ($parts as $p) {
        $p = strtolower(trim((string)$p));
        if (filter_var($p, FILTER_VALIDATE_EMAIL) && !in_array($p, $out, true)) $out[] = $p;
        if (count($out) >= 20) break;
    }
    return $out;
}

function smtp_read($fp): array {
    $text = '';
    while (($line = fgets($fp, 1024)) !== false) {
        $text .= $line;
        if (strlen($line) < 4 || $line[3] !== '-') break;
    }
    if ($text === '') throw new RuntimeException('O servidor de e-mail não respondeu (tempo esgotado).');
    return [(int)substr($text, 0, 3), $text];
}

function smtp_cmd($fp, string $cmd, array $ok): string {
    if ($cmd !== '') fwrite($fp, $cmd . "\r\n");
    [$code, $text] = smtp_read($fp);
    if (!in_array($code, $ok, true)) throw new RuntimeException('Servidor de e-mail recusou: ' . trim($text));
    return $text;
}

/**
 * Envia a mensagem tentando, em ordem, cada servidor de CEN_AGENDA_SMTP_HOST (separe vários com ";")
 * na porta configurada (STARTTLS) e, no modo auto, também na 465 com SSL. Para na primeira que funcionar.
 */
function smtp_send(array $to, string $subject, string $body): void {
    if (count($to) > 40) { foreach (array_chunk($to, 40) as $lote) smtp_send($lote, $subject, $body); return; } // limite de destinatários por mensagem
    $base = mail_cfg();
    $hosts = preg_split('/[;,\s]+/', $base['host'], -1, PREG_SPLIT_NO_EMPTY) ?: [];
    $tries = [];
    foreach ($hosts as $h) {
        $tries[] = [$h, $base['port'], $base['secure']];
        if ($base['secure'] === 'auto' && $base['port'] !== 465) $tries[] = [$h, 465, 'ssl'];
    }
    if (!$tries) throw new RuntimeException('E-mail não configurado: preencha CEN_AGENDA_SMTP_HOST e CEN_AGENDA_SMTP_FROM no .env.');
    $errors = [];
    foreach ($tries as [$h, $port, $secure]) {
        try {
            smtp_send_once(['host' => $h, 'port' => $port, 'secure' => $secure] + $base, $to, $subject, $body);
            return;
        } catch (RuntimeException $e) {
            $errors[] = "{$h}:{$port} (" . ($secure === 'ssl' ? 'SSL' : 'STARTTLS/auto') . ') → ' . $e->getMessage();
        }
    }
    throw new RuntimeException("Todas as tentativas falharam:\n" . implode("\n", $errors));
}

function smtp_send_once(array $c, array $to, string $subject, string $body): void {
    if (!mail_configured()) throw new RuntimeException('E-mail não configurado: preencha CEN_AGENDA_SMTP_HOST e CEN_AGENDA_SMTP_FROM no .env.');
    if (!$to) throw new RuntimeException('Nenhum destinatário válido.');
    $ssl = $c['secure'] === 'ssl' || ($c['secure'] === 'auto' && $c['port'] === 465);
    $ctx = stream_context_create(['ssl' => ['verify_peer' => $c['verify'], 'verify_peer_name' => $c['verify'], 'allow_self_signed' => !$c['verify']]]);
    $fp = @stream_socket_client(($ssl ? 'ssl://' : 'tcp://') . $c['host'] . ':' . $c['port'], $errno, $errstr, $c['timeout'], STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) throw new RuntimeException("Não foi possível conectar em {$c['host']}:{$c['port']} ({$errstr}).");
    stream_set_timeout($fp, $c['timeout']);
    try {
        $tlsOn = $ssl;
        smtp_cmd($fp, '', [220]);
        $me = gethostname() ?: 'cenagenda';
        $ehlo = smtp_cmd($fp, "EHLO {$me}", [250]);
        if (!$ssl && $c['secure'] !== 'none' && stripos($ehlo, 'STARTTLS') !== false) {
            smtp_cmd($fp, 'STARTTLS', [220]);
            if (!@stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new RuntimeException('Falha ao negociar TLS com o servidor de e-mail.');
            $ehlo = smtp_cmd($fp, "EHLO {$me}", [250]);
            $tlsOn = true;
        }
        if ($c['user'] !== '') {
            try { // alguns servidores só aceitam AUTH PLAIN; tenta LOGIN e depois PLAIN
                smtp_cmd($fp, 'AUTH LOGIN', [334]);
                smtp_cmd($fp, base64_encode($c['user']), [334]);
                smtp_cmd($fp, base64_encode($c['pass']), [235]);
            } catch (RuntimeException $e1) {
                try {
                    smtp_cmd($fp, 'AUTH PLAIN ' . base64_encode("\0{$c['user']}\0{$c['pass']}"), [235]);
                } catch (RuntimeException $e2) {
                    throw new RuntimeException($e2->getMessage() . " [usuário enviado: {$c['user']}; senha com " . strlen($c['pass']) . ' caracteres; conexão ' . ($tlsOn ? 'criptografada' : 'SEM criptografia') . ']');
                }
            }
        }
        smtp_cmd($fp, "MAIL FROM:<{$c['from']}>", [250]);
        foreach ($to as $r) smtp_cmd($fp, "RCPT TO:<{$r}>", [250, 251]);
        smtp_cmd($fp, 'DATA', [354]);
        $enc = fn(string $s) => '=?UTF-8?B?' . base64_encode($s) . '?=';
        $msg = 'From: ' . $enc($c['name']) . " <{$c['from']}>\r\n"
            . 'To: ' . $enc($c['name']) . " <{$c['from']}>\r\n" // os destinatários vão em cópia oculta
            . 'Subject: ' . $enc($subject) . "\r\n"
            . 'Date: ' . date('r') . "\r\n"
            . 'Message-ID: <' . bin2hex(random_bytes(8)) . '@cenagenda>' . "\r\n"
            . "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
            . chunk_split(base64_encode($body));
        fwrite($fp, $msg . "\r\n.\r\n");
        smtp_cmd($fp, '', [250]);
        @fwrite($fp, "QUIT\r\n");
    } finally {
        fclose($fp);
    }
}

/** E-mail real do usuário: o do cadastro/AD ou, se vazio, usuario@CEN_AGENDA_MAIL_DOMAIN para contas do AD. */
function user_mail(array $u): string {
    // 1) e-mail definido pelo administrador no painel (caixa de setor, ex.: juridico@...) — o AD não sobrescreve
    $man = strtolower(trim((string)($u['email_manual'] ?? '')));
    if ($man !== '' && filter_var($man, FILTER_VALIDATE_EMAIL)) return $man;
    // 2) e-mail vindo do AD; 3) usuário@domínio da clínica
    $m = strtolower(trim((string)($u['email'] ?? '')));
    if ($m !== '' && !str_ends_with($m, LOCAL_ACCOUNT_SUFFIX) && filter_var($m, FILTER_VALIDATE_EMAIL)) return $m;
    $d = strtolower(app_env('CEN_AGENDA_MAIL_DOMAIN', 'clinicaserasmoneto.com.br'));
    if (($u['source'] ?? '') === 'ldap' && $d !== '' && preg_match('/^[a-z0-9._-]+$/', (string)($u['username'] ?? ''))) return $u['username'] . '@' . $d;
    return '';
}

/** Criador + e-mails extras + grupo escolhido no evento ("*" = todos da clínica, ou um setor). */
function reminder_recipients(array $ev, array $usersByName): array {
    $list = parse_emails($ev['notify_emails'] ?? []);
    $creator = $usersByName[$ev['created_by'] ?? ''] ?? null;
    if ($creator && ($mail = user_mail($creator)) !== '') $list[] = $mail;
    $mode = (string)($ev['notify_mode'] ?? '');
    $group = (string)($ev['notify_group'] ?? ''); // formato antigo (v2.6)
    if ($mode === '' && $group !== '') $mode = $group === '*' ? 'all' : 'sector';
    if (in_array($mode, ['all', 'sector', 'people'], true)) {
        $pick = array_flip(array_map('strtolower', (array)($ev['notify_users'] ?? [])));
        $no = array_flip(array_map(fn($d) => strtolower((string)($d['username'] ?? '')), (array)($ev['declined'] ?? []))); // quem negou não recebe mais
        foreach ($usersByName as $u) {
            if (empty($u['active']) || !empty($u['ad_disabled'])) continue;
            if (isset($no[strtolower((string)($u['username'] ?? ''))])) continue;
            if ($mode === 'sector' && (string)($u['sector'] ?? '') !== $group) continue;
            if ($mode === 'people' && !isset($pick[strtolower((string)($u['username'] ?? ''))])) continue;
            if (($mail = user_mail($u)) !== '') $list[] = $mail;
        }
    }
    return array_values(array_unique($list));
}

/** Aviso imediato de "novo evento" para o grupo/e-mails escolhidos (só quando há alguém indicado). */
function announce_event(array $ev): void {
    if (!mail_configured() || (!in_array($ev['notify_mode'] ?? '', ['all', 'people'], true) && ($ev['notify_group'] ?? '') === '' && empty($ev['notify_emails']))) return;
    $users = [];
    foreach (json_read()['users'] ?? [] as $u) $users[$u['username']] = $u;
    $to = reminder_recipients($ev, $users);
    if (!$to) return;
    $start = new DateTimeImmutable($ev['start']);
    $end = new DateTimeImmutable($ev['end']);
    $body = "Novo evento na agenda\n\n" . $ev['title'] . "\n"
        . 'Data: ' . $start->format('d/m/Y') . "\n"
        . 'Horário: ' . $start->format('H:i') . ' às ' . $end->format('H:i') . "\n"
        . (($ev['location'] ?? '') !== '' ? 'Unidade: ' . $ev['location'] . "\n" : '')
        . (($ev['description'] ?? '') !== '' ? "\n" . $ev['description'] . "\n" : '')
        . "\nCriado por: " . ($ev['created_by_name'] ?? $ev['created_by'] ?? '') . "\n\n— Cen Agenda";
    smtp_send($to, 'Novo evento: ' . $ev['title'] . ' (' . $start->format('d/m H:i') . ')', $body);
}

/** Enfileira o aviso imediato para o worker enviar sem bloquear a gravação do evento. */
function queue_event_announcement(array $ev): void {
    $file = dirname(DATA_FILE) . DIRECTORY_SEPARATOR . 'emails_pendentes.json';
    $queue = is_file($file) ? (json_decode((string)file_get_contents($file), true) ?: []) : [];
    $queue[] = ['event' => $ev, 'queued_at' => time()];
    file_put_contents($file, json_encode(array_slice($queue, -500), JSON_UNESCAPED_UNICODE), LOCK_EX);
}

/** Processa avisos imediatos pendentes; chamado continuamente pelo worker. */
function process_queued_announcements(): array {
    if (!mail_configured()) return ['sent' => 0, 'errors' => []];
    $file = dirname(DATA_FILE) . DIRECTORY_SEPARATOR . 'emails_pendentes.json';
    if (!is_file($file)) return ['sent' => 0, 'errors' => []];
    $fp = @fopen($file, 'c+'); if (!$fp) return ['sent' => 0, 'errors' => ['Não foi possível abrir a fila de e-mails.']];
    if (!flock($fp, LOCK_EX)) { fclose($fp); return ['sent' => 0, 'errors' => []]; }
    $raw = stream_get_contents($fp); $queue = json_decode($raw ?: '[]', true) ?: [];
    ftruncate($fp, 0); rewind($fp); fwrite($fp, '[]'); fflush($fp); flock($fp, LOCK_UN); fclose($fp);
    $sent = 0; $errors = []; $retry = [];
    foreach ($queue as $item) {
        try { if (!empty($item['event']) && mail_configured()) announce_event($item['event']); $sent++; }
        catch (Throwable $e) { $errors[] = $e->getMessage(); $retry[] = $item; }
    }
    if ($retry) { $old = is_file($file) ? (json_decode((string)file_get_contents($file), true) ?: []) : []; file_put_contents($file, json_encode(array_slice(array_merge($retry, $old), -500), JSON_UNESCAPED_UNICODE), LOCK_EX); }
    return ['sent' => $sent, 'errors' => $errors];
}

/** Envia os lembretes que entraram na janela. Rodar a cada minuto (Agendador de Tarefas). */
function send_due_reminders(): array {
    $store = json_read();
    $now = new DateTimeImmutable('now');
    $file = dirname(DATA_FILE) . DIRECTORY_SEPARATOR . 'lembretes_enviados.json';
    $sent = is_file($file) ? (json_decode((string)file_get_contents($file), true) ?: []) : [];
    $users = [];
    foreach ($store['users'] ?? [] as $u) $users[$u['username']] = $u;
    $count = 0;
    $errors = [];
    foreach ($store['events'] ?? [] as $ev) {
        $mins = (int)($ev['reminder_minutes'] ?? 0);
        if ($mins <= 0) continue;
        $to = reminder_recipients($ev, $users);
        if (!$to) continue;
        foreach (event_occurrences($ev, $now, $now->modify("+{$mins} minutes")) as $oc) {
            $start = new DateTimeImmutable($oc['occurrence_start']);
            $key = ($ev['id'] ?? '') . '|' . $oc['occurrence_start'];
            if ($start <= $now || isset($sent[$key])) continue;
            $end = new DateTimeImmutable($oc['occurrence_end']);
            $body = "Lembrete de evento\n\n" . $ev['title'] . "\n"
                . 'Data: ' . $start->format('d/m/Y') . "\n"
                . 'Horário: ' . $start->format('H:i') . ' às ' . $end->format('H:i') . "\n"
                . (($ev['location'] ?? '') !== '' ? 'Unidade: ' . $ev['location'] . "\n" : '')
                . (($ev['description'] ?? '') !== '' ? "\n" . $ev['description'] . "\n" : '')
                . "\n— Cen Agenda";
            try {
                smtp_send($to, 'Lembrete: ' . $ev['title'] . ' às ' . $start->format('H:i'), $body);
                $sent[$key] = time();
                $count++;
            } catch (Throwable $e) {
                $errors[] = $ev['title'] . ': ' . $e->getMessage();
            }
        }
    }
    $sent = array_filter($sent, fn($t) => $t > time() - 3 * 86400); // limpa o histórico antigo
    file_put_contents($file, json_encode($sent), LOCK_EX);
    return ['sent' => $count, 'errors' => $errors];
}

/** "07/10/2026 · 09:00–10:00 · NACEN" */
function event_when(array $e): string {
    $s = new DateTimeImmutable($e['start']);
    $f = new DateTimeImmutable($e['end']);
    return $s->format('d/m/Y') . ' · ' . $s->format('H:i') . '–' . $f->format('H:i') . (($e['location'] ?? '') !== '' ? ' · ' . $e['location'] : '');
}

/** Quem recebia o aviso antes ou passa a receber agora, menos quem fez a alteração. */
function change_recipients(array $before, array $after, array $actor): array {
    $users = [];
    foreach (json_read()['users'] ?? [] as $u) $users[$u['username']] = $u;
    $to = array_merge(reminder_recipients($before, $users), reminder_recipients($after, $users));
    $self = user_mail($actor);
    return array_values(array_filter(array_unique($to), fn($mail) => $mail !== $self));
}

function announce_change(array $before, array $after, array $actor): void {
    if (!mail_configured()) return;
    $changed = false;
    foreach (['title', 'start', 'end', 'location', 'recurrence'] as $k) {
        if (($before[$k] ?? null) != ($after[$k] ?? null)) { $changed = true; break; }
    }
    if (!$changed) return;
    $to = change_recipients($before, $after, $actor);
    if (!$to) return;
    $body = "Um evento da agenda foi alterado\n\n" . $after['title'] . "\n\n"
        . 'Antes: ' . event_when($before) . "\n"
        . 'Agora: ' . event_when($after) . "\n\n"
        . 'Alterado por: ' . ($actor['name'] ?? $actor['username'] ?? '') . "\n\n— Cen Agenda";
    smtp_send($to, 'Evento alterado: ' . $after['title'], $body);
}

/** Avisa quem criou o evento que alguém o negou. */
function announce_decline(array $ev, array $by): void {
    if (!mail_configured()) return;
    $owner = null;
    foreach (json_read()['users'] ?? [] as $u) {
        if (strtolower((string)($u['username'] ?? '')) === strtolower((string)($ev['created_by'] ?? ''))) { $owner = $u; break; }
    }
    $to = $owner ? user_mail($owner) : '';
    if ($to === '') return;
    $who = (string)($by['name'] ?? $by['username'] ?? '');
    $body = $who . " negou um evento seu na agenda\n\n" . $ev['title'] . "\n\n"
        . 'Era em: ' . event_when($ev) . "\n\n"
        . 'Esse evento deixou de aparecer na agenda de ' . $who . ".\n\n— Cen Agenda";
    smtp_send([$to], 'Evento negado por ' . $who . ': ' . $ev['title'], $body);
}

function announce_cancel(array $ev, array $actor): void {
    if (!mail_configured()) return;
    $to = change_recipients($ev, $ev, $actor);
    if (!$to) return;
    $body = "Um evento da agenda foi cancelado\n\n" . $ev['title'] . "\n\n"
        . 'Era em: ' . event_when($ev) . "\n"
        . 'Cancelado por: ' . ($actor['name'] ?? $actor['username'] ?? '') . "\n\n— Cen Agenda";
    smtp_send($to, 'Evento cancelado: ' . $ev['title'], $body);
}
