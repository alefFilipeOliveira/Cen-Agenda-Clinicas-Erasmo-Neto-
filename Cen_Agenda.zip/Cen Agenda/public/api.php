<?php
declare(strict_types=1);
require_once __DIR__ . '/../api_routes.php';
start_app_session();
handle_api_request();
