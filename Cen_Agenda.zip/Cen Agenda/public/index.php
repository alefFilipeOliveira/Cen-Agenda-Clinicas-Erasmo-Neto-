<?php
declare(strict_types=1);
require_once __DIR__ . '/../backend.php';
start_app_session();
send_security_headers();
header('Cache-Control: no-store');
run_migrations();
$s = json_read();
$user = current_user();
$csrf = csrf_token();
$ldapCfg = ldap_cfg();
$ldapProblem = $ldapCfg['enabled'] && !ldap_extension_loaded();
?><!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cen Agenda</title>
<meta name="theme-color" content="#20beda">
<link rel="icon" href="/assets/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/assets/logo-cen.png?v=4">
<link rel="stylesheet" href="/assets/style.css?v=<?= APP_VERSION ?>">
</head>
<body>
<div id="app" class="app" data-authenticated="<?= $user ? '1':'0' ?>">
  <?php if (!$user): ?>
  <main class="login-wrap"><div class="login-split">
    <section class="login-brand">
      <div class="login-logo-bg"><img class="login-logo" src="/assets/logo-cen.png?v=4" alt="Clínica Erasmo Neto, NACEN e NACEN+"></div>
      <h2>Cen Agenda</h2>
      <p>Reuniões, eventos e acontecimentos de todas as unidades em um só lugar.</p>
      <ul class="login-points"><li>Erasmo</li><li>NACEN</li><li>NACEN+</li></ul>
    </section>
    <section class="login-card">
      <div class="eyebrow">Acesso</div>
      <h1>Bem-vindo de volta</h1>
      <p class="login-subtitle">Entre com seu usuário e senha.</p>
      <?php if ($ldapProblem): ?><div class="notice warn">O login pelo Active Directory está indisponível neste servidor (extensão LDAP do PHP não habilitada). Avise o TI ou use a conta local de emergência.</div><?php endif; ?>
      <form id="loginForm" class="login-form">
        <label>Usuário<input id="loginUser" autocomplete="username" placeholder="usuário do domínio" required></label>
        <label>Senha<input id="loginPass" type="password" autocomplete="current-password" placeholder="••••••••" required></label>
        <button class="btn primary full" type="submit">Entrar</button>
        <div id="loginError" class="form-error" role="alert"></div>
      </form>
      <div class="login-foot">Agenda De Organizações Erasmo Neto</div>
    </section>
  </div></main>
  <?php else: ?>
  <?php $initialLetter = function_exists('mb_substr') ? mb_substr((string)$user['name'], 0, 1, 'UTF-8') : substr((string)$user['name'], 0, 1); ?>
  <div class="shell">
    <aside class="sidebar">
      <div class="sidebar-brand"><img class="brand-logo" src="/assets/logo-cen.png?v=4" alt="Clínica Erasmo Neto, NACEN e NACEN+"><div class="brand-text"><strong>Cen Agenda</strong><small>Calendário corporativo</small></div><img class="brand-icon" src="/assets/favicon.svg" alt="Cen Agenda"></div>
      <nav class="nav">
        <button class="nav-item active" data-view="dashboard"><span class="ico">🏠</span><span>Início</span></button>
        <button class="nav-item" data-view="calendar"><span class="ico">🗓️</span><span>Calendário</span></button>
        <button class="nav-item" data-view="events"><span class="ico">🗂️</span><span>Eventos</span></button>
        <?php if (($user['profile']??'user')==='admin'): ?><button class="nav-item" data-view="settings"><span class="ico">👑</span><span>Painel</span></button><?php endif; ?>
      </nav>
      <div class="sidebar-user"><div class="avatar"><?= strtoupper($initialLetter) ?></div><div class="u-text"><strong><?= htmlspecialchars((string)$user['name'], ENT_QUOTES, 'UTF-8') ?></strong><small><?= ($user['profile']??'user')==='admin'?'Administrador':'Usuário' ?></small></div><button data-logout class="logout-btn" title="Sair" aria-label="Sair"><span>↪</span><span class="logout-text">Sair</span></button></div>
    </aside>
    <main class="content">
      <header class="topbar">
        <div><div class="eyebrow">CEN AGENDA</div><h2 id="pageTitle">Início</h2></div>
        <div class="top-actions"><div class="status" title="Online"><span class="status-dot"></span><span id="ldapStatusText" class="sr-only">Sessão ativa</span></div><button id="newEventBtn" class="btn primary">＋ Novo evento</button><button data-logout class="btn secondary only-mobile">Sair</button><div class="avatar large"><?= strtoupper($initialLetter) ?></div></div>
      </header>

      <section id="view-dashboard" class="view active">
        <div class="hero"><div><span class="pill">Hoje</span><h3>Seu calendário em um só lugar.</h3><p>Veja o que acontece hoje e acompanhe os próximos acontecimentos da empresa.</p></div><button class="btn secondary" data-action="go-calendar">Abrir calendário</button></div>
        <div class="stats"><div class="stat-card"><small>Hoje</small><strong id="statToday">0</strong><span>acontecimentos</span></div><div class="stat-card"><small>Próximos</small><strong id="statUpcoming">0</strong><span>já programados</span></div><div class="stat-card"><small>Total</small><strong id="statTotal">0</strong><span>eventos cadastrados</span></div></div>
        <div class="dashboard-grid"><div class="panel"><div class="panel-head"><div><small>AGENDA DE HOJE</small><h3 id="todayLabel">Hoje</h3></div><button class="link-btn" data-action="go-calendar">Ver calendário →</button></div><div id="todayList" class="timeline"></div></div><div class="panel"><div class="panel-head"><div><small>PRÓXIMOS</small><h3>Próximos eventos</h3></div></div><div id="upcomingList" class="mini-list"></div></div></div>
      </section>

      <section id="view-calendar" class="view">
        <div class="calendar-toolbar"><div class="toolbar-left"><button class="icon-btn" id="prevBtn" aria-label="Anterior">‹</button><button class="icon-btn" id="nextBtn" aria-label="Próximo">›</button><button class="btn secondary" id="todayBtn">Hoje</button><div class="date-pick"><button type="button" id="calendarTitle" class="title-btn" aria-haspopup="true" aria-expanded="false" title="Escolher mês e ano"></button>
        <div id="datePicker" class="date-picker hidden" role="dialog" aria-label="Escolher mês e ano"><div class="dp-year"><button type="button" class="icon-btn" id="dpPrev" aria-label="Ano anterior">‹</button><input type="number" id="dpYear" min="1970" max="2100" aria-label="Ano"><button type="button" class="icon-btn" id="dpNext" aria-label="Próximo ano">›</button></div><div class="dp-months" id="dpMonths"></div></div></div><select id="unitFilter" class="unit-filter" aria-label="Filtrar por unidade"></select></div><div class="view-switch"><button class="switch active" data-calview="month">Mês</button><button class="switch" data-calview="week">Semana</button><button class="switch" data-calview="day">Dia</button></div></div>
        <div class="calendar-card"><div id="calendar"></div></div>
      </section>

      <section id="view-events" class="view"><div class="section-header"><div><div class="eyebrow">CONSULTA</div><h3>Eventos</h3><p>Pesquise e visualize acontecimentos cadastrados.</p></div><div class="search"><input id="eventSearch" placeholder="Pesquisar evento, unidade ou descrição…"></div></div><div class="panel table-wrap"><table><thead><tr><th>Evento</th><th>Data</th><th>Horário</th><th>Unidade</th><th></th></tr></thead><tbody id="eventsTable"></tbody></table></div></section>

      <?php if (($user['profile']??'user')==='admin'): ?><section id="view-settings" class="view"><div class="section-header"><div><div class="eyebrow">ADMINISTRAÇÃO</div><h3>Configurações</h3><p>Personalize o calendário e a integração com o ambiente corporativo.</p></div></div><div class="settings-grid"><div class="panel setting-card"><h4>Calendário</h4><label>Primeiro dia da semana<select id="setFirstDay"><option value="1">Segunda-feira</option><option value="0">Domingo</option></select></label><label class="check"><input type="checkbox" id="setHolidays"> Mostrar feriados no calendário</label><label>Duração padrão (minutos)<input id="setDuration" type="number" min="5" max="480"></label><label>Lembrete padrão (minutos)<input id="setReminder" type="number" min="0" max="10080"></label><label>Grade inicia às<input id="setTimeStart" type="number" min="0" max="23"></label><label>Grade termina às<input id="setTimeEnd" type="number" min="1" max="23"></label><label class="check"><input id="setNotifications" type="checkbox"> Avisos de lembrete quando o sistema estiver aberto</label></div><div class="panel setting-card"><h4>Unidades</h4><div id="unitsChips" class="chips"></div><div class="add-row"><input id="unitsInput" maxlength="60" placeholder="Nova unidade…"><button type="button" class="btn secondary" id="unitsAdd">Adicionar</button></div><div class="form-note">Clique em “Salvar configurações” para aplicar.</div></div><div class="panel setting-card"><h4>Setores</h4><p class="form-note">Valem só para a agenda: nada muda no Active Directory. Excluir remove a pasta e deixa as pessoas “Sem setor”.</p><div id="sectorsManage" class="sector-manage"></div><div class="add-row"><input id="sectorsInput" maxlength="60" placeholder="Novo setor…"><button type="button" class="btn secondary" id="sectorsAdd">Adicionar</button></div></div><div class="panel setting-card"><h4>Alertas por e-mail</h4><p class="form-note">O servidor de e-mail (SMTP) é configurado no arquivo .env. Use o teste para validar a conexão.</p><label>Enviar teste para<input id="mailTestTo" type="email" placeholder="seu@clinicaserasmoneto.com.br"></label><div class="setting-actions"><button type="button" class="btn secondary" id="mailTestBtn">Enviar e-mail de teste</button></div><div class="form-note" id="mailTestMsg" role="status"></div></div><div class="panel setting-card backup-card"><h4>Backups</h4><p class="form-note">Todo dia o sistema salva sozinho uma cópia de tudo (eventos, pessoas e configurações), guardada por 30 dias. Cada backup é uma página que você abre no navegador para conferir o que foi salvo. “Restaurar” volta tudo para aquela data.</p><div id="backupList" class="backup-list"></div><div class="setting-actions"><button type="button" class="btn secondary" id="backupNow">Fazer backup agora</button><label class="btn secondary file-btn">Restaurar de um arquivo…<input type="file" id="backupFile" accept=".html,.json" hidden></label></div></div><div class="panel setting-card ldap-card"><h4>Active Directory / LDAP</h4><div id="ldapDetails" class="ldap-details"></div><div class="setting-actions"><button class="btn secondary" id="ldapTest">Testar conexão</button><button class="btn primary" id="ldapSync">Sincronizar usuários</button></div><div id="ldapResult" class="form-note"></div></div><div class="savebar"><span id="settingsSaved"></span><button class="btn primary" id="saveSettings">Salvar configurações</button></div></div>
        <div class="panel users-panel"><div class="panel-head"><div><small>ACESSO</small><h3>Usuários</h3></div><div class="head-actions"><div class="search"><input id="userSearch" placeholder="Buscar usuário…"></div><button type="button" class="btn primary" id="newUserBtn">＋ Novo usuário</button></div></div><div id="usersGroups"></div><div class="form-note users-note">Os setores são definidos aqui, localmente: o AD só traz os usuários. O perfil de quem entra pelo AD acompanha o grupo de administradores até você alterá-lo aqui; depois disso o AD não muda mais. Contas desativadas não conseguem entrar.</div></div></section><?php endif; ?>
    <?php if (($user['profile']??'user')==='admin'): ?><div id="userModal" class="modal hidden" role="dialog" aria-modal="true"><div class="backdrop" data-close-user="1"></div><div class="modal-card narrow"><div class="modal-head"><div><div class="eyebrow">ACESSO</div><h3>Novo usuário local</h3></div><button type="button" class="icon-btn" data-close-user="1" aria-label="Fechar">×</button></div><p class="form-note">Conta local, independente do AD. A pessoa define a própria senha no primeiro acesso.</p><form id="userForm" class="login-form"><label>Nome<input id="nuName" required maxlength="200"></label><label>Usuário<input id="nuUser" required maxlength="120" placeholder="ex.: maria"></label><label>Senha provisória<input id="nuPass" type="password" minlength="8" required autocomplete="new-password"></label><label>Perfil<select id="nuProfile"><option value="user">Usuário</option><option value="admin">Administrador</option></select></label><label>Setor<select id="nuSector"></select></label><div id="nuError" class="form-error"></div><button class="btn primary full" type="submit">Criar usuário</button></form></div></div><?php endif; ?>
    </main>
  </div>
  <div id="eventModal" class="modal hidden" role="dialog" aria-modal="true" aria-labelledby="modalTitle"><div class="backdrop" data-close="1"></div><div class="modal-card"><div class="modal-head"><div><div class="eyebrow" id="modalEyebrow">NOVO EVENTO</div><h3 id="modalTitle">Novo evento</h3></div><button type="button" class="icon-btn" data-close="1" aria-label="Fechar">×</button></div><form id="eventForm"><input type="hidden" id="eventId"><div class="form-grid"><label class="wide">Nome do evento<input id="eventName" required maxlength="200" placeholder="Ex.: Reunião Geral"></label><label>Data<input id="eventDate" type="date" required></label><label>Cor<input id="eventColor" type="color" required></label><label>Início<input id="eventStart" type="time" required></label><label>Fim<input id="eventEnd" type="time" required></label><label class="wide">Unidade<select id="eventLocation"></select></label><label class="wide">Quem participa<select id="eventNotifyMode"><option value="me">Só eu (fica só na minha agenda)</option><option value="people">Pessoas que eu escolher</option><option value="all">Todos da clínica</option></select><small class="form-note">Quem for escolhido vê o evento na própria agenda e recebe por e-mail.</small></label><div id="declinedNote" class="wide declined-note hidden"></div><div id="notifyPicker" class="wide notify-picker hidden"><input id="notifySearch" placeholder="Buscar pessoa ou setor para mencionar…" autocomplete="off"><div class="picker-actions"><button type="button" class="link-btn" id="notifyAll">Selecionar todos</button><button type="button" class="link-btn" id="notifyNone">Limpar</button><span id="notifyCount" class="form-note"></span></div><div id="notifyList" class="notify-list"></div></div><label class="wide">Descrição<textarea id="eventDescription" rows="4" maxlength="5000" placeholder="Detalhes do acontecimento…"></textarea></label><label>Lembrete<select id="eventReminder"><option value="0">Sem lembrete</option><option value="5">5 minutos antes</option><option value="10">10 minutos antes</option><option value="15">15 minutos antes</option><option value="30">30 minutos antes</option><option value="60">1 hora antes</option><option value="1440">1 dia antes</option></select></label><label>Repetição<select id="eventRecurrence"><option value="none">Não repetir</option><option value="monthly">Todo mês</option><option value="yearly">Todo ano</option></select></label><input id="eventInterval" type="hidden" value="1"><input id="eventUntil" type="hidden"></div><div class="form-error" id="eventError"></div><div class="modal-actions"><button type="button" class="btn ghost" data-close="1">Cancelar</button><span class="spacer"></span><button type="button" class="btn danger hidden" id="deleteEventBtn">Excluir</button><button type="button" class="btn danger hidden" id="declineEventBtn" title="Tira este evento da sua agenda e avisa quem criou">Negar</button><button type="button" class="btn secondary hidden" id="duplicateEventBtn">Duplicar</button><button class="btn primary" type="submit" id="saveEventBtn">Salvar evento</button></div></form></div></div>
  <div id="busyOverlay" class="busy-overlay hidden" role="status" aria-live="polite"><div class="busy-card"><div class="spinner" aria-hidden="true"><span></span></div><strong id="busyText">Salvando…</strong><small id="busyHint"></small><div class="busy-progress"><div id="busyProgressBar"></div></div><div class="busy-progress-meta"><span>Processando</span><b id="busyProgressValue">0%</b></div></div></div>
  <?php if (!empty($user['must_change_password'])): ?>
  <div id="pwModal" class="modal"><div class="backdrop"></div><div class="modal-card narrow"><div class="modal-head"><div><div class="eyebrow">SEGURANÇA</div><h3>Defina uma nova senha</h3></div></div><p class="form-note">Esta conta usa uma senha provisória. Escolha uma nova senha (mínimo de 8 caracteres) para continuar.</p><form id="pwForm" class="login-form"><label>Senha atual<input id="pwCurrent" type="password" autocomplete="current-password" required></label><label>Nova senha<input id="pwNew" type="password" autocomplete="new-password" minlength="8" required></label><label>Confirmar nova senha<input id="pwConfirm" type="password" autocomplete="new-password" minlength="8" required></label><div id="pwError" class="form-error"></div><button class="btn primary full" type="submit">Salvar nova senha</button></form></div></div>
  <?php endif; ?>
  <div id="toast" class="toast" role="status" aria-live="polite"></div>
  <?php endif; ?>
</div>
<script>window.CEN_AGENDA={csrf:<?= json_encode($csrf) ?>,user:<?= json_encode($user,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP) ?>,initialSettings:<?= json_encode($s['settings'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP) ?>};</script>
<script src="/assets/app.js?v=<?= APP_VERSION ?>"></script>
</body></html>
