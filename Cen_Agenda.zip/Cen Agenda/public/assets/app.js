/* Cen Agenda — app.js
   Seções: utilidades · API · tema · login · navegação · início · calendário · eventos · atalhos · admin · lembretes */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const user = window.CEN_AGENDA?.user || null;
  let settings = window.CEN_AGENDA?.initialSettings || {};
  const admin = user?.profile === 'admin';
  const canEdit = e => admin || (!!e?.created_by && e.created_by === user?.username);
  const WEEKDAYS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
  const wdClass = i => i === 6 ? ' sat' : i === 0 ? ' sun' : ''; // sábado azul, domingo vermelho
  const MONTHS = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
  const HOUR_PX = 64;
  const VIEWS = { dashboard: 'Início', calendar: 'Calendário', events: 'Eventos', settings: 'Configurações' };

  const store = { get: (k, d) => { try { return localStorage.getItem('cen.' + k) ?? d; } catch { return d; } }, set: (k, v) => { try { localStorage.setItem('cen.' + k, v); } catch { /* sem storage */ } } };
  let dragBlock = false; // evita abrir o evento ao soltar um arrasto
  let unitFilter = store.get('unit', '');
  const visibleEvents = () => unitFilter ? events.filter(e => (e.location || '') === unitFilter) : events;
  let currentView = 'dashboard', calView = ['month', 'week', 'day'].includes(store.get('view', 'month')) ? store.get('view', 'month') : 'month', events = [], editingId = null, reqSeq = 0;
  let cursor = startOfDay(new Date());
  let listEvents = [], lastFocus = null, modalReadOnly = false, directory = null, notifySel = new Set();
  const known = new Map(); // id -> evento (para abrir o formulário vindo do início, calendário ou lista)
  const remember = list => (list || []).forEach(x => known.set(x.id, x));
  const cache = new Map(); // "from|to" -> eventos (invalidado ao salvar/excluir)

  /* ---------- Utilidades ---------- */
  function startOfDay(d) { const x = new Date(d); x.setHours(0, 0, 0, 0); return x; }
  const pad = n => String(n).padStart(2, '0');
  const ymd = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parseYmd = s => new Date(s + 'T00:00');
  const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
  const dateOf = e => (e.occurrence_start || e.start || '').slice(0, 10);
  const timeOf = e => (e.occurrence_start || e.start || '').slice(11, 16);
  const endOf = e => (e.occurrence_end || e.end || '').slice(11, 16);
  const minutes = t => parseInt(t.slice(0, 2), 10) * 60 + parseInt(t.slice(3, 5), 10);
  const esc = s => String(s ?? '').replace(/[&<>'"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[c]));
  const fmt = (d, o) => new Intl.DateTimeFormat('pt-BR', o).format(typeof d === 'string' ? parseYmd(d.slice(0, 10)) : d);
  const debounce = (fn, ms = 180) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
  function weekStart(d) { const diff = (d.getDay() - Number(settings.first_day ?? 1) + 7) % 7; return addDays(startOfDay(d), -diff); }
  function plusMinutes(t, n) { const x = Math.min(1439, minutes(t) + n); return `${pad(Math.floor(x / 60))}:${pad(x % 60)}`; }

  /* ---------- Feriados (nacionais, Bahia e Salvador; datas móveis calculadas, sem internet) ---------- */
  const holidayCache = {};
  function easter(y) { // algoritmo de Meeus/Jones/Butcher
    const a = y % 19, b = Math.floor(y / 100), c = y % 100, d = Math.floor(b / 4), e = b % 4, f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30, i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451), mo = Math.floor((h + l - 7 * m + 114) / 31), da = ((h + l - 7 * m + 114) % 31) + 1;
    return new Date(y, mo - 1, da);
  }
  function holidaysOf(y) {
    if (holidayCache[y]) return holidayCache[y];
    const map = {}, add = (d, name, optional = false) => { map[ymd(d)] = { name, optional }; };
    [['01-01', 'Confraternização Universal'], ['04-21', 'Tiradentes'], ['05-01', 'Dia do Trabalho'], ['07-02', 'Independência da Bahia'], ['09-07', 'Independência do Brasil'], ['10-12', 'N. Sra. Aparecida'], ['11-02', 'Finados'], ['11-15', 'Proclamação da República'], ['11-20', 'Consciência Negra'], ['12-08', 'N. Sra. da Conceição da Praia'], ['12-25', 'Natal']].forEach(([md, n]) => add(new Date(`${y}-${md}T00:00`), n));
    const p = easter(y), off = n => addDays(p, n);
    add(off(-48), 'Carnaval', true); add(off(-47), 'Carnaval', true); add(off(-46), 'Quarta de Cinzas (até 14h)', true);
    add(off(-2), 'Sexta-feira Santa'); add(p, 'Páscoa', true); add(off(60), 'Corpus Christi', true);
    return holidayCache[y] = map;
  }
  const holidayOn = date => settings.show_holidays === false ? null : (holidaysOf(Number(String(date).slice(0, 4)))[String(date).slice(0, 10)] || null);

  /* ---------- API ---------- */
  async function api(route, options = {}) {
    const url = '/api.php?route=' + encodeURIComponent(route) + (options.query ? '&' + new URLSearchParams(options.query) : '');
    const cfg = { ...options, credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': window.CEN_AGENDA?.csrf || '', ...(options.headers || {}) } };
    delete cfg.query;
    let res, data;
    try { res = await fetch(url, cfg); } catch { throw new Error('Sem conexão com o servidor. Verifique a rede.'); }
    try { data = await res.json(); } catch { data = { ok: false, error: 'Resposta inválida do servidor.' }; }
    if (!res.ok || data.ok === false) {
      const err = new Error(data.error || data.message || 'Erro ao comunicar com o servidor.');
      err.status = res.status; err.data = data;
      if ((res.status === 419 || (res.status === 401 && user)) && !api._reloading) { api._reloading = true; setTimeout(() => location.reload(), 1300); }
      throw err;
    }
    return data;
  }

  function toast(message, error = false) {
    const el = $('#toast'); if (!el) return;
    el.textContent = message; el.className = 'toast show' + (error ? ' error' : '');
    clearTimeout(toast._t); toast._t = setTimeout(() => el.className = 'toast', 3200);
  }

  /* ---------- Tema ---------- */
  function setTheme() {
    document.documentElement.dataset.theme = settings.theme || 'light';
    if (settings.accent) document.documentElement.style.setProperty('--accent', settings.accent);
    if (settings.system_name) document.title = settings.system_name;
  }
  setTheme();
  navigator.serviceWorker?.getRegistrations().then(r => r.forEach(x => x.unregister())).catch(() => {}); // limpa o app instalável da v2.4
  if (user && $('#ldapStatusText')) { const t = user.source === 'ldap' ? 'Online · conta do domínio' : 'Online · conta local'; $('#ldapStatusText').textContent = t; $('.status')?.setAttribute('title', t); }

  /* ---------- Login ---------- */
  if (!user) {
    const form = $('#loginForm');
    $('#loginUser')?.focus();
    form?.addEventListener('submit', async e => {
      e.preventDefault();
      const err = $('#loginError'), btn = $('button', form);
      err.textContent = ''; btn.disabled = true; btn.textContent = 'Entrando…';
      try {
        await api('auth/login', { method: 'POST', body: JSON.stringify({ username: $('#loginUser').value.trim(), password: $('#loginPass').value }) });
        btn.textContent = 'Bem-vindo!'; location.reload();
      } catch (ex) { err.textContent = ex.message; btn.disabled = false; btn.textContent = 'Entrar'; $('#loginPass').select(); }
    });
    return;
  }

  function initPasswordModal() {
    const form = $('#pwForm'); if (!form) return;
    $('#pwCurrent')?.focus();
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const err = $('#pwError'), btn = $('button', form);
      err.textContent = ''; btn.disabled = true;
      try {
        await api('auth/change-password', { method: 'POST', body: JSON.stringify({ current: $('#pwCurrent').value, new: $('#pwNew').value, confirm: $('#pwConfirm').value }) });
        location.reload();
      } catch (ex) { err.textContent = ex.message; btn.disabled = false; }
    });
  }

  /* ---------- Navegação (com #hash, o botão Voltar funciona) ---------- */
  function navigate(view, { push = true } = {}) {
    if (!VIEWS[view] || (view === 'settings' && !admin)) view = 'dashboard';
    currentView = view;
    $$('.view').forEach(v => v.classList.toggle('active', v.id === 'view-' + view));
    $$('.nav-item').forEach(b => { const on = b.dataset.view === view; b.classList.toggle('active', on); on ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current'); });
    $('#pageTitle').textContent = VIEWS[view];
    if (push && location.hash !== '#' + view) history.pushState(null, '', '#' + view);
    ({ calendar: loadCalendar, events: loadEventsTable, dashboard: loadDashboard, settings: loadSettings })[view]?.();
  }
  $$('.nav-item').forEach(b => b.addEventListener('click', () => navigate(b.dataset.view)));
  $$('[data-action="go-calendar"]').forEach(b => b.addEventListener('click', () => navigate('calendar')));
  window.addEventListener('popstate', () => navigate(location.hash.slice(1) || 'dashboard', { push: false }));
  $$('[data-logout]').forEach(b => b.addEventListener('click', async () => { try { await api('auth/logout', { method: 'POST' }); } finally { location.reload(); } }));
  $('#newEventBtn')?.addEventListener('click', () => openEventModal());
  // Um único listener para qualquer evento clicável (funciona após cada re-render).
  document.addEventListener('click', e => { const b = e.target.closest('.event-link'); if (b && !dragBlock) openEventModal(b.dataset.id); });

  /* ---------- Início ---------- */
  const eventTimeline = e => `<button class="timeline-item event-link" data-id="${esc(e.id)}"><span class="time">${timeOf(e)}</span><span class="line" style="--event:${esc(e.color)}"></span><span class="tl-content"><strong>${esc(e.title)}</strong><small>${esc(e.location || 'Sem unidade')}</small></span></button>`;
  const eventMini = e => `<button class="mini-item event-link" data-id="${esc(e.id)}"><span class="mini-dot" style="background:${esc(e.color)}"></span><span><strong>${esc(e.title)}</strong><small>${fmt(dateOf(e), { weekday: 'short', day: '2-digit', month: 'short' })} · ${timeOf(e)}</small></span></button>`;
  async function loadDashboard() {
    const sk = '<div class="skeleton"></div>'.repeat(3);
    if (!$('#todayList').children.length) { $('#todayList').innerHTML = sk; $('#upcomingList').innerHTML = sk; }
    try {
      const d = await api('dashboard');
      remember(d.today_events); remember(d.upcoming);
      $('#statToday').textContent = d.today_events.length;
      $('#statUpcoming').textContent = d.upcoming.length;
      $('#statTotal').textContent = d.total_events;
      { const h = holidayOn(d.today); $('#todayLabel').textContent = fmt(d.today, { weekday: 'long', day: 'numeric', month: 'long' }) + (h ? ` · ${h.optional ? 'Ponto facultativo' : 'Feriado'}: ${h.name}` : ''); }
      $('#todayList').innerHTML = d.today_events.length ? d.today_events.map(eventTimeline).join('') : '<div class="empty">Nenhum acontecimento programado para hoje.</div>';
      $('#upcomingList').innerHTML = d.upcoming.length ? d.upcoming.map(eventMini).join('') : '<div class="empty">Nenhum próximo evento.</div>';
    } catch (e) { toast(e.message, true); }
  }

  /* ---------- Calendário ---------- */
  function calendarRange() {
    if (calView === 'month') return { from: ymd(new Date(cursor.getFullYear(), cursor.getMonth(), 1)), to: ymd(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0)) };
    if (calView === 'week') { const s = weekStart(cursor); return { from: ymd(s), to: ymd(addDays(s, 6)) }; }
    return { from: ymd(cursor), to: ymd(cursor) };
  }
  async function fetchRange(from, to) {
    const key = from + '|' + to;
    if (!cache.has(key)) cache.set(key, (await api('events/list', { query: { from, to } })).events || []);
    remember(cache.get(key));
    return cache.get(key);
  }
  function fillUnitFilter() {
    const sel = $('#unitFilter'); if (!sel) return;
    const opts = ['', ...(settings.units || [])]; if (unitFilter && !opts.includes(unitFilter)) unitFilter = '';
    sel.innerHTML = opts.map(u => `<option value="${esc(u)}">${u ? esc(u) : 'Todas as unidades'}</option>`).join(''); sel.value = unitFilter;
  }
  $('#unitFilter')?.addEventListener('change', e => { unitFilter = e.target.value; store.set('unit', unitFilter); renderCalendar(); });
  async function loadCalendar() {
    fillUnitFilter();
    const seq = ++reqSeq, { from, to } = calendarRange(), card = $('.calendar-card');
    card.classList.add('loading');
    try {
      const list = await fetchRange(from, to);
      if (seq !== reqSeq) return; // resposta antiga: o usuário já navegou
      events = list; renderCalendar();
    } catch (e) { if (seq === reqSeq) toast(e.message, true); }
    finally { if (seq === reqSeq) card.classList.remove('loading'); }
  }
  const invalidate = () => cache.clear();

  function weekTitle() {
    const s = weekStart(cursor), e = addDays(s, 6), m = d => MONTHS[d.getMonth()].slice(0, 3);
    return s.getMonth() === e.getMonth() ? `${s.getDate()}–${e.getDate()} de ${MONTHS[s.getMonth()]} de ${s.getFullYear()}` : `${s.getDate()} ${m(s)} – ${e.getDate()} ${m(e)} ${e.getFullYear()}`;
  }
  function renderCalendar() {
    $('#calendarTitle').textContent = calView === 'month' ? `${MONTHS[cursor.getMonth()]} ${cursor.getFullYear()}` : calView === 'week' ? weekTitle() : fmt(cursor, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    calView === 'month' ? renderMonth() : renderSchedule(calView === 'day');
  }
  const eventChip = e => `<button class="event-chip event-link"${canEdit(e) ? ' draggable="true"' : ''} data-occ="${dateOf(e)}" data-id="${esc(e.id)}" style="--event:${esc(e.color)}" title="${esc(e.title)}"><span class="event-chip-time">${timeOf(e)}</span><span class="event-chip-title">${esc(e.title)}</span></button>`;
  function renderMonth() {
    const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1), last = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0);
    const lead = (first.getDay() - Number(settings.first_day ?? 1) + 7) % 7, total = Math.ceil((lead + last.getDate()) / 7) * 7, today = ymd(new Date());
    const byDay = {}; visibleEvents().forEach(e => (byDay[dateOf(e)] ||= []).push(e));
    const heads = Array.from({ length: 7 }, (_, i) => `<div class="calendar-weekday${wdClass((Number(settings.first_day ?? 1) + i) % 7)}">${WEEKDAYS[(Number(settings.first_day ?? 1) + i) % 7]}</div>`).join('');
    let cells = '';
    for (let i = 0; i < total; i++) {
      const d = addDays(first, i - lead), date = ymd(d), list = byDay[date] || [];
      cells += `<div class="day-cell${wdClass(d.getDay())}${d.getMonth() !== cursor.getMonth() ? ' muted' : ''}${date < today ? ' is-past' : ''}${date === today ? ' today-cell' : ''}${holidayOn(date) ? ' is-holiday' : ''}" data-date="${date}"><button class="day-number" data-date="${date}" aria-label="Abrir ${fmt(d, { day: 'numeric', month: 'long' })}">${d.getDate()}</button>${holidayOn(date) ? `<span class="holiday-tag" title="${holidayOn(date).optional ? 'Ponto facultativo' : 'Feriado'}">${esc(holidayOn(date).name)}</span>` : ''}<div class="day-events">${list.slice(0, 3).map(eventChip).join('')}${list.length > 3 ? `<button class="more-events day-number-link" data-date="${date}">+${list.length - 3} mais</button>` : ''}</div></div>`;
    }
    $('#calendar').innerHTML = `<div class="calendar-head">${heads}</div><div class="month-grid">${cells}</div>`;
  }

  // Posiciona eventos que se sobrepõem lado a lado em vez de empilhados.
  function layoutDay(list) {
    const items = list.map(e => ({ e, s: minutes(timeOf(e)), f: Math.max(minutes(timeOf(e)) + 30, minutes(endOf(e) || timeOf(e))) })).sort((a, b) => a.s - b.s || b.f - a.f);
    let cluster = [], end = -1;
    const flush = () => { const n = Math.max(0, ...cluster.map(x => x.col + 1)); cluster.forEach(x => x.cols = n); cluster = []; };
    for (const it of items) {
      if (it.s >= end) { flush(); end = -1; }
      const used = new Set(cluster.filter(x => x.f > it.s).map(x => x.col));
      it.col = 0; while (used.has(it.col)) it.col++;
      cluster.push(it); end = Math.max(end, it.f);
    }
    flush(); return items;
  }
  function renderSchedule(single) {
    const start = single ? cursor : weekStart(cursor), n = single ? 1 : 7, days = Array.from({ length: n }, (_, i) => addDays(start, i));
    const h0 = Number(settings.time_start ?? 7), h1 = Number(settings.time_end ?? 20), today = ymd(new Date());
    const pxMin = HOUR_PX / 60, hours = Array.from({ length: h1 - h0 + 1 }, (_, i) => h0 + i);
    const head = days.map(d => `<div class="schedule-day-head${wdClass(d.getDay())}${ymd(d) === today ? ' is-today' : ''}"><small>${WEEKDAYS[d.getDay()]}</small><strong>${d.getDate()}</strong>${holidayOn(ymd(d)) ? `<em class="hd-name" title="${holidayOn(ymd(d)).name}">${esc(holidayOn(ymd(d)).name)}</em>` : ''}</div>`).join('');
    const labels = hours.map(h => `<div class="time-label">${pad(h)}:00</div>`).join('');
    const now = new Date(), nowTop = (now.getHours() * 60 + now.getMinutes() - h0 * 60) * pxMin;
    const cols = days.map(d => {
      const date = ymd(d), slots = hours.map(h => `<div class="slot" data-date="${date}" data-time="${pad(h)}:00"></div>`).join('');
      const evs = layoutDay(visibleEvents().filter(e => dateOf(e) === date)).map(({ e, s, f, col, cols }) => {
        const top = Math.max(0, (s - h0 * 60) * pxMin), height = Math.max(26, (f - s) * pxMin - 3);
        return `<button class="schedule-event event-link" data-id="${esc(e.id)}" style="top:${top + 1}px;height:${height}px;left:calc(${col / cols * 100}% + 3px);width:calc(${100 / cols}% - 6px);--event:${esc(e.color)}"><strong>${esc(e.title)}</strong><small>${timeOf(e)}–${endOf(e)}</small></button>`;
      }).join('');
      const line = date === today && nowTop >= 0 && nowTop <= hours.length * HOUR_PX ? `<div class="now-line" style="top:${nowTop}px"></div>` : '';
      return `<div class="schedule-col${date === today ? ' is-today' : ''}${holidayOn(date) ? ' is-holiday' : ''}" data-date="${date}">${slots}${evs}${line}</div>`;
    }).join('');
    $('#calendar').innerHTML = `<div class="schedule" style="--cols:${n};--minw:${single ? 420 : 880}px"><div class="schedule-header"><div></div>${head}</div><div class="schedule-body"><div class="time-column">${labels}</div>${cols}</div></div>`;
    const box = $('.schedule'); // abre já na hora atual (ou no primeiro evento)
    const vis = visibleEvents(), firstEv = vis.length ? Math.min(...vis.map(e => minutes(timeOf(e)))) : null;
    const focus = days.some(d => ymd(d) === today) ? nowTop - 80 : firstEv !== null ? (firstEv - h0 * 60) * pxMin - 40 : 0;
    box.scrollTop = Math.max(0, focus);
  }

  // Delegação: um listener cobre qualquer re-render do calendário.
  $('#calendar')?.addEventListener('click', e => {
    const n = e.target.closest('.day-number, .day-number-link');
    if (n) { cursor = parseYmd(n.dataset.date); setCalView('day'); }
  });
  $('#calendar')?.addEventListener('dblclick', e => {
    if (e.target.closest('.event-link')) return;
    const slot = e.target.closest('.slot'), cell = e.target.closest('.day-cell');
    if (slot) openEventModal(null, slot.dataset.date, slot.dataset.time); else if (cell) openEventModal(null, cell.dataset.date);
  });
  function setCalView(v) {
    calView = v; store.set('view', v);
    $$('.switch[data-calview]').forEach(b => { const on = b.dataset.calview === v; b.classList.toggle('active', on); b.setAttribute('aria-pressed', on); });
    loadCalendar();
  }
  function shift(dir) {
    if (calView === 'month') cursor = new Date(cursor.getFullYear(), cursor.getMonth() + dir, 1);
    else cursor = addDays(cursor, dir * (calView === 'week' ? 7 : 1));
    loadCalendar();
  }
  $('#prevBtn')?.addEventListener('click', () => shift(-1));
  $('#nextBtn')?.addEventListener('click', () => shift(1));
  $('#todayBtn')?.addEventListener('click', () => { cursor = startOfDay(new Date()); loadCalendar(); });
  $$('.switch[data-calview]').forEach(b => b.addEventListener('click', () => setCalView(b.dataset.calview)));

  /* ---------- Seletor de mês e ano (clique no título) ---------- */
  const picker = $('#datePicker'), titleBtn = $('#calendarTitle');
  let dpYr = cursor.getFullYear();
  function renderDp() {
    const now = new Date();
    $('#dpYear').value = dpYr;
    $('#dpMonths').innerHTML = MONTHS.map((m, i) => `<button type="button" class="dp-month${dpYr === cursor.getFullYear() && i === cursor.getMonth() ? ' current' : ''}${dpYr === now.getFullYear() && i === now.getMonth() ? ' today' : ''}" data-m="${i}">${m.slice(0, 3)}</button>`).join('');
  }
  function togglePicker(show = picker?.classList.contains('hidden')) {
    if (!picker) return;
    if (show) { dpYr = cursor.getFullYear(); renderDp(); }
    picker.classList.toggle('hidden', !show);
    titleBtn.setAttribute('aria-expanded', String(!!show));
  }
  titleBtn?.addEventListener('click', e => { e.stopPropagation(); togglePicker(); });
  $('#dpPrev')?.addEventListener('click', () => { dpYr--; renderDp(); });
  $('#dpNext')?.addEventListener('click', () => { dpYr++; renderDp(); });
  $('#dpYear')?.addEventListener('change', e => { const y = Number(e.target.value); if (y >= 1970 && y <= 2100) { dpYr = y; renderDp(); } else e.target.value = dpYr; });
  $('#dpMonths')?.addEventListener('click', e => { const b = e.target.closest('.dp-month'); if (!b) return; cursor = new Date(dpYr, Number(b.dataset.m), 1); togglePicker(false); loadCalendar(); });
  document.addEventListener('click', e => { if (picker && !picker.classList.contains('hidden') && !e.target.closest('.date-pick')) togglePicker(false); });
  const pkOpen = new Set(); // pastas abertas (começam todas fechadas)
  function renderPicker() {
    const q = $('#notifySearch').value.toLowerCase().trim(), groups = {}, dis = modalReadOnly ? 'disabled' : '';
    directory.filter(u => u.username !== user.username && `${u.name} ${u.username} ${u.sector || ''} ${u.coordinator ? 'coordenador coordenadora' : ''}`.toLowerCase().includes(q)).forEach(u => { (groups[u.sector || ''] ||= []).push(u); if (u.coordinator) (groups[COORD] ||= []).push(u); });
    const names = Object.keys(groups).sort((a, b) => a === COORD ? -1 : b === COORD ? 1 : !a ? 1 : !b ? -1 : a.localeCompare(b, 'pt-BR'));
    $('#notifyList').innerHTML = names.length ? names.map(n => {
      const g = groups[n], can = g.filter(pickable).length, on = g.filter(u => pickable(u) && notifySel.has(u.username)).length, open = !!q || pkOpen.has(n);
      const people = g.map(u => `<label class="pk-user"><input type="checkbox" class="pk-user-cb" value="${esc(u.username)}" ${notifySel.has(u.username) ? 'checked' : ''} ${dis || !u.has_mail ? 'disabled' : ''}><span>${esc(u.name)}</span><small>${esc(u.username)}${u.has_mail ? '' : ' · sem e-mail'}</small></label>`).join('');
      return `<div class="pk-group${open ? ' open' : ''}"><div class="pk-head"><input type="checkbox" class="pk-sector" data-s="${esc(n)}" ${can && on === can ? 'checked' : ''} ${dis || !can ? 'disabled' : ''} aria-label="Marcar o setor ${esc(n === COORD ? 'Coordenadores' : (n || 'Sem setor'))} inteiro"><button type="button" class="pk-fold" data-s="${esc(n)}" aria-expanded="${open}"><span class="pk-arrow">▸</span> 📁 ${n === COORD ? 'Coordenadores' : n ? esc(n) : 'Sem setor'} <span class="badge">${on}/${can}</span></button></div>${open ? `<div class="pk-body">${people}</div>` : ''}</div>`;
    }).join('') : '<div class="empty">Ninguém encontrado.</div>';
    $('#notifyCount').textContent = notifySel.size ? `${notifySel.size} selecionado(s)` : 'Ninguém selecionado';
  }
  $('#notifyList')?.addEventListener('click', e => { const f = e.target.closest('.pk-fold'); if (!f) return; const n = f.dataset.s; pkOpen.has(n) ? pkOpen.delete(n) : pkOpen.add(n); renderPicker(); });
  $('#eventNotifyMode')?.addEventListener('change', syncNotifyUI);
  $('#notifySearch')?.addEventListener('input', debounce(() => directory && renderPicker()));
  $('#notifyList')?.addEventListener('change', e => {
    if (e.target.matches('.pk-user-cb')) e.target.checked ? notifySel.add(e.target.value) : notifySel.delete(e.target.value);
    else if (e.target.matches('.pk-sector')) directory.filter(u => (e.target.dataset.s === COORD ? !!u.coordinator : (u.sector || '') === e.target.dataset.s) && pickable(u)).forEach(u => e.target.checked ? notifySel.add(u.username) : notifySel.delete(u.username));
    renderPicker();
  });
  $('#notifyAll')?.addEventListener('click', () => { if (modalReadOnly || !directory) return; directory.filter(pickable).forEach(u => notifySel.add(u.username)); renderPicker(); });
  $('#notifyNone')?.addEventListener('click', () => { if (modalReadOnly || !directory) return; notifySel.clear(); renderPicker(); });
  /* ---------- Escolha de pessoas (pastas fechadas) ---------- */
  const COORD = '__coord__'; // pasta extra "Coordenadores" (as pessoas continuam também no setor delas)
  const pickable = u => !!u.has_mail && u.username !== user.username; // quem cria já vê o próprio evento
  async function ensureDirectory() {
    if (directory) return directory;
    try { directory = (await api('users/directory')).users || []; } catch (e) { toast(e.message, true); return []; }
    return directory;
  }
  function syncNotifyUI() {
    const people = $('#eventNotifyMode').value === 'people';
    $('#notifyPicker').classList.toggle('hidden', !people);
    if (!people) return;
    if (directory) renderPicker();
    else { $('#notifyList').innerHTML = '<div class="empty">Carregando pessoas…</div>'; ensureDirectory().then(d => { if (d.length) renderPicker(); else $('#notifyList').innerHTML = '<div class="empty">Não foi possível carregar as pessoas.</div>'; }); }
  }

  /* ---------- Tela de carregamento ---------- */
  let busyProgressTimer = null, busyProgress = 0;
  function busy(on, text = 'Salvando…', hint = '') {
    const el = $('#busyOverlay'); if (!el) return;
    $('#busyText').textContent = text; $('#busyHint').textContent = hint;
    el.classList.toggle('hidden', !on);
    const bar = $('#busyProgressBar'), value = $('#busyProgressValue');
    if (busyProgressTimer) { clearInterval(busyProgressTimer); busyProgressTimer = null; }
    if (!on) { busyProgress = 100; if (bar) bar.style.width = '100%'; if (value) value.textContent = '100%'; return; }
    busyProgress = 0; if (bar) bar.style.width = '0%'; if (value) value.textContent = '0%';
    // Progresso visual enquanto o servidor processa; não finge conclusão antes da resposta.
    busyProgressTimer = setInterval(() => { busyProgress = Math.min(92, busyProgress + (busyProgress < 35 ? 4 : busyProgress < 70 ? 2 : 0.6)); if (bar) bar.style.width = busyProgress + '%'; if (value) value.textContent = Math.floor(busyProgress) + '%'; }, 120);
  }

  /* ---------- Formulário do evento (novo, editar ou só consultar) ---------- */
  function openEventModal(id = null, date = null, time = null) {
    const modal = $('#eventModal'); if (!modal) return;
    const ev = id ? (known.get(id) || findEv(id) || null) : null;
    if (id && !ev) { toast('Evento não encontrado. Atualize a página.', true); return; }
    lastFocus = document.activeElement;
    editingId = ev ? ev.id : null;
    modalReadOnly = !!ev && !canEdit(ev);
    pkOpen.clear(); $('#notifySearch').value = ''; $('#eventError').textContent = '';
    const units = [...(settings.units || [])]; if (ev?.location && !units.includes(ev.location)) units.push(ev.location);
    $('#eventLocation').innerHTML = ['', ...units].map(u => `<option value="${esc(u)}">${u ? esc(u) : 'Sem unidade'}</option>`).join('');
    const unit = ev ? (ev.location || '') : (units.includes(unitFilter) ? unitFilter : '');
    const h = Math.min(23, new Date().getHours() + 1), st = ev ? ev.start.slice(11, 16) : (time || `${pad(h)}:00`);
    const en = ev ? ev.end.slice(11, 16) : plusMinutes(st, Number(settings.default_duration || 60));
    const rem = String(ev ? (ev.reminder_minutes ?? 0) : (settings.default_reminder ?? 15)), remSel = $('#eventReminder');
    if (![...remSel.options].some(o => o.value === rem)) remSel.add(new Option(`${rem} minutos antes`, rem));
    const rec = ev?.recurrence || {}, set = (k, v) => { $('#' + k).value = v ?? ''; };
    set('eventName', ev?.title); set('eventDate', ev ? ev.start.slice(0, 10) : (date || ymd(new Date())));
    set('eventLocation', unit);
    set('eventColor', ev?.color || (units.indexOf(unit) >= 0 ? UNIT_COLORS[units.indexOf(unit) % UNIT_COLORS.length] : '#3156d8'));
    set('eventStart', st); set('eventEnd', en); set('eventDescription', ev?.description); set('eventReminder', rem);
    { const rs = $('#eventRecurrence'), rt = rec.type || 'none'; [...rs.options].forEach(o => { if (!['none', 'monthly', 'yearly'].includes(o.value)) o.remove(); }); if (![...rs.options].some(o => o.value === rt)) rs.add(new Option(({ daily: 'Todos os dias (antigo)', weekly: 'Toda semana (antigo)' })[rt] || rt, rt)); }
    set('eventRecurrence', rec.type || 'none'); set('eventInterval', rec.interval || 1); set('eventUntil', rec.until);
    set('eventNotifyMode', ['me', 'all', 'people'].includes(ev?.notify_mode) ? ev.notify_mode : 'me');
    notifySel = new Set(Array.isArray(ev?.notify_users) ? ev.notify_users : []);
    $$('#eventForm input, #eventForm select, #eventForm textarea').forEach(i => { i.disabled = modalReadOnly; });
    $('#saveEventBtn').classList.toggle('hidden', modalReadOnly);
    $('#deleteEventBtn').classList.toggle('hidden', !ev || modalReadOnly);
    $('#duplicateEventBtn').classList.toggle('hidden', !ev);
    const guest = !!ev && !!ev.created_by && ev.created_by !== user?.username; // alguém me mencionou neste evento
    $('#declineEventBtn').classList.toggle('hidden', !guest);
    const nos = (!guest && Array.isArray(ev?.declined)) ? ev.declined.map(d => d.name || d.username) : [];
    const dn = $('#declinedNote'); dn.classList.toggle('hidden', !nos.length); dn.textContent = nos.length ? `✋ Negaram este evento: ${nos.join(', ')}` : '';
    $('#modalEyebrow').textContent = !ev ? 'NOVO EVENTO' : (modalReadOnly ? 'EVENTO' : 'EDITAR EVENTO') + (ev.created_by_name ? ` · CRIADO POR ${ev.created_by_name}` : '');
    $('#modalTitle').textContent = !ev ? 'Novo evento' : (modalReadOnly ? 'Detalhes do evento' : 'Editar evento');
    toggleRecurrence(); syncNotifyUI();
    modal.classList.remove('hidden');
    if (!modalReadOnly) setTimeout(() => $('#eventName').focus(), 40);
  }

  /* ---------- Lista de eventos (aba Eventos) ---------- */
  function renderEventsTable() {
    const body = $('#eventsTable'); if (!body) return;
    const q = ($('#eventSearch')?.value || '').toLowerCase().trim();
    const list = listEvents.filter(e => !q || `${e.title} ${e.location || ''} ${e.description || ''}`.toLowerCase().includes(q)).slice(0, 400);
    body.innerHTML = list.length ? list.map(e => `<tr><td><button type="button" class="table-event event-link" data-id="${esc(e.id)}" data-occ="${dateOf(e)}"><span class="dot" style="background:${esc(e.color)}"></span>${esc(e.title)}</button></td><td>${fmt(dateOf(e), { day: '2-digit', month: '2-digit', year: 'numeric' })}</td><td>${timeOf(e)} – ${endOf(e)}</td><td>${esc(e.location || '—')}</td><td><button type="button" class="table-open event-link" data-id="${esc(e.id)}" data-occ="${dateOf(e)}">Abrir</button></td></tr>`).join('') : '<tr><td colspan="5"><div class="empty">Nenhum evento encontrado.</div></td></tr>';
  }
  async function loadEventsTable() {
    if (!$('#eventsTable')) return;
    if (!listEvents.length) $('#eventsTable').innerHTML = '<tr><td colspan="5"><div class="empty">Carregando…</div></td></tr>';
    try { listEvents = await fetchRange(ymd(addDays(new Date(), -60)), ymd(addDays(new Date(), 330))); } catch (e) { toast(e.message, true); }
    renderEventsTable();
  }
  $('#eventSearch')?.addEventListener('input', debounce(renderEventsTable));

  function closeModal() { $('#eventModal')?.classList.add('hidden'); lastFocus?.focus?.(); }
  const modalOpen = () => !$('#eventModal')?.classList.contains('hidden');
  $$('[data-close="1"]').forEach(b => b.addEventListener('click', closeModal));
  // Repetição: só "Todo mês" e "Todo ano". O dia (e o mês, no anual) vêm sozinhos da data do evento.
  function toggleRecurrence() {
    const sel = $('#eventRecurrence'); if (!sel) return;
    const d = $('#eventDate').value, [, m, day] = d ? d.split('-') : [];
    const label = { monthly: day ? `Todo mês (dia ${Number(day)})` : 'Todo mês', yearly: day ? `Todo ano (${day}/${m})` : 'Todo ano' };
    [...sel.options].forEach(o => { if (label[o.value]) o.textContent = label[o.value]; });
  }
  $('#eventRecurrence')?.addEventListener('change', toggleRecurrence);
  $('#eventDate')?.addEventListener('change', toggleRecurrence);
  // Mudar o início empurra o fim junto, mantendo a duração.
  $('#eventStart')?.addEventListener('change', () => { if (!$('#eventEnd').value || $('#eventEnd').value <= $('#eventStart').value) $('#eventEnd').value = plusMinutes($('#eventStart').value, Number(settings.default_duration || 60)); });
  async function refreshAll() { invalidate(); listEvents = []; await loadCalendar(); if (currentView === 'events') loadEventsTable(); if (currentView === 'dashboard') loadDashboard(); }

  $('#eventForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const err = $('#eventError'), btn = $('#saveEventBtn'); err.textContent = '';
    if ($('#eventEnd').value <= $('#eventStart').value) { err.textContent = 'O horário de término deve ser depois do início.'; $('#eventEnd').focus(); return; }
    const payload = { id: editingId, title: $('#eventName').value.trim(), date: $('#eventDate').value, color: $('#eventColor').value, start: $('#eventStart').value, end: $('#eventEnd').value, location: $('#eventLocation').value, notify_mode: $('#eventNotifyMode').value, notify_users: [...notifySel], notify_group: '', description: $('#eventDescription').value, reminder_minutes: Number($('#eventReminder').value), recurrence_type: $('#eventRecurrence').value, recurrence_interval: Number($('#eventInterval').value || 1), recurrence_until: $('#eventUntil').value };
    if (payload.notify_mode === 'people' && !payload.notify_users.length) { $('#eventError').textContent = 'Escolha pelo menos uma pessoa para mencionar, ou mude para "Só eu".'; return; }
    btn.disabled = true;
    try {
      if (!(await confirmClash(payload))) return;
      const repeats = payload.recurrence_type && payload.recurrence_type !== 'none', t0 = Date.now();
      busy(true, repeats ? 'Replicando o evento…' : 'Salvando o evento…', repeats ? 'Estamos repetindo o evento nas datas escolhidas.' : '');
      await api(editingId ? 'events/update' : 'events/create', { method: 'POST', body: JSON.stringify(payload) });
      await refreshAll();
      toast(editingId ? 'Evento atualizado.' : 'Evento criado.'); closeModal(); }
    catch (ex) { err.textContent = ex.message; } finally { busy(false); btn.disabled = false; }
  });
  $('#deleteEventBtn')?.addEventListener('click', async () => {
    if (!editingId || !confirm('Excluir este evento? Se ele se repete, toda a série será removida.')) return;
    try { await api('events/delete', { method: 'POST', body: JSON.stringify({ id: editingId }) }); toast('Evento excluído.'); closeModal(); await refreshAll(); } catch (e) { toast(e.message, true); }
  });

  // Duplicar: reabre como novo evento com os mesmos dados; falta só escolher a nova data.
  $('#declineEventBtn')?.addEventListener('click', async () => {
    if (!editingId || !confirm('Negar este evento?\n\nEle sai da sua agenda e quem criou será avisado.')) return;
    const b = $('#declineEventBtn'); b.disabled = true; busy(true, 'Negando o evento…');
    try { await api('events/decline', { method: 'POST', body: JSON.stringify({ id: editingId }) }); await refreshAll(); toast('Evento negado. Quem criou foi avisado.'); closeModal(); }
    catch (ex) { $('#eventError').textContent = ex.message; } finally { busy(false); b.disabled = false; }
  });
  $('#duplicateEventBtn')?.addEventListener('click', () => {
    const keys = ['eventName', 'eventColor', 'eventStart', 'eventEnd', 'eventLocation', 'eventNotifyMode', 'eventDescription', 'eventReminder', 'eventRecurrence', 'eventInterval', 'eventUntil'];
    const keep = keys.map(k => [k, $('#' + k).value]), date = $('#eventDate').value;
    const sel = new Set(notifySel); openEventModal(null, date); keep.forEach(([k, v]) => $('#' + k).value = v); notifySel = sel; toggleRecurrence(); syncNotifyUI();
    $('#modalTitle').textContent = 'Duplicar evento'; $('#eventDate').focus();
  });

  // Cor automática por unidade (só em evento novo), para distinguir as unidades de relance.
  const UNIT_COLORS = ['#2f9e44', '#3156d8', '#e8590c', '#7048e8', '#0c8599', '#d6336c', '#f08c00', '#495057'];
  $('#eventLocation')?.addEventListener('change', e => { if (editingId) return; const i = (settings.units || []).indexOf(e.target.value); if (i >= 0) $('#eventColor').value = UNIT_COLORS[i % UNIT_COLORS.length]; });

  // Aviso de conflito: mesma unidade, horários que se cruzam no mesmo dia.
  async function confirmClash(p, selfId = editingId) {
    if (!p.location) return true;
    try {
      const day = (await api('events/list', { query: { from: p.date, to: p.date } })).events || [], s = minutes(p.start), f = minutes(p.end);
      const clash = day.filter(x => x.id !== selfId && (x.location || '') === p.location && minutes(timeOf(x)) < f && minutes(endOf(x)) > s);
      if (!clash.length) return true;
      return confirm(`Já existe evento em ${p.location} nesse horário:\n\n` + clash.slice(0, 4).map(x => `• ${timeOf(x)}–${endOf(x)}  ${x.title}`).join('\n') + (clash.length > 4 ? `\n• e mais ${clash.length - 4}…` : '') + '\n\nSalvar mesmo assim?');
    } catch { return true; } // se a checagem falhar, não impede de salvar
  }

  /* ---------- Arrastar para reagendar (mês: muda o dia · semana/dia: muda dia e horário) ---------- */
  const findEv = (id, occ) => events.find(x => x.id === id && dateOf(x) === occ) || events.find(x => x.id === id);
  async function moveEvent(e, newDate, newStartMin) {
    const parse = s => new Date(String(s).replace(' ', 'T')), occ = parse(e.occurrence_start || e.start);
    const target = new Date(newDate + 'T00:00'); target.setMinutes(newStartMin ?? (occ.getHours() * 60 + occ.getMinutes()));
    const delta = target - occ; if (!delta) return false;
    const ns = new Date(parse(e.start).getTime() + delta), ne = new Date(parse(e.end).getTime() + delta), hm = d => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
    if (ymd(ns) !== ymd(ne)) { toast('O evento não pode passar da meia-noite.', true); return false; }
    const rec = e.recurrence || {};
    if (rec.type && rec.type !== 'none' && !confirm('Este evento se repete. Mover vai alterar toda a série. Continuar?')) return false;
    const payload = { id: e.id, title: e.title, date: ymd(ns), color: e.color, start: hm(ns), end: hm(ne), location: e.location || '', description: e.description || '', reminder_minutes: Number(e.reminder_minutes ?? settings.default_reminder ?? 15), recurrence_type: rec.type || 'none', recurrence_interval: rec.interval || 1, recurrence_until: rec.until || '' };
    if (!(await confirmClash(payload, e.id))) return false;
    try { await api('events/update', { method: 'POST', body: JSON.stringify(payload) }); toast(`Movido para ${fmt(ymd(ns), { day: '2-digit', month: '2-digit' })} às ${hm(ns)}.`); await refreshAll(); return true; }
    catch (err) { toast(err.message, true); return false; }
  }
  const calEl = $('#calendar');
  // Mês: arrastar o evento para outro dia (mantém o horário)
  calEl?.addEventListener('dragstart', ev => { const c = ev.target.closest('.event-chip[draggable]'); if (!c) return; ev.dataTransfer.setData('text/plain', c.dataset.id + '|' + c.dataset.occ); ev.dataTransfer.effectAllowed = 'move'; dragBlock = true; });
  calEl?.addEventListener('dragend', () => { setTimeout(() => { dragBlock = false; }, 0); $$('.drop-target').forEach(x => x.classList.remove('drop-target')); });
  calEl?.addEventListener('dragover', ev => { const c = ev.target.closest('.day-cell'); if (!c) return; ev.preventDefault(); $$('.drop-target').forEach(x => x !== c && x.classList.remove('drop-target')); c.classList.add('drop-target'); });
  calEl?.addEventListener('drop', ev => {
    const c = ev.target.closest('.day-cell'); if (!c) return; ev.preventDefault();
    const [id, occ] = (ev.dataTransfer.getData('text/plain') || '').split('|'), e = findEv(id, occ);
    if (e && c.dataset.date !== dateOf(e)) moveEvent(e, c.dataset.date, null);
  });
  // Semana/Dia: arrastar na grade (encaixa de 15 em 15 minutos). Só com mouse, para não atrapalhar a rolagem no celular.
  let drag = null;
  calEl?.addEventListener('pointerdown', ev => {
    const el = ev.target.closest('.schedule-event'); if (!el || ev.button !== 0 || ev.pointerType !== 'mouse') return;
    const e = findEv(el.dataset.id, el.closest('.schedule-col')?.dataset.date); if (!e || !canEdit(e)) return;
    drag = { el, e, x: ev.clientX, y: ev.clientY, grab: ev.clientY - el.getBoundingClientRect().top, on: false, dur: Math.max(30, minutes(endOf(e) || timeOf(e)) - minutes(timeOf(e))) };
  });
  document.addEventListener('pointermove', ev => {
    if (!drag) return;
    if (!drag.on) { if (Math.hypot(ev.clientX - drag.x, ev.clientY - drag.y) < 6) return; drag.on = true; dragBlock = true; drag.el.classList.add('dragging'); }
    const cols = $$('.schedule-col'), col = cols.find(c => { const r = c.getBoundingClientRect(); return ev.clientX >= r.left && ev.clientX < r.right; }) || drag.col || cols[0]; if (!col) return;
    const h0 = Number(settings.time_start ?? 7), pxMin = HOUR_PX / 60;
    const start = Math.max(0, Math.min(1440 - drag.dur, Math.round(((ev.clientY - drag.grab - col.getBoundingClientRect().top) / pxMin) / 15) * 15 + h0 * 60));
    drag.col = col; drag.date = col.dataset.date; drag.start = start;
    if (drag.el.parentElement !== col) col.appendChild(drag.el);
    drag.el.style.top = ((start - h0 * 60) * pxMin + 1) + 'px';
    const t = m => `${pad(Math.floor(m / 60))}:${pad(m % 60)}`, sm = drag.el.querySelector('small'); if (sm) sm.textContent = `${t(start)}–${t(start + drag.dur)}`;
  });
  document.addEventListener('pointerup', async () => {
    if (!drag) return; const d = drag; drag = null; if (!d.on) return;
    d.el.classList.remove('dragging'); setTimeout(() => { dragBlock = false; }, 0);
    if (d.date === dateOf(d.e) && d.start === minutes(timeOf(d.e))) return renderCalendar();
    if (!(await moveEvent(d.e, d.date, d.start))) renderCalendar(); // cancelou ou falhou: volta ao lugar
  });
  document.addEventListener('keydown', ev => { if (ev.key === 'Escape' && drag?.on) { drag = null; dragBlock = false; renderCalendar(); } });

  /* ---------- Atalhos de teclado ---------- */
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && $('#userModal') && !$('#userModal').classList.contains('hidden')) return $('#userModal').classList.add('hidden');
    if (e.key === 'Escape' && picker && !picker.classList.contains('hidden')) { togglePicker(false); return titleBtn.focus(); }
    if (e.key === 'Escape' && modalOpen()) return closeModal();
    if (e.ctrlKey || e.metaKey || e.altKey || modalOpen() || /INPUT|TEXTAREA|SELECT/.test(e.target.tagName) || $('#pwModal')) return;
    const k = e.key.toLowerCase();
    if (k === 'n') { e.preventDefault(); openEventModal(); }
    else if (k === '/') { e.preventDefault(); navigate('events'); setTimeout(() => $('#eventSearch')?.focus(), 60); }
    else if (currentView === 'calendar') {
      if (k === 'arrowleft') shift(-1); else if (k === 'arrowright') shift(1);
      else if (k === 't') $('#todayBtn').click();
      else if (k === 'm') setCalView('month'); else if (k === 's' || k === 'w') setCalView('week'); else if (k === 'd') setCalView('day');
    }
  });

  /* ---------- Administração: configurações, usuários e LDAP ---------- */
  async function loadSettings(){
    try{const d=await api('settings/get');settings=d.settings;setTheme();fillSettings();const l=await api('ldap/status');renderLdap(l.ldap);loadUsers();}catch(e){toast(e.message,true);}
  }
  const lists = { units: [], sectors: [] };
  function renderChips(k) { const el = $('#' + k + 'Chips'); if (!el) return; el.innerHTML = lists[k].length ? lists[k].map((v, i) => `<span class="chip">${esc(v)}<button type="button" data-k="${k}" data-i="${i}" aria-label="Remover ${esc(v)}">×</button></span>`).join('') : '<span class="form-note">Nenhum cadastrado.</span>'; }
  document.addEventListener('click', e => { const b = e.target.closest('.chip button'); if (!b) return; lists[b.dataset.k].splice(+b.dataset.i, 1); renderChips(b.dataset.k); });
  ['units'].forEach(k => {
    const add = () => { const inp = $('#' + k + 'Input'), v = inp.value.trim(); if (!v) return; if (!lists[k].some(x => x.toLowerCase() === v.toLowerCase())) lists[k].push(v); inp.value = ''; renderChips(k); inp.focus(); };
    $('#' + k + 'Add')?.addEventListener('click', add);
    $('#' + k + 'Input')?.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); add(); } });
  });
  function fillSettings() {
    const m = { setFirstDay: settings.first_day, setDuration: settings.default_duration, setReminder: settings.default_reminder, setTimeStart: settings.time_start, setTimeEnd: settings.time_end };
    Object.entries(m).forEach(([id, v]) => { const el = $('#' + id); if (el) el.value = v; });
    $('#setNotifications').checked = !!settings.notifications; $('#setHolidays').checked = settings.show_holidays !== false;
    lists.units = [...(settings.units || [])]; renderChips('units'); renderSectors(); loadBackups();
  }
  function renderLdap(l){$('#ldapDetails').innerHTML=`<div><span>Status</span><strong>${l.enabled?'Ativo':'Desativado'}</strong></div><div><span>Servidor</span><strong>${esc(l.server)}${l.server_name?' · '+esc(l.server_name):''}</strong></div><div><span>Domínio</span><strong>${esc(l.domain)}</strong></div><div><span>Extensão PHP</span><strong>${l.php_extension?'OK':'Não habilitada'}</strong></div><div><span>Grupo administrador</span><strong>${esc((l.admin_groups||[]).join(', '))}</strong></div><div><span>Conta de serviço</span><strong>${l.service_configured?'Configurada':'Sem senha no .env'}</strong></div><div><span>Última sincronização</span><strong>${l.last_sync?esc(formatStamp(l.last_sync.at)):'Nunca'}</strong></div>`;}
  function formatStamp(iso){ try{ return new Intl.DateTimeFormat('pt-BR',{dateStyle:'short',timeStyle:'short'}).format(new Date(iso)); }catch{ return iso||''; } }
  function renderChecks(el, checks){
    if(!Array.isArray(checks)||!checks.length) return;
    el.innerHTML += '<ul class="checks">'+checks.map(c=>`<li class="${c.ok?'ok':'bad'}"><strong>${c.ok?'✓':'✗'} ${esc(c.label)}</strong>${c.detail?`<small>${esc(c.detail)}</small>`:''}</li>`).join('')+'</ul>';
  }

  let usersCache = [];
  async function loadUsers() { try { const d = await api('users/list'); usersCache = d.users || []; renderUsers(); renderSectors(); } catch (e) { const b = $('#usersGroups'); if (b) b.innerHTML = `<div class="empty">${esc(e.message)}</div>`; } }
  function sectorOptions(cur) {
    const set = new Set([...(settings.sectors || []), ...usersCache.map(u => u.sector).filter(Boolean)].filter(n => !isOff(n))); if (cur) set.add(cur); // setor desativado não aparece para novas atribuições
    return ['', ...[...set].sort((a, b) => a.localeCompare(b, 'pt-BR'))];
  }
  const optHtml = (list, sel) => list.map(s => `<option value="${esc(s)}" ${s === sel ? 'selected' : ''}>${s ? esc(s) : 'Sem setor'}</option>`).join('');
  function userRow(u) {
    const dis = u.id === user.id ? 'disabled' : '';
    const flags = [u.ad_disabled ? '<span class="badge warn">desativado no AD</span>' : '', u.ad_missing ? '<span class="badge warn">fora do AD</span>' : ''].join(' ');
    return `<tr data-id="${esc(u.id)}"><td><strong>${esc(u.name)}</strong><small class="sub">${esc(u.username)}</small></td><td><span class="badge">${u.source === 'ldap' ? 'AD' : 'Local'}</span> ${flags}</td><td><select class="user-sector" ${dis}>${optHtml(sectorOptions(u.sector), u.sector || '')}</select></td><td><input type="email" class="user-email" maxlength="320" value="${esc(u.email_manual || '')}" placeholder="${esc(u.mail_effective || 'sem e-mail')}" title="Deixe vazio para usar o e-mail do AD (ou usuário@domínio). Preencha para usar outro, como a caixa do setor."></td><td><select class="user-profile" ${dis}><option value="user" ${u.profile === 'user' ? 'selected' : ''}>Usuário</option><option value="admin" ${u.profile === 'admin' ? 'selected' : ''}>Administrador</option></select></td><td><label class="check inline"><input type="checkbox" class="user-active" ${u.active ? 'checked' : ''} ${dis}> ${u.active ? 'Ativo' : 'Inativo'}</label></td><td><label class="check inline" title="Entra também na pasta Coordenadores (continua no setor dela)"><input type="checkbox" class="user-coord" ${u.coordinator ? 'checked' : ''}> Coordenador(a)</label></td><td>${u.last_login ? esc(formatStamp(u.last_login)) : '—'}</td></tr>`;
  }
  function renderUsers() {
    const box = $('#usersGroups'); if (!box) return;
    const q = ($('#userSearch')?.value || '').toLowerCase().trim();
    const list = usersCache.filter(u => `${u.name} ${u.username} ${u.email || ''} ${u.sector || ''}`.toLowerCase().includes(q));
    if (!list.length) { box.innerHTML = '<div class="empty">Nenhum usuário. Use “Sincronizar usuários” ou crie um usuário local.</div>'; return; }
    const openNow = new Set($$('#usersGroups details[open]').map(d => d.dataset.g)), groups = {};
    list.forEach(u => (groups[u.sector || ''] ||= []).push(u));
    const names = Object.keys(groups).sort((a, b) => !a ? 1 : !b ? -1 : a.localeCompare(b, 'pt-BR'));
    box.innerHTML = names.map(n => `<details class="sector-group" data-g="${esc(n)}" ${q || openNow.has(n) ? 'open' : ''}><summary><span>📁 ${n ? esc(n) : 'Sem setor'}</span><span class="badge">${groups[n].length}</span></summary><div class="table-wrap"><table><thead><tr><th>Usuário</th><th>Origem</th><th>Setor</th><th>E-mail dos avisos</th><th>Perfil</th><th>Status</th><th>Coordenação</th><th>Último acesso</th></tr></thead><tbody>${groups[n].map(userRow).join('')}</tbody></table></div></details>`).join('');
  }
  async function updateUser(id, change) {
    try { const d = await api('users/update', { method: 'POST', body: JSON.stringify({ id, ...change }) }); const i = usersCache.findIndex(x => x.id === id); if (i >= 0) usersCache[i] = d.user; toast('Usuário atualizado.'); }
    catch (e) { toast(e.message, true); }
    renderUsers();
  }
  $('#usersGroups')?.addEventListener('change', e => {
    const id = e.target.closest('tr[data-id]')?.dataset.id; if (!id) return;
    if (e.target.matches('.user-profile')) updateUser(id, { profile: e.target.value });
    else if (e.target.matches('.user-active')) updateUser(id, { active: e.target.checked });
    else if (e.target.matches('.user-sector')) updateUser(id, { sector: e.target.value });
    else if (e.target.matches('.user-email')) updateUser(id, { email_manual: e.target.value.trim() });
    else if (e.target.matches('.user-coord')) updateUser(id, { coordinator: e.target.checked });
  });
  $('#userSearch')?.addEventListener('input', debounce(renderUsers));
  /* ---------- Backups ---------- */
  const fmtSize = n => n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
  async function loadBackups() {
    const box = $('#backupList'); if (!box) return;
    try {
      const d = await api('backup/list');
      const kind = n => /_auto\./.test(n) ? 'Automático' : /_manual\./.test(n) ? 'Manual' : /_antes\./.test(n) ? 'Antes de restaurar' : 'Backup';
      const url = (n, v) => `/api.php?route=backup%2Fdownload&name=${encodeURIComponent(n)}${v ? '&view=1' : ''}`;
      box.innerHTML = d.backups.length ? d.backups.map(b => `<div class="backup-row"><div class="sr-name"><strong>${esc(formatStamp(b.created))} <span class="badge">${kind(b.name)}</span></strong><small>${fmtSize(b.size)}</small></div><a class="btn secondary" href="${url(b.name, true)}" target="_blank" rel="noopener">Visualizar</a><a class="btn secondary" href="${url(b.name)}">Baixar</a><button type="button" class="btn danger backup-restore" data-name="${esc(b.name)}">Restaurar</button><button type="button" class="btn secondary backup-delete" data-name="${esc(b.name)}">Apagar</button></div>`).join('') : '<div class="empty">Nenhum backup ainda.</div>';
    } catch (e) { box.innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
  }
  $('#backupNow')?.addEventListener('click', async () => {
    const btn = $('#backupNow'); btn.disabled = true;
    try { await api('backup/create', { method: 'POST', body: '{}' }); toast('Backup criado.'); await loadBackups(); } catch (e) { toast(e.message, true); } finally { btn.disabled = false; }
  });
  $('#backupFile')?.addEventListener('change', async e => {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return;
    if (!confirm(`Restaurar o backup do arquivo “${f.name}”?\n\nEventos, pessoas e configurações atuais serão substituídos. Um backup do estado atual é feito antes.`)) return;
    try { await api('backup/restore', { method: 'POST', body: JSON.stringify({ content: await f.text() }) }); toast('Backup restaurado. Recarregando…'); setTimeout(() => location.reload(), 1200); } catch (err) { toast(err.message, true); }
  });
  $('#backupList')?.addEventListener('click', async e => {
    const d = e.target.closest('.backup-delete'); if (!d) return;
    if (!confirm('Apagar este backup?\n\nEle some da lista e não dá para recuperar depois.')) return;
    d.disabled = true;
    try { await api('backup/delete', { method: 'POST', body: JSON.stringify({ name: d.dataset.name }) }); toast('Backup apagado.'); await loadBackups(); } catch (err) { toast(err.message, true); d.disabled = false; }
  });
  $('#backupList')?.addEventListener('click', async e => {
    const b = e.target.closest('.backup-restore'); if (!b) return;
    if (!confirm('Restaurar este backup?\n\nEventos, usuários e configurações atuais serão substituídos pelos dessa data. Um backup do estado atual é feito antes.\n\nVocê pode ser desconectado ao final.')) return;
    try { await api('backup/restore', { method: 'POST', body: JSON.stringify({ name: b.dataset.name }) }); toast('Backup restaurado. Recarregando…'); setTimeout(() => location.reload(), 1200); } catch (err) { toast(err.message, true); }
  });

  /* ---------- Setores: adicionar, ativar/desativar e excluir (só na agenda) ---------- */
  const isOff = n => (settings.sectors_disabled || []).some(x => x.toLowerCase() === n.toLowerCase());
  function sectorCounts() { const m = {}; usersCache.forEach(u => u.sector && (m[u.sector] = (m[u.sector] || 0) + 1)); return m; }
  function allSectors() {
    const seen = new Map();
    [...(settings.sectors || []), ...usersCache.map(u => u.sector).filter(Boolean)].forEach(n => { if (!seen.has(n.toLowerCase())) seen.set(n.toLowerCase(), n); });
    return [...seen.values()].sort((a, b) => a.localeCompare(b, 'pt-BR'));
  }
  function renderSectors() {
    const box = $('#sectorsManage'); if (!box) return;
    const counts = sectorCounts(), list = allSectors();
    box.innerHTML = list.length ? list.map(n => { const off = isOff(n); return `<div class="sector-row${off ? ' off' : ''}"><div class="sr-name"><strong>${esc(n)}</strong><small>${counts[n] || 0} pessoa(s)${off ? ' · desativado' : ''}</small></div><label class="switch-toggle" title="${off ? 'Ativar' : 'Desativar'} setor"><input type="checkbox" class="sector-toggle" data-sector="${esc(n)}" ${off ? '' : 'checked'} aria-label="Ativar ${esc(n)}"><span></span></label><button type="button" class="btn danger sector-del" data-sector="${esc(n)}">Excluir</button></div>`; }).join('') : '<div class="empty">Nenhum setor ainda.</div>';
  }
  async function manageSector(action, name, extra = {}) {
    try { const d = await api('sectors/manage', { method: 'POST', body: JSON.stringify({ action, name, ...extra }) }); settings = d.settings; await loadUsers(); renderSectors(); return d; }
    catch (e) { toast(e.message, true); renderSectors(); }
  }
  $('#sectorsManage')?.addEventListener('change', e => { if (e.target.matches('.sector-toggle')) manageSector('toggle', e.target.dataset.sector, { active: e.target.checked }); });
  $('#sectorsManage')?.addEventListener('click', async e => {
    const b = e.target.closest('.sector-del'); if (!b) return;
    const n = b.dataset.sector, c = sectorCounts()[n] || 0;
    if (!confirm(`Excluir o setor “${n}”?\n\nIsso vale só para a agenda; o Active Directory não é alterado.` + (c ? `\n${c} pessoa(s) ficarão em “Sem setor”.` : '') + '\nA pasta some e a sincronização do AD não a recria.')) return;
    if (await manageSector('delete', n)) toast('Setor excluído.');
  });
  async function addSector() { const inp = $('#sectorsInput'), v = inp.value.trim(); if (!v) return; inp.value = ''; if (await manageSector('add', v)) toast('Setor adicionado.'); }
  $('#sectorsAdd')?.addEventListener('click', addSector);
  $('#sectorsInput')?.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addSector(); } });

  const userModal = $('#userModal'), closeUser = () => userModal?.classList.add('hidden');
  $('#newUserBtn')?.addEventListener('click', () => { $('#userForm').reset(); $('#nuError').textContent = ''; $('#nuSector').innerHTML = optHtml(sectorOptions(), ''); userModal.classList.remove('hidden'); $('#nuName').focus(); });
  $$('[data-close-user]').forEach(b => b.addEventListener('click', closeUser));
  $('#userForm')?.addEventListener('submit', async e => {
    e.preventDefault(); const err = $('#nuError'); err.textContent = '';
    try {
      const d = await api('users/create', { method: 'POST', body: JSON.stringify({ name: $('#nuName').value, username: $('#nuUser').value, password: $('#nuPass').value, profile: $('#nuProfile').value, sector: $('#nuSector').value }) });
      usersCache.push(d.user); renderUsers(); closeUser(); toast('Usuário criado.');
    } catch (ex) { err.textContent = ex.message; }
  });
  $('#mailTestBtn')?.addEventListener('click', async () => {
    const to = $('#mailTestTo').value.trim(), msg = $('#mailTestMsg'), btn = $('#mailTestBtn');
    if (!to) { msg.textContent = 'Informe o e-mail de destino.'; return; }
    btn.disabled = true; btn.textContent = 'Enviando…'; msg.textContent = '';
    try { await api('mail/test', { method: 'POST', body: JSON.stringify({ to }) }); msg.textContent = '✔ E-mail de teste enviado para ' + to; toast('E-mail de teste enviado.'); }
    catch (e) { msg.textContent = '✖ ' + e.message; }
    finally { btn.disabled = false; btn.textContent = 'Enviar e-mail de teste'; }
  });
  $('#saveSettings')?.addEventListener('click', async () => {
    try {
      const d = await api('settings/save', { method: 'POST', body: JSON.stringify({ first_day: Number($('#setFirstDay').value), default_duration: Number($('#setDuration').value), default_reminder: Number($('#setReminder').value), time_start: Number($('#setTimeStart').value), time_end: Number($('#setTimeEnd').value), notifications: $('#setNotifications').checked, show_holidays: $('#setHolidays').checked, units: lists.units }) });
      settings = d.settings; invalidate(); fillSettings(); renderUsers();
      $('#settingsSaved').textContent = 'Salvo agora'; setTimeout(() => $('#settingsSaved').textContent = '', 2200); toast('Configurações salvas.');
    } catch (e) { toast(e.message, true); }
  });
  $('#ldapTest')?.addEventListener('click',async()=>{const el=$('#ldapResult');el.textContent='Testando conexão…';try{const r=await api('ldap/test');el.textContent=r.message||'Conexão validada.';renderChecks(el,r.checks);toast('LDAP conectado.');}catch(e){el.textContent=e.message;renderChecks(el,e.data?.checks);toast(e.message,true);}});
  $('#ldapSync')?.addEventListener('click',async()=>{const el=$('#ldapResult');el.textContent='Sincronizando usuários do Active Directory…';try{const r=await api('ldap/sync',{method:'POST'});el.textContent=`Sincronização concluída: ${r.created} novos, ${r.updated} atualizados, ${r.ignored} ignorados${r.disabled?`, ${r.disabled} desativados no AD`:''}${r.missing?`, ${r.missing} fora do AD`:''}.`;toast('Usuários sincronizados.');loadUsers();api('ldap/status').then(l=>renderLdap(l.ldap)).catch(()=>{});}catch(e){el.textContent=e.message;toast(e.message,true);}});

  /* ---------- Lembretes (enquanto o sistema estiver aberto) ---------- */
  const fired = new Set();
  async function checkReminders() {
    if (!settings.notifications) return;
    try {
      const d = await api('dashboard'), now = Date.now();
      for (const e of [...d.today_events, ...d.upcoming]) {
        const mins = Number(e.reminder_minutes ?? 0), at = new Date((e.occurrence_start || e.start).replace(' ', 'T')).getTime(), key = e.id + at;
        if (mins > 0 && !fired.has(key) && at - now <= mins * 60000 && at > now) { fired.add(key); notify(`${e.title} começa em ${Math.max(1, Math.round((at - now) / 60000))} min`, e.location || 'Cen Agenda'); }
      }
    } catch (_) { /* silencioso: tenta no próximo ciclo */ }
  }
  async function notify(title, body) {
    toast('🔔 ' + title);
    try { if ('Notification' in window && Notification.permission === 'granted') new Notification(title, { body, icon: '/assets/favicon.svg' }); } catch (_) {}
  }
  if (settings.notifications && 'Notification' in window && Notification.permission === 'default') $('#newEventBtn, .nav') && document.addEventListener('click', () => Notification.requestPermission(), { once: true });

  /* ---------- Início ---------- */
  if (user.must_change_password) { initPasswordModal(); return; }
  $$('.switch[data-calview]').forEach(b => b.classList.toggle('active', b.dataset.calview === calView));
  navigate(location.hash.slice(1) || 'dashboard', { push: false });
  checkReminders(); setInterval(checkReminders, 60000);
  setInterval(() => { if (!document.hidden && currentView === 'calendar' && calView !== 'month') renderCalendar(); }, 60000); // move a linha de "agora"
})();
