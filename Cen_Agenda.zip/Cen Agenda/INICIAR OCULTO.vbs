' ============================================================
'  CEN AGENDA - iniciar oculto
'  Abre a agenda SEM deixar nenhuma janela do CMD na tela.
'  Dar dois cliques neste arquivo. Se a agenda ja estiver
'  rodando, ele pergunta se quer abrir no navegador ou encerrar.
' ============================================================
Option Explicit

Dim sh, fso, pasta, porta, q, bat, cmd, resp, ok, i

Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
q = Chr(34)
pasta = fso.GetParentFolderName(WScript.ScriptFullName)
bat = pasta & "\iniciar.bat"
sh.CurrentDirectory = pasta

If Not fso.FileExists(bat) Then
  MsgBox "Nao encontrei o iniciar.bat nesta pasta." & vbCrLf & "Deixe este arquivo na mesma pasta do iniciar.bat.", vbCritical, "Cen Agenda"
  WScript.Quit 1
End If

porta = LePorta(bat)

' Ja esta rodando?
If Escutando() Then
  resp = MsgBox("A Cen Agenda ja esta em execucao." & vbCrLf & vbCrLf & _
                "Sim = abrir no navegador" & vbCrLf & _
                "Nao = encerrar a Cen Agenda" & vbCrLf & _
                "Cancelar = nao fazer nada", vbYesNoCancel + vbQuestion, "Cen Agenda")
  If resp = vbYes Then sh.Run "http://127.0.0.1:" & porta & "/"
  If resp = vbNo Then Encerrar
  WScript.Quit 0
End If

' PHP instalado?
If sh.Run("cmd /c where php >nul 2>nul", 0, True) <> 0 Then
  MsgBox "O PHP nao foi encontrado neste computador." & vbCrLf & "Execute o instalar.bat primeiro.", vbCritical, "Cen Agenda"
  WScript.Quit 1
End If

' Inicia o iniciar.bat com a janela oculta (o proprio .bat abre o navegador)
cmd = "cmd /c " & q & q & bat & q & " oculto" & q
sh.Run cmd, 0, False

' Espera o servidor subir (ate ~25 segundos)
ok = False
For i = 1 To 25
  WScript.Sleep 1000
  If Escutando() Then
    ok = True
    Exit For
  End If
Next

If Not ok Then
  MsgBox "Nao foi possivel iniciar a Cen Agenda." & vbCrLf & vbCrLf & _
         "Veja a pasta logs (servidor.log) ou execute o instalar.bat.", vbCritical, "Cen Agenda"
End If

' ---------------------------------------------------------------
Function LePorta(arq)
  Dim f, t, re, m
  LePorta = "5080"
  On Error Resume Next
  Set f = fso.OpenTextFile(arq, 1)
  t = f.ReadAll
  f.Close
  Set re = New RegExp
  re.Pattern = "set ""PORT=(\d+)"""
  re.IgnoreCase = True
  Set m = re.Execute(t)
  If m.Count > 0 Then LePorta = m(0).SubMatches(0)
  Err.Clear
  On Error GoTo 0
End Function

' Verdadeiro se alguma coisa esta escutando na porta da agenda
Function Escutando()
  Dim c
  c = "cmd /c netstat -ano | findstr " & q & ":" & porta & q & " | findstr " & q & "LISTENING" & q & " >nul 2>&1"
  Escutando = (sh.Run(c, 0, True) = 0)
End Function

' Encerra o iniciar.bat oculto, o servidor e o worker
Sub Encerrar()
  Dim svc, col, p, cl
  On Error Resume Next
  Set svc = GetObject("winmgmts:\\.\root\cimv2")
  Set col = svc.ExecQuery("Select * from Win32_Process Where Name = 'cmd.exe'")
  For Each p In col
    cl = LCase(p.CommandLine & "")
    If InStr(cl, "iniciar.bat") > 0 And InStr(cl, "oculto") > 0 Then p.Terminate
  Next
  Set col = svc.ExecQuery("Select * from Win32_Process Where Name = 'php.exe'")
  For Each p In col
    cl = LCase(p.CommandLine & "")
    If InStr(cl, "worker.php") > 0 Or InStr(cl, "0.0.0.0:" & porta) > 0 Then p.Terminate
  Next
  Err.Clear
  On Error GoTo 0
  WScript.Sleep 1500
  If Escutando() Then
    MsgBox "Nao consegui encerrar tudo." & vbCrLf & "Feche o processo php.exe pelo Gerenciador de Tarefas.", vbExclamation, "Cen Agenda"
  Else
    MsgBox "Cen Agenda encerrada.", vbInformation, "Cen Agenda"
  End If
End Sub
