<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/ldap_config.php';

/**
 * Camada LDAP/Active Directory da Cen Agenda.
 *
 * Mesmo modelo da Intranet Erasmo: o AD autentica e informa identidade/grupos; o cadastro
 * local controla o resto. Esta camada só devolve dados — não grava nada.
 */

/** Subcódigos do AD ("data 52e" na mensagem de diagnóstico) que encerram a tentativa de login. */
const LDAP_AD_FINAL_ERRORS = [
    '52e' => 'Usuário ou senha inválidos no Active Directory.',
    '530' => 'Este usuário não tem permissão para entrar neste horário.',
    '531' => 'Este usuário não tem permissão para entrar nesta estação.',
    '532' => 'A senha do Active Directory expirou. Altere a senha e tente novamente.',
    '533' => 'A conta do Active Directory está desativada.',
    '701' => 'A conta do Active Directory expirou.',
    '773' => 'É necessário redefinir a senha no Active Directory antes de entrar.',
    '775' => 'A conta do Active Directory está bloqueada. Procure o TI.',
];

const LDAP_USER_ATTRIBUTES = ['cn', 'displayName', 'mail', 'memberOf', 'sAMAccountName', 'userPrincipalName', 'userAccountControl'];

// ---------------------------------------------------------------------------
// Utilidades
// ---------------------------------------------------------------------------

function ldap_extension_loaded(): bool {
    return function_exists('ldap_connect');
}

function ldap_available(): bool {
    return ldap_cfg()['enabled'] && ldap_extension_loaded();
}

/** Aceita "usuario", "CEN\usuario" e "usuario@cen.local" e devolve só o login curto. */
function normalize_ldap_username(string $username): string {
    $username = trim($username);
    if (str_contains($username, '\\')) $username = substr($username, (int)strrpos($username, '\\') + 1);
    if (str_contains($username, '@')) $username = substr($username, 0, (int)strpos($username, '@'));
    return strtolower($username);
}

/** Minúsculas + sem acentos, para comparar nomes de grupo ("Admins. do domínio" == "admins. do dominio"). */
function ldap_fold(string $s): string {
    $s = trim($s);
    $s = function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
    return strtr($s, [
        'á' => 'a', 'à' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a',
        'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
        'í' => 'i', 'ì' => 'i', 'î' => 'i', 'ï' => 'i',
        'ó' => 'o', 'ò' => 'o', 'ô' => 'o', 'õ' => 'o', 'ö' => 'o',
        'ú' => 'u', 'ù' => 'u', 'û' => 'u', 'ü' => 'u',
        'ç' => 'c', 'ñ' => 'n',
    ]);
}

function ldap_fail(string $code, string $message): array {
    return ['ok' => false, 'code' => $code, 'error' => $message];
}

// ---------------------------------------------------------------------------
// Conexão
// ---------------------------------------------------------------------------

function ldap_uri(): string {
    $cfg = ldap_cfg();
    $host = (string)$cfg['server'];
    if (preg_match('#^ldaps?://#i', $host)) return $host; // URI completa informada no .env
    return ($cfg['use_ssl'] ? 'ldaps' : 'ldap') . '://' . $host . ':' . (int)$cfg['port'];
}

/** Abre uma conexão ainda sem bind. Lança RuntimeException se a biblioteca recusar. */
function ldap_open() {
    $cfg = ldap_cfg();
    if ($cfg['use_ssl'] && !$cfg['tls_verify'] && defined('LDAP_OPT_X_TLS_REQUIRE_CERT') && defined('LDAP_OPT_X_TLS_NEVER')) {
        @ldap_set_option(null, LDAP_OPT_X_TLS_REQUIRE_CERT, LDAP_OPT_X_TLS_NEVER);
    }
    $conn = @ldap_connect(ldap_uri());
    if ($conn === false) throw new RuntimeException('Não foi possível iniciar a conexão com o Active Directory.');
    ldap_set_option($conn, LDAP_OPT_PROTOCOL_VERSION, 3);
    ldap_set_option($conn, LDAP_OPT_REFERRALS, 0);
    ldap_set_option($conn, LDAP_OPT_NETWORK_TIMEOUT, (int)$cfg['timeout']);
    if (defined('LDAP_OPT_TIMEOUT')) ldap_set_option($conn, LDAP_OPT_TIMEOUT, (int)$cfg['timeout']);
    return $conn;
}

/**
 * Tenta um bind e devolve ['ok', 'code' (erro LDAP; -1 = servidor inacessível), 'ad' (subcódigo do AD)].
 * O subcódigo permite distinguir senha errada (52e), conta bloqueada (775), etc. — e assim
 * evitar repetir a mesma senha errada em vários formatos de login, o que bloquearia contas no AD.
 */
function ldap_bind_attempt($conn, string $account, string $password): array {
    if (@ldap_bind($conn, $account, $password)) return ['ok' => true, 'code' => 0, 'ad' => ''];
    $code = (int)@ldap_errno($conn);
    $diag = '';
    if (defined('LDAP_OPT_DIAGNOSTIC_MESSAGE')) @ldap_get_option($conn, LDAP_OPT_DIAGNOSTIC_MESSAGE, $diag);
    $ad = preg_match('/data\s+([0-9a-f]{3,4})\b/i', (string)$diag, $m) ? strtolower($m[1]) : '';
    return ['ok' => false, 'code' => $code, 'ad' => $ad];
}

function ldap_is_final_failure(array $r): bool {
    return ($r['code'] ?? 0) === -1 || (($r['ad'] ?? '') !== '' && isset(LDAP_AD_FINAL_ERRORS[$r['ad']]));
}

function ldap_failure_text(array $r): string {
    if (($r['code'] ?? 0) === -1) return 'Não foi possível contatar o servidor LDAP (verifique IP, porta e firewall).';
    $ad = (string)($r['ad'] ?? '');
    if ($ad !== '' && isset(LDAP_AD_FINAL_ERRORS[$ad])) return LDAP_AD_FINAL_ERRORS[$ad];
    return 'O Active Directory recusou a autenticação (erro LDAP ' . (int)($r['code'] ?? 0) . ($ad !== '' ? ', AD ' . $ad : '') . ').';
}

/** Formatos de login que o AD aceita, na ordem em que são tentados. */
function ldap_user_bind_candidates(string $username): array {
    $cfg = ldap_cfg();
    $list = [];
    if ($cfg['netbios'] !== '') $list[] = $cfg['netbios'] . '\\' . $username;
    $list[] = $username . '@' . $cfg['domain'];
    $list[] = $username;
    return array_values(array_unique($list));
}

function ldap_service_candidates(): array {
    $cfg = ldap_cfg();
    $bind = trim((string)$cfg['bind_user']);
    if ($bind === '') return [];
    if (str_contains($bind, '\\') || str_contains($bind, '@')) return [$bind];
    $list = [];
    if ($cfg['netbios'] !== '') $list[] = $cfg['netbios'] . '\\' . $bind;
    $list[] = $bind . '@' . $cfg['domain'];
    $list[] = $bind;
    return array_values(array_unique($list));
}

function ldap_service_configured(): bool {
    $cfg = ldap_cfg();
    return trim((string)$cfg['bind_user']) !== '' && (string)$cfg['bind_password'] !== '';
}

/** Conexão autenticada com a conta de serviço (a mesma "intranet@cen.local" da Intranet). */
function ldap_service_connect() {
    if (!ldap_extension_loaded()) throw new RuntimeException('A extensão LDAP do PHP não está habilitada (execute instalar.bat).');
    if (!ldap_service_configured()) throw new RuntimeException('Configure o usuário e a senha da conta de serviço LDAP no arquivo .env.');
    $last = null;
    foreach (ldap_service_candidates() as $account) {
        $conn = ldap_open();
        $r = ldap_bind_attempt($conn, $account, (string)ldap_cfg()['bind_password']);
        if ($r['ok']) return $conn;
        @ldap_unbind($conn);
        $last = $r;
        if (ldap_is_final_failure($r)) break;
    }
    $text = ldap_failure_text($last ?? ['code' => 0]);
    if (($last['ad'] ?? '') === '52e') $text = 'A conta de serviço LDAP foi recusada: usuário ou senha incorretos no .env.';
    throw new RuntimeException($text);
}

// ---------------------------------------------------------------------------
// Leitura de entradas (formato de ldap_get_entries: chaves em minúsculas + "count")
// ---------------------------------------------------------------------------

function ldap_attr(array $entry, string $name): array {
    $key = strtolower($name);
    if (!isset($entry[$key]) || !is_array($entry[$key])) return [];
    $values = [];
    foreach ($entry[$key] as $i => $v) {
        if ($i === 'count') continue;
        $values[] = (string)$v;
    }
    return $values;
}

function ldap_attr_first(array $entry, string $name): string {
    $values = ldap_attr($entry, $name);
    return $values[0] ?? '';
}

/** "CN=Admins. do domínio,CN=Users,DC=cen,DC=local" -> "Admins. do domínio" (respeita "\," escapado). */
function ldap_group_cn(string $dn): string {
    if (preg_match('/^CN=((?:\\\\.|[^,\\\\])+)/i', $dn, $m)) {
        return trim((string)preg_replace('/\\\\(.)/s', '$1', $m[1]));
    }
    return trim($dn);
}

function ldap_in_group(array $groups, array|string $targets): bool {
    if (is_string($targets)) $targets = [$targets];
    $have = [];
    foreach ($groups as $g) $have[ldap_fold((string)$g)] = true;
    foreach ($targets as $t) {
        if (isset($have[ldap_fold((string)$t)])) return true;
    }
    return false;
}

function ldap_sector_from_groups(array $groups): ?string {
    foreach (ldap_cfg()['sector_groups'] as $slug => $candidates) {
        if (ldap_in_group($groups, $candidates)) return (string)$slug;
    }
    return null;
}

function ldap_entry_info(array $entry): array {
    $username = normalize_ldap_username(ldap_attr_first($entry, 'samaccountname'));
    $name = trim(ldap_attr_first($entry, 'displayname'));
    if ($name === '') $name = trim(ldap_attr_first($entry, 'cn'));
    if ($name === '') $name = $username;
    $groups = array_values(array_unique(array_filter(array_map('ldap_group_cn', ldap_attr($entry, 'memberof')), fn($g) => $g !== '')));
    $uac = (int)ldap_attr_first($entry, 'useraccountcontrol');
    return [
        'username' => $username,
        'name' => $name,
        'email' => trim(ldap_attr_first($entry, 'mail')),
        'upn' => trim(ldap_attr_first($entry, 'userprincipalname')),
        'dn' => (string)($entry['dn'] ?? ''),
        'groups' => $groups,
        'sector' => ldap_sector_from_groups($groups),
        'disabled' => ($uac & 2) === 2,
        'is_admin_group' => ldap_in_group($groups, ldap_cfg()['admin_groups']),
    ];
}

function ldap_find_user($conn, string $username): ?array {
    $cfg = ldap_cfg();
    $filter = str_replace('{username}', ldap_escape($username, '', LDAP_ESCAPE_FILTER), (string)$cfg['user_filter']);
    $res = @ldap_search($conn, (string)$cfg['base_dn'], $filter, LDAP_USER_ATTRIBUTES, 0, 2, (int)$cfg['timeout']);
    if ($res === false) return null;
    $entries = @ldap_get_entries($conn, $res);
    if (!is_array($entries) || (int)($entries['count'] ?? 0) < 1) return null;
    return is_array($entries[0] ?? null) ? $entries[0] : null;
}

/** Busca o usuário com a conta de serviço (usado quando o próprio usuário não consegue ler o diretório). */
function ldap_find_user_with_service(string $username): ?array {
    if (!ldap_service_configured()) return null;
    try {
        $service = ldap_service_connect();
        $entry = ldap_find_user($service, $username);
        @ldap_unbind($service);
        return $entry;
    } catch (Throwable $e) {
        log_error('LDAP (consulta com conta de serviço): ' . $e->getMessage());
        return null;
    }
}

// ---------------------------------------------------------------------------
// Login
// ---------------------------------------------------------------------------

/**
 * Autentica o usuário no AD.
 * Retorno: ['ok'=>true, username, name, email, upn, dn, groups, sector, is_admin_group, groups_known]
 *       ou ['ok'=>false, code, error]. Códigos: disabled, no_extension, empty, invalid, unreachable, error.
 */
function ldap_authenticate(string $username, string $password): array {
    $cfg = ldap_cfg();
    if (!$cfg['enabled']) return ldap_fail('disabled', 'LDAP desativado.');
    if (!ldap_extension_loaded()) return ldap_fail('no_extension', 'A extensão LDAP do PHP não está habilitada neste servidor.');
    $u = normalize_ldap_username($username);
    if ($u === '' || $password === '') return ldap_fail('empty', 'Informe usuário e senha.');
    // Senha com NUL seria truncada pela biblioteca (viraria "bind anônimo"/senha parcial).
    if (str_contains($password, "\0") || strlen($password) > 256) return ldap_fail('invalid', LDAP_AD_FINAL_ERRORS['52e']);

    $conn = null;
    try {
        $last = null;
        foreach (ldap_user_bind_candidates($u) as $account) {
            $c = ldap_open();
            $r = ldap_bind_attempt($c, $account, $password);
            if ($r['ok']) { $conn = $c; break; }
            @ldap_unbind($c);
            $last = $r;
            if (ldap_is_final_failure($r)) break;
        }

        $entry = null;
        if ($conn === null) {
            if (($last['code'] ?? 0) === -1) return ldap_fail('unreachable', ldap_failure_text($last));
            if ($last !== null && ldap_is_final_failure($last)) return ldap_fail('invalid', ldap_failure_text($last));

            // Nenhum formato de login funcionou (ex.: UPN diferente do domínio). Se houver conta de serviço,
            // localiza o DN/UPN real do usuário e valida a senha por eles.
            if (!ldap_service_configured()) return ldap_fail('invalid', LDAP_AD_FINAL_ERRORS['52e']);
            $service = ldap_service_connect();
            $found = ldap_find_user($service, $u);
            @ldap_unbind($service);
            if ($found === null) return ldap_fail('invalid', LDAP_AD_FINAL_ERRORS['52e']);
            $foundInfo = ldap_entry_info($found);
            if ($foundInfo['disabled']) return ldap_fail('invalid', LDAP_AD_FINAL_ERRORS['533']);
            foreach (array_values(array_filter(array_unique([$foundInfo['dn'], $foundInfo['upn']]))) as $account) {
                $c = ldap_open();
                $r = ldap_bind_attempt($c, $account, $password);
                if ($r['ok']) { $conn = $c; break; }
                @ldap_unbind($c);
                $last = $r;
                if (ldap_is_final_failure($r)) break;
            }
            if ($conn === null) return ldap_fail('invalid', $last !== null && ldap_is_final_failure($last) ? ldap_failure_text($last) : LDAP_AD_FINAL_ERRORS['52e']);
            $entry = $found;
        }

        // Senha validada. Agora lê nome/e-mail/grupos (primeiro com o próprio usuário, depois com a conta de serviço).
        if ($entry === null) $entry = ldap_find_user($conn, $u);
        if ($entry === null) $entry = ldap_find_user_with_service($u);
        @ldap_unbind($conn);
        $conn = null;

        if ($entry === null) {
            // Login válido, mas sem acesso de leitura ao diretório: entra com o mínimo, sem decidir perfil por grupo.
            return [
                'ok' => true, 'code' => 'ok', 'error' => '', 'username' => $u, 'name' => $u, 'email' => '', 'upn' => '',
                'dn' => '', 'groups' => [], 'sector' => null, 'disabled' => false, 'is_admin_group' => false, 'groups_known' => false,
            ];
        }
        $info = ldap_entry_info($entry);
        if ($info['username'] === '') $info['username'] = $u;
        if ($info['disabled']) return ldap_fail('invalid', LDAP_AD_FINAL_ERRORS['533']);
        return ['ok' => true, 'code' => 'ok', 'error' => ''] + $info + ['groups_known' => true];
    } catch (Throwable $e) {
        if ($conn) @ldap_unbind($conn);
        log_error('LDAP (login): ' . $e->getMessage());
        return ldap_fail('error', 'Falha ao comunicar com o Active Directory.');
    }
}

// ---------------------------------------------------------------------------
// Busca paginada (o AD limita 1000 resultados por consulta sem paginação)
// ---------------------------------------------------------------------------

function ldap_search_paged($conn, string $base, string $filter, array $attributes, callable $onEntry): void {
    $size = (int)ldap_cfg()['page_size'];
    if (!defined('LDAP_CONTROL_PAGEDRESULTS')) {
        $res = @ldap_search($conn, $base, $filter, $attributes, 0, 0, 0);
        if ($res === false) throw new RuntimeException('Falha ao consultar o Active Directory: ' . ldap_error($conn));
        $entries = ldap_get_entries($conn, $res);
        for ($i = 0; $i < (int)($entries['count'] ?? 0); $i++) $onEntry($entries[$i]);
        return;
    }
    $cookie = '';
    do {
        $controls = [['oid' => LDAP_CONTROL_PAGEDRESULTS, 'iscritical' => true, 'value' => ['size' => $size, 'cookie' => $cookie]]];
        $res = @ldap_search($conn, $base, $filter, $attributes, 0, 0, 0, LDAP_DEREF_NEVER, $controls);
        if ($res === false) throw new RuntimeException('Falha ao consultar o Active Directory: ' . ldap_error($conn));
        $entries = ldap_get_entries($conn, $res);
        for ($i = 0; $i < (int)($entries['count'] ?? 0); $i++) $onEntry($entries[$i]);
        $errCode = 0; $matched = ''; $errMsg = ''; $referrals = []; $responseControls = [];
        if (!@ldap_parse_result($conn, $res, $errCode, $matched, $errMsg, $referrals, $responseControls)) {
            throw new RuntimeException('Resposta inválida do Active Directory durante a paginação.');
        }
        $cookie = (string)($responseControls[LDAP_CONTROL_PAGEDRESULTS]['value']['cookie'] ?? '');
        @ldap_free_result($res);
    } while ($cookie !== '');
}

/** Todos os usuários (pessoas) do AD, já interpretados. Contas de computador ("$") são descartadas. */
function ldap_fetch_all_users(): array {
    $service = ldap_service_connect();
    $users = [];
    try {
        ldap_search_paged(
            $service,
            (string)ldap_cfg()['base_dn'],
            '(&(objectCategory=person)(objectClass=user)(sAMAccountName=*))',
            LDAP_USER_ATTRIBUTES,
            function (array $entry) use (&$users) {
                $info = ldap_entry_info($entry);
                if ($info['username'] === '' || str_ends_with($info['username'], '$')) return;
                $users[] = $info;
            }
        );
    } finally {
        @ldap_unbind($service);
    }
    return $users;
}

// ---------------------------------------------------------------------------
// Diagnóstico (tela Configurações e instalar.bat)
// ---------------------------------------------------------------------------

function ldap_diagnose(): array {
    $cfg = ldap_cfg();
    $checks = [];
    $add = function (string $label, bool $ok, string $detail = '') use (&$checks): bool {
        $checks[] = ['label' => $label, 'ok' => $ok, 'detail' => $detail];
        return $ok;
    };
    $result = function (bool $ok, string $message) use (&$checks): array {
        return ['ok' => $ok, 'message' => $message, 'checks' => $checks];
    };

    if (!$add('LDAP habilitado na configuração', (bool)$cfg['enabled'], $cfg['enabled'] ? '' : 'CEN_AGENDA_LDAP_ENABLED está desativado.')) {
        return $result(false, 'LDAP está desativado.');
    }
    $ext = ldap_extension_loaded();
    if (!$add('Extensão LDAP do PHP', $ext, $ext ? '' : 'Execute instalar.bat e reinicie a Cen Agenda.')) {
        return $result(false, 'A extensão LDAP do PHP não está habilitada.');
    }
    $configured = ldap_service_configured();
    if (!$add('Conta de serviço configurada', $configured, $configured ? (string)$cfg['bind_user'] : 'Preencha CEN_AGENDA_LDAP_BIND_PASSWORD no .env.')) {
        return $result(false, 'Conta de serviço LDAP sem senha configurada.');
    }

    try {
        $conn = ldap_service_connect();
    } catch (Throwable $e) {
        $add('Conexão e autenticação da conta de serviço', false, $e->getMessage());
        return $result(false, $e->getMessage());
    }
    $add('Conexão e autenticação da conta de serviço', true, ldap_uri());

    $read = @ldap_read($conn, (string)$cfg['base_dn'], '(objectClass=*)', ['distinguishedName'], 0, 1, (int)$cfg['timeout']);
    $baseOk = $read !== false;
    $add('Base DN acessível', $baseOk, $baseOk ? (string)$cfg['base_dn'] : 'Verifique CEN_AGENDA_LDAP_BASE_DN (' . $cfg['base_dn'] . ').');

    $adminOk = true;
    foreach ($cfg['admin_groups'] as $group) {
        $filter = '(&(objectCategory=group)(cn=' . ldap_escape((string)$group, '', LDAP_ESCAPE_FILTER) . '))';
        $s = $baseOk ? @ldap_search($conn, (string)$cfg['base_dn'], $filter, ['cn'], 0, 1, (int)$cfg['timeout']) : false;
        $found = $s !== false && (int)ldap_count_entries($conn, $s) > 0;
        if (!$found) $adminOk = false;
        $add('Grupo de administradores "' . $group . '"', $found, $found ? '' : 'Grupo não encontrado: ninguém será promovido a administrador pelo AD.');
    }
    @ldap_unbind($conn);

    $ok = $baseOk && $adminOk;
    return $result($ok, $ok ? 'Conexão com o Active Directory validada.' : 'Conexão feita, mas há itens para corrigir.');
}

/** Compatibilidade: resumo simples do diagnóstico. */
function ldap_test_connection(): array {
    $d = ldap_diagnose();
    $cfg = ldap_cfg();
    return $d + ['server' => $cfg['server'], 'domain' => $cfg['domain']];
}
