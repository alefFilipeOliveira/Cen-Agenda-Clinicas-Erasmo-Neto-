<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

/**
 * Configuração do Active Directory — mesmos valores e mesma lógica da Intranet Erasmo.
 * Lê CEN_AGENDA_LDAP_* e cai para INTRANET_LDAP_* quando a variável não existir,
 * então o mesmo .env da Intranet pode ser reaproveitado.
 */
function ldap_env(string $key, string $fallbackKey, string $default = ''): string {
    $v = getenv($key);
    if ($v !== false && trim((string)$v) !== '') return trim((string)$v);
    $v = getenv($fallbackKey);
    if ($v !== false && trim((string)$v) !== '') return trim((string)$v);
    return $default;
}

/** Lista separada por ";" ou "|" (nomes de grupo do AD podem ter vírgula e espaços). */
function ldap_env_list(string $key, string $fallbackKey, string $default = ''): array {
    $raw = ldap_env($key, $fallbackKey, $default);
    $items = preg_split('/[;|]/', $raw) ?: [];
    return array_values(array_filter(array_map('trim', $items), fn($v) => $v !== ''));
}

function ldap_cfg(): array {
    static $cfg = null;
    if ($cfg !== null) return $cfg;

    $ssl = env_bool(ldap_env('CEN_AGENDA_LDAP_USE_SSL', 'INTRANET_LDAP_USE_SSL', 'false'));
    $domain = ldap_env('CEN_AGENDA_LDAP_DOMAIN', 'INTRANET_LDAP_DOMAIN', 'cen.local');
    $baseDn = ldap_env('CEN_AGENDA_LDAP_BASE_DN', 'INTRANET_LDAP_BASE_DN', '');
    if ($baseDn === '') $baseDn = 'DC=' . str_replace('.', ',DC=', $domain);

    $cfg = [
        'enabled'        => env_bool(ldap_env('CEN_AGENDA_LDAP_ENABLED', 'INTRANET_LDAP_ENABLED', 'true'), true),
        'server'         => ldap_env('CEN_AGENDA_LDAP_SERVER', 'INTRANET_LDAP_SERVER', '192.168.52.250'),
        'server_name'    => ldap_env('CEN_AGENDA_LDAP_SERVER_NAME', 'INTRANET_LDAP_SERVER_NAME', 'Server-S01'),
        'domain'         => $domain,
        'netbios'        => ldap_env('CEN_AGENDA_LDAP_NETBIOS_DOMAIN', 'INTRANET_LDAP_NETBIOS_DOMAIN', 'CEN'),
        'base_dn'        => $baseDn,
        'bind_user'      => ldap_env('CEN_AGENDA_LDAP_BIND_USER', 'INTRANET_LDAP_BIND_USER', 'intranet@cen.local'),
        'bind_password'  => ldap_env('CEN_AGENDA_LDAP_BIND_PASSWORD', 'INTRANET_LDAP_BIND_PASSWORD', ''),
        'use_ssl'        => $ssl,
        'port'           => (int)ldap_env('CEN_AGENDA_LDAP_PORT', 'INTRANET_LDAP_PORT', $ssl ? '636' : '389'),
        // Em LDAPS com certificado interno/autoassinado, defina CEN_AGENDA_LDAP_TLS_VERIFY=false.
        'tls_verify'     => env_bool(ldap_env('CEN_AGENDA_LDAP_TLS_VERIFY', 'INTRANET_LDAP_TLS_VERIFY', 'true'), true),
        'timeout'        => max(2, min(60, (int)ldap_env('CEN_AGENDA_LDAP_TIMEOUT', 'INTRANET_LDAP_TIMEOUT', '8'))),
        'page_size'      => 500,
        'login_attribute' => 'sAMAccountName',
        'user_filter'    => '(sAMAccountName={username})',
        'group_attribute' => 'memberOf',
        // Mais de um grupo pode ser informado separando por ";".
        'admin_groups'   => ldap_env_list('CEN_AGENDA_LDAP_ADMIN_GROUP', 'INTRANET_LDAP_ADMIN_GROUP', 'Admins. do domínio'),
        // O AD só identifica o usuário e informa os grupos (mesmo mapa da Intranet).
        // A Cen Agenda não cria menu de setores: isto fica no cadastro para auditoria/integração.
        'sector_groups'  => [
            'marcacao'      => ['Marcacao', 'Marcação'],
            'faturamento'   => ['Faturamento'],
            'financeiro'    => ['Financeiro'],
            'apoio'         => ['Apoio'],
            'recepcao'      => ['Recepcao', 'Recepção'],
            'conferencia'   => ['Conferencia', 'Conferência'],
            'nacen'         => ['Nacen'],
            'profissionais' => ['Profissionais'],
            'ti'            => ['TI', 'Glpi-Atendente-TI', 'Suporte_AD', 'NTFS_EN_TI_WR', 'NTFS_ALL_BACKUP'],
        ],
    ];
    return $cfg;
}
