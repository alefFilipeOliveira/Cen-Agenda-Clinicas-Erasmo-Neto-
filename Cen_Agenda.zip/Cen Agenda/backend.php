<?php
declare(strict_types=1);

/**
 * Biblioteca da Cen Agenda (sem efeitos colaterais ao ser incluída).
 * As rotas da API ficam em api_routes.php; os scripts de linha de comando
 * (tools/*.php, testar_ldap.php) podem incluir este arquivo com segurança.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/ldap.php';
require_once __DIR__ . '/mail.php';
require_once __DIR__ . '/backup.php';

const LOCAL_ACCOUNT_SUFFIX = '@cenagenda.local';
const LOGIN_USER_MAX_FAILS = 5;     // falhas por usuário na janela
const LOGIN_IP_MAX_FAILS = 30;      // falhas por IP na janela
const LOGIN_WINDOW_SECONDS = 600;
const LOGIN_LOCK_SECONDS = 300;
const WEAK_PASSWORDS = ['admin123', '123456', '12345678', 'password', 'senha123', 'cenagenda', 'admin1234'];

final class ApiError extends RuntimeException {
    public int $status;
    public string $errorCode;
    public function __construct(string $message, int $status = 400, string $errorCode = '') {
        parent::__construct($message);
        $this->status = $status;
        $this->errorCode = $errorCode;
    }
}

// ---------------------------------------------------------------------------
// HTTP / sessão / CSRF
// ---------------------------------------------------------------------------

function is_https(): bool {
    return !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
}

function send_security_headers(): void {
    if (headers_sent()) return;
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: same-origin');
}

function start_app_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.gc_maxlifetime', (string)SESSION_IDLE_SECONDS);
    session_name(SESSION_NAME);
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'secure' => is_https(),
        'samesite' => 'Lax',
    ]);
    session_start();
}

function csrf_token(): string {
    if (empty($_SESSION['csrf']) || !is_string($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

/** Toda requisição que altera dados precisa mandar o token no cabeçalho X-CSRF-Token. */
function csrf_verify(): void {
    $sent = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if ($sent === '' || !hash_equals(csrf_token(), $sent)) {
        throw new ApiError('Sessão expirada. A página será recarregada.', 419, 'csrf');
    }
}

function client_ip(): string {
    return (string)($_SERVER['REMOTE_ADDR'] ?? 'desconhecido');
}

function request_method(): string {
    return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
}

function json_response(array $payload, int $status = 200): never {
    http_response_code($status);
    send_security_headers();
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function input_json(int $maxBytes = 262144): array {
    $raw = file_get_contents('php://input', false, null, 0, $maxBytes);
    if ($raw === false || $raw === '') return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

// ---------------------------------------------------------------------------
// Utilidades
// ---------------------------------------------------------------------------

function cut_text(string $s, int $max): string {
    return function_exists('mb_substr') ? mb_substr($s, 0, $max, 'UTF-8') : substr($s, 0, $max);
}

function clean_text($v, int $max = 5000): string {
    return cut_text(trim((string)($v ?? '')), $max);
}

function valid_date(string $s): bool {
    $d = DateTime::createFromFormat('Y-m-d', $s);
    return $d !== false && $d->format('Y-m-d') === $s;
}

function valid_time(string $s): bool {
    return (bool)preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $s);
}

function normalize_color(string $color): string {
    return preg_match('/^#[0-9A-Fa-f]{6}$/', $color) ? strtoupper($color) : '#3156D8';
}

// ---------------------------------------------------------------------------
// Auditoria de login (arquivo à parte: tentativas falhas não poluem o histórico do sistema)
// ---------------------------------------------------------------------------

function auth_log(string $event, array $ctx = []): void {
    if (!is_dir(LOG_DIR)) @mkdir(LOG_DIR, 0775, true);
    $file = LOG_DIR . DIRECTORY_SEPARATOR . 'auth.log';
    if (is_file($file) && (int)@filesize($file) > 1048576) {
        @unlink($file . '.1');
        @rename($file, $file . '.1');
    }
    $line = '[' . date('c') . '] ' . $event . ' ' . json_encode($ctx, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . PHP_EOL;
    @file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
}

// ---------------------------------------------------------------------------
// Limite de tentativas de login (protege também as contas do AD contra bloqueio por força bruta)
// ---------------------------------------------------------------------------

function throttle_mutate(callable $fn) {
    ensure_storage();
    $data = [];
    $fp = @fopen(dirname(DATA_FILE) . DIRECTORY_SEPARATOR . 'login_attempts.json', 'c+');
    if (!$fp) return $fn($data);
    try {
        flock($fp, LOCK_EX);
        rewind($fp);
        $decoded = json_decode((string)stream_get_contents($fp), true);
        if (is_array($decoded)) $data = $decoded;
        $now = time();
        foreach ($data as $k => $v) {
            if ((int)($v['locked_until'] ?? 0) < $now && (int)($v['first'] ?? 0) < $now - LOGIN_WINDOW_SECONDS) unset($data[$k]);
        }
        $result = $fn($data);
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, (string)json_encode($data));
        fflush($fp);
        return $result;
    } finally {
        @flock($fp, LOCK_UN);
        fclose($fp);
    }
}

function login_throttle_remaining(string $username, string $ip): int {
    return (int)throttle_mutate(function (array &$d) use ($username, $ip) {
        $now = time();
        $remaining = 0;
        foreach (['u:' . sha1($username), 'i:' . $ip] as $key) {
            $until = (int)($d[$key]['locked_until'] ?? 0);
            if ($until > $now) $remaining = max($remaining, $until - $now);
        }
        return $remaining;
    });
}

function login_register_failure(string $username, string $ip): void {
    throttle_mutate(function (array &$d) use ($username, $ip) {
        $now = time();
        foreach ([['u:' . sha1($username), LOGIN_USER_MAX_FAILS], ['i:' . $ip, LOGIN_IP_MAX_FAILS]] as [$key, $max]) {
            $e = $d[$key] ?? ['fails' => 0, 'first' => $now, 'locked_until' => 0];
            if ($now - (int)$e['first'] > LOGIN_WINDOW_SECONDS) $e = ['fails' => 0, 'first' => $now, 'locked_until' => 0];
            $e['fails'] = (int)$e['fails'] + 1;
            if ($e['fails'] >= $max) {
                $e['locked_until'] = $now + LOGIN_LOCK_SECONDS;
                $e['fails'] = 0;
                $e['first'] = $now;
            }
            $d[$key] = $e;
        }
        return null;
    });
}

function login_register_success(string $username): void {
    throttle_mutate(function (array &$d) use ($username) {
        unset($d['u:' . sha1($username)]);
        return null;
    });
}

// ---------------------------------------------------------------------------
// Usuários
// ---------------------------------------------------------------------------

function find_user_index(array $store, string $username): ?int {
    foreach ($store['users'] as $i => $u) {
        if (($u['username'] ?? '') === $username) return (int)$i;
    }
    return null;
}

function find_user_index_by_id(array $store, string $id): ?int {
    foreach ($store['users'] as $i => $u) {
        if (($u['id'] ?? '') === $id) return (int)$i;
    }
    return null;
}

function public_user(array $u): array {
    return [
        'id' => $u['id'],
        'username' => $u['username'],
        'name' => $u['name'],
        'email' => $u['email'] ?? '',
        'profile' => $u['profile'] ?? 'user',
        'source' => $u['source'] ?? 'local',
        'sector' => $u['sector'] ?? null,
        'coordinator' => !empty($u['coordinator']),
        'must_change_password' => !empty($u['must_change_password']),
    ];
}

/** Visão do cadastro para o painel do administrador (nunca inclui hash de senha). */
function admin_user_view(array $u): array {
    return public_user($u) + [
        'active' => !empty($u['active']),
        'ldap_groups' => array_values($u['ldap_groups'] ?? []),
        'email_manual' => (string)($u['email_manual'] ?? ''),
        'mail_effective' => user_mail($u),
        'ad_disabled' => !empty($u['ad_disabled']),
        'ad_missing' => !empty($u['ad_missing']),
        'profile_source' => $u['profile_source'] ?? 'manual',
        'last_login' => $u['last_login'] ?? null,
        'created_at' => $u['created_at'] ?? null,
    ];
}

/**
 * Usuário da sessão, sempre recarregado do cadastro: se o administrador desativar ou rebaixar
 * alguém, vale na próxima requisição (antes a sessão guardava uma cópia antiga do perfil).
 */
function current_user(): ?array {
    static $cache = false;
    if ($cache !== false) return $cache;
    $uid = $_SESSION['uid'] ?? null;
    if (!is_string($uid) || $uid === '') return $cache = null;
    $now = time();
    if ($now - (int)($_SESSION['last_seen'] ?? 0) > SESSION_IDLE_SECONDS || $now - (int)($_SESSION['login_at'] ?? 0) > SESSION_ABSOLUTE_SECONDS) {
        unset($_SESSION['uid'], $_SESSION['login_at'], $_SESSION['last_seen']);
        return $cache = null;
    }
    $store = json_read();
    $i = find_user_index_by_id($store, $uid);
    if ($i === null || empty($store['users'][$i]['active'])) {
        unset($_SESSION['uid'], $_SESSION['login_at'], $_SESSION['last_seen']);
        return $cache = null;
    }
    $_SESSION['last_seen'] = $now;
    return $cache = public_user($store['users'][$i]);
}

function begin_session_for(array $user): void {
    session_regenerate_id(true); // evita fixação de sessão
    $_SESSION['uid'] = $user['id'];
    $_SESSION['login_at'] = time();
    $_SESSION['last_seen'] = time();
}

function require_login(bool $allowMustChange = false): array {
    $u = current_user();
    if (!$u) throw new ApiError('Sessão não autenticada.', 401, 'auth');
    if (!$allowMustChange && !empty($u['must_change_password'])) {
        throw new ApiError('Defina uma nova senha para continuar.', 403, 'must_change_password');
    }
    return $u;
}

function require_admin(): array {
    $u = require_login();
    if (($u['profile'] ?? 'user') !== 'admin') throw new ApiError('Acesso exclusivo do administrador.', 403);
    return $u;
}

function is_local_account_name(string $username): bool {
    return str_ends_with(strtolower(trim($username)), LOCAL_ACCOUNT_SUFFIX);
}

/**
 * Cria/atualiza o cadastro de um usuário do AD no login.
 * - Primeiro login: cria o usuário (admin se estiver no grupo de administradores).
 * - Depois: atualiza nome/e-mail/grupos. Status (ativo/inativo) nunca é alterado pelo AD.
 * - Perfil: acompanha o grupo do AD enquanto não for definido manualmente no painel; depois de
 *   definido manualmente pelo administrador, o AD não sobrescreve mais (como na Intranet).
 */
/** Setor vindo do AD, descartando os que o administrador excluiu da agenda. */
function sector_clean(array $s, $sector): ?string {
    if ($sector === null || $sector === '') return null;
    foreach ($s['settings']['sectors_deleted'] ?? [] as $d) if (strcasecmp((string)$d, (string)$sector) === 0) return null;
    return (string)$sector;
}

function upsert_user_from_login(array $info): array {
    $username = normalize_ldap_username((string)($info['username'] ?? ''));
    if ($username === '') throw new ApiError('Usuário inválido.', 422);
    $name = clean_text($info['name'] ?? $username, 200);
    if ($name === '') $name = $username;
    $email = clean_text($info['email'] ?? '', 320);
    $groups = array_values(array_map('strval', $info['groups'] ?? []));
    $known = !empty($info['groups_known']);
    $adAdmin = $known && !empty($info['is_admin_group']);
    $sector = $info['sector'] ?? null;
    $result = null;

    json_update(function (array $s) use ($username, $name, $email, $groups, $known, $adAdmin, $sector, &$result) {
        $idx = find_user_index($s, $username);
        $now = date('c');
        if ($idx === null) {
            $user = [
                'id' => bin2hex(random_bytes(8)),
                'username' => $username,
                'name' => $name,
                'email' => $email,
                'profile' => $adAdmin ? 'admin' : 'user',
                'profile_source' => 'ad',
                'active' => true,
                'source' => 'ldap',
                'ldap_groups' => $groups,
                'sector' => sector_clean($s, $sector),
                'ad_disabled' => false,
                'created_at' => $now,
                'updated_at' => $now,
                'last_login' => $now,
            ];
            $s['users'][] = $user;
            $result = $user;
            return $s;
        }
        $u = $s['users'][$idx];
        if (($u['source'] ?? '') !== 'ldap') throw new ApiError('Esta conta é local e não pode entrar pelo Active Directory.', 403);
        $u['name'] = $name;
        $u['email'] = $email;
        if ($known) {
            $u['ldap_groups'] = $groups;
            if (($u['sector_source'] ?? '') !== 'manual') $u['sector'] = sector_clean($s, $sector);
            if (($u['profile_source'] ?? 'manual') === 'ad') $u['profile'] = $adAdmin ? 'admin' : 'user';
        }
        $u['ad_disabled'] = false;
        $u['ad_missing'] = false;
        $u['updated_at'] = $now;
        $u['last_login'] = $now;
        $s['users'][$idx] = $u;
        $result = $u;
        return $s;
    });
    return $result;
}

/** Importa/atualiza usuários do AD. Nunca ativa/desativa nem rebaixa quem teve o perfil definido manualmente. */
function sync_ldap_users(array $actor): array {
    $fetched = ldap_fetch_all_users();
    $adminGroups = ldap_cfg()['admin_groups'];
    $created = 0; $updated = 0; $ignored = 0; $disabled = 0; $missing = 0;

    json_update(function (array $s) use ($fetched, $adminGroups, $actor, &$created, &$updated, &$ignored, &$disabled, &$missing) {
        $now = date('c');
        $index = [];
        foreach ($s['users'] as $i => $u) $index[(string)($u['username'] ?? '')] = $i;
        $seen = [];

        foreach ($fetched as $info) {
            $username = $info['username'];
            $adAdmin = ldap_in_group($info['groups'], $adminGroups);
            $i = $index[$username] ?? null;
            if ($i === null) {
                if ($info['disabled']) { $ignored++; continue; }   // conta desativada no AD não é importada
                $s['users'][] = [
                    'id' => bin2hex(random_bytes(8)),
                    'username' => $username,
                    'name' => $info['name'],
                    'email' => $info['email'],
                    'profile' => $adAdmin ? 'admin' : 'user',
                    'profile_source' => 'ad',
                    'active' => true,
                    'source' => 'ldap',
                    'ldap_groups' => $info['groups'],
                    'sector' => sector_clean($s, $info['sector']),
                    'ad_disabled' => false,
                    'created_at' => $now,
                    'updated_at' => $now,
                ];
                $index[$username] = count($s['users']) - 1;
                $seen[$username] = true;
                $created++;
                continue;
            }
            $u = $s['users'][$i];
            if (($u['source'] ?? '') !== 'ldap') { $ignored++; continue; }
            $u['name'] = $info['name'];
            $u['email'] = $info['email'];
            $u['ldap_groups'] = $info['groups'];
            if (($u['sector_source'] ?? '') !== 'manual') $u['sector'] = sector_clean($s, $info['sector']);
            $u['ad_disabled'] = $info['disabled'];
            $u['ad_missing'] = false;
            if (($u['profile_source'] ?? 'manual') === 'ad') $u['profile'] = $adAdmin ? 'admin' : 'user';
            $u['updated_at'] = $now;
            if ($info['disabled']) $disabled++;
            $s['users'][$i] = $u;
            $seen[$username] = true;
            $updated++;
        }

        // Usuários que existiam no cadastro mas não aparecem mais no AD: apenas sinalizados.
        foreach ($s['users'] as $i => $u) {
            if (($u['source'] ?? '') === 'ldap' && !isset($seen[(string)($u['username'] ?? '')])) {
                $s['users'][$i]['ad_missing'] = true;
                $missing++;
            }
        }
        $s['meta']['last_ldap_sync'] = [
            'at' => $now,
            'by' => $actor['username'] ?? 'system',
            'total' => count($fetched),
            'created' => $created,
            'updated' => $updated,
            'ignored' => $ignored,
            'disabled' => $disabled,
            'missing' => $missing,
        ];
        return $s;
    });

    return ['created' => $created, 'updated' => $updated, 'ignored' => $ignored, 'disabled' => $disabled, 'missing' => $missing, 'total' => count($fetched)];
}

// ---------------------------------------------------------------------------
// Conta local de emergência (equivalente à conta "val" da Intranet)
// ---------------------------------------------------------------------------

function validate_new_password(string $password): void {
    if (strlen($password) < 8) throw new ApiError('A senha deve ter pelo menos 8 caracteres.', 422);
    if (in_array(strtolower($password), WEAK_PASSWORDS, true)) throw new ApiError('Escolha uma senha menos óbvia.', 422);
}

function authenticate_local(string $username, string $password): ?array {
    $store = json_read();
    $i = find_user_index($store, strtolower(trim($username)));
    if ($i === null) return null;
    $u = $store['users'][$i];
    if (($u['source'] ?? '') !== 'local' || empty($u['active'])) return null;
    $hash = (string)($u['password_hash'] ?? '');
    if ($hash === '' || !password_verify($password, $hash)) return null;
    return $u;
}

function create_or_reset_local_admin(string $username, string $name, string $password): array {
    $username = strtolower(trim($username));
    if (!is_local_account_name($username) || strlen($username) <= strlen(LOCAL_ACCOUNT_SUFFIX)) {
        throw new ApiError('O usuário local deve terminar com ' . LOCAL_ACCOUNT_SUFFIX . '.', 422);
    }
    validate_new_password($password);
    $created = false;
    json_update(function (array $s) use ($username, $name, $password, &$created) {
        $now = date('c');
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $idx = find_user_index($s, $username);
        if ($idx === null) {
            $s['users'][] = [
                'id' => bin2hex(random_bytes(8)), 'username' => $username, 'name' => $name, 'email' => $username,
                'profile' => 'admin', 'profile_source' => 'manual', 'active' => true, 'source' => 'local',
                'password_hash' => $hash, 'ldap_groups' => [], 'sector' => null, 'created_at' => $now, 'updated_at' => $now,
            ];
            $created = true;
            return $s;
        }
        if (($s['users'][$idx]['source'] ?? '') !== 'local') throw new ApiError('Já existe um usuário do AD com este nome.', 409);
        $s['users'][$idx]['password_hash'] = $hash;
        $s['users'][$idx]['profile'] = 'admin';
        $s['users'][$idx]['active'] = true;
        unset($s['users'][$idx]['must_change_password']);
        $s['users'][$idx]['updated_at'] = $now;
        return $s;
    });
    return ['username' => $username, 'created' => $created];
}

function count_active_local_admins(): int {
    $n = 0;
    foreach (json_read()['users'] as $u) {
        if (($u['source'] ?? '') === 'local' && ($u['profile'] ?? '') === 'admin' && !empty($u['active'])) $n++;
    }
    return $n;
}

/**
 * Migração para a versão 3 do armazenamento: as contas de demonstração das versões
 * anteriores (admin123 / 123456) são removidas ou obrigadas a trocar a senha.
 */
function run_migrations(): void {
    $store = json_read();
    if ((int)($store['meta']['version'] ?? 0) >= STORE_VERSION) return;
    json_update(function (array $s) {
        foreach ($s['users'] as $i => $u) {
            if (($u['source'] ?? '') !== 'local') continue;
            $hash = (string)($u['password_hash'] ?? '');
            if ($hash === '') continue;
            if (($u['username'] ?? '') === 'usuario@cenagenda.local' && password_verify('123456', $hash)) {
                unset($s['users'][$i]);
                continue;
            }
            if (password_verify('admin123', $hash) || password_verify('123456', $hash)) {
                $s['users'][$i]['must_change_password'] = true;
            }
        }
        $s['users'] = array_values($s['users']);
        $s['meta']['version'] = STORE_VERSION;
        $s['meta']['migrated_at'] = date('c');
        return $s;
    });
}

// ---------------------------------------------------------------------------
// Eventos
// ---------------------------------------------------------------------------

function add_months(DateTimeImmutable $d, int $months): DateTimeImmutable {
    $total = ((int)$d->format('Y')) * 12 + ((int)$d->format('n') - 1) + $months;
    $year = intdiv($total, 12);
    $month = $total % 12 + 1;
    $lastDay = (int)(new DateTimeImmutable(sprintf('%04d-%02d-01', $year, $month)))->format('t');
    return $d->setDate($year, $month, min((int)$d->format('j'), $lastDay)); // 31/jan + 1 mês = 28/fev (não 3/mar)
}

function occurrence_at(DateTimeImmutable $start, string $type, int $interval, int $k): DateTimeImmutable {
    return match ($type) {
        'daily' => $start->modify('+' . ($k * $interval) . ' days'),
        'weekly' => $start->modify('+' . ($k * $interval * 7) . ' days'),
        'monthly' => add_months($start, $k * $interval),
        default => add_months($start, 12 * $k * $interval),
    };
}

function event_occurrences(array $event, DateTimeImmutable $from, DateTimeImmutable $to): array {
    $start = new DateTimeImmutable($event['start']);
    $end = new DateTimeImmutable($event['end']);
    $duration = max(0, $end->getTimestamp() - $start->getTimestamp());
    $rec = $event['recurrence'] ?? null;
    $type = is_array($rec) ? (string)($rec['type'] ?? 'none') : 'none';
    $out = [];

    if (!in_array($type, ['daily', 'weekly', 'monthly', 'yearly'], true)) {
        if ($end > $from && $start < $to) {
            $out[] = $event + ['occurrence_start' => $event['start'], 'occurrence_end' => $event['end']];
        }
        return $out;
    }

    $interval = max(1, (int)($rec['interval'] ?? 1));
    $until = (!empty($rec['until']) && valid_date((string)$rec['until'])) ? new DateTimeImmutable($rec['until'] . ' 23:59') : $to;
    $limit = $until < $to ? $until : $to;

    // Salta direto para perto do período consultado (antes só olhava as primeiras 500 repetições,
    // então um evento diário com mais de ~16 meses sumia do calendário).
    $k = 0;
    $diffSeconds = $from->getTimestamp() - $start->getTimestamp();
    if ($diffSeconds > 0) {
        if ($type === 'daily') {
            $k = max(0, intdiv(intdiv($diffSeconds, 86400), $interval) - 1);
        } elseif ($type === 'weekly') {
            $k = max(0, intdiv(intdiv($diffSeconds, 86400 * 7), $interval) - 1);
        } elseif ($type === 'monthly') {
            $months = ((int)$from->format('Y') - (int)$start->format('Y')) * 12 + ((int)$from->format('n') - (int)$start->format('n'));
            $k = max(0, intdiv($months, $interval) - 1);
        } else {
            $k = max(0, intdiv((int)$from->format('Y') - (int)$start->format('Y'), $interval) - 1);
        }
    }

    for ($guard = 0; $guard < 1000; $guard++, $k++) {
        $cursor = occurrence_at($start, $type, $interval, $k);
        if ($cursor > $limit) break;
        $occEnd = $cursor->modify('+' . $duration . ' seconds');
        if ($occEnd > $from) {
            $out[] = $event + ['occurrence_start' => $cursor->format('Y-m-d H:i'), 'occurrence_end' => $occEnd->format('Y-m-d H:i')];
        }
    }
    return $out;
}

/** Valida os dados do formulário de evento. Em edição, campos ausentes herdam os do evento atual. */
function parse_event_input(array $in, ?array $base = null): array {
    $date = clean_text($in['date'] ?? ($base ? substr((string)$base['start'], 0, 10) : ''), 10);
    $start = clean_text($in['start'] ?? ($base ? substr((string)$base['start'], 11, 5) : ''), 5);
    $end = clean_text($in['end'] ?? ($base ? substr((string)$base['end'], 11, 5) : ''), 5);
    $title = clean_text($in['title'] ?? ($base['title'] ?? ''), 200);
    if ($title === '' || !valid_date($date) || !valid_time($start) || !valid_time($end)) {
        throw new ApiError('Preencha nome, data e horários corretamente.', 422);
    }
    $startDT = DateTimeImmutable::createFromFormat('Y-m-d H:i', $date . ' ' . $start);
    $endDT = DateTimeImmutable::createFromFormat('Y-m-d H:i', $date . ' ' . $end);
    if (!$startDT || !$endDT || $endDT <= $startDT) throw new ApiError('O horário final precisa ser maior que o horário inicial.', 422);

    $baseRec = is_array($base['recurrence'] ?? null) ? $base['recurrence'] : [];
    $recType = (string)($in['recurrence_type'] ?? ($baseRec['type'] ?? 'none'));
    if (!in_array($recType, ['none', 'daily', 'weekly', 'monthly', 'yearly'], true)) $recType = 'none';
    $recurrence = null;
    if ($recType !== 'none') {
        $untilRaw = (string)($in['recurrence_until'] ?? ($baseRec['until'] ?? ''));
        $recurrence = [
            'type' => $recType,
            'interval' => max(1, min(365, (int)($in['recurrence_interval'] ?? ($baseRec['interval'] ?? 1)))),
            'until' => valid_date($untilRaw) ? $untilRaw : null,
        ];
    }

    return [
        'title' => $title,
        'start' => $date . ' ' . $start,
        'end' => $date . ' ' . $end,
        'location' => clean_text($in['location'] ?? ($base['location'] ?? ''), 200),
        'description' => clean_text($in['description'] ?? ($base['description'] ?? ''), 5000),
        'color' => normalize_color((string)($in['color'] ?? ($base['color'] ?? '#3156D8'))),
        'reminder_minutes' => max(0, min(10080, (int)($in['reminder_minutes'] ?? ($base['reminder_minutes'] ?? 15)))),
        'recurrence' => $recurrence,
        'notify_mode' => in_array(($nm = (string)($in['notify_mode'] ?? ($base['notify_mode'] ?? 'me'))), ['me', 'all', 'people'], true) ? $nm : 'me',
        'notify_users' => array_slice(array_values(array_unique(array_map(fn($x) => strtolower(clean_text($x, 120)), is_array($in['notify_users'] ?? null) ? $in['notify_users'] : ($base['notify_users'] ?? [])))), 0, 500),
        'notify_group' => clean_text($in['notify_group'] ?? ($base['notify_group'] ?? ''), 60),
        'notify_emails' => parse_emails($in['notify_emails'] ?? ($base['notify_emails'] ?? [])),
    ];
}
