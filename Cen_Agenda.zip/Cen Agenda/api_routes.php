<?php
declare(strict_types=1);

require_once __DIR__ . '/backend.php';

function require_post(): void {
    if (request_method() !== 'POST') throw new ApiError('Método não permitido.', 405);
    csrf_verify();
}

/** Administrador edita qualquer evento; os demais, apenas os que criaram. */
/** Só o criador enxerga quem negou o evento. */
function event_for_viewer(array $u, array $o): array {
    if (strtolower((string)($o['created_by'] ?? '')) !== strtolower((string)($u['username'] ?? ''))) unset($o['declined']);
    return $o;
}

function can_edit_event(array $u, array $e): bool {
    return ($u['profile'] ?? 'user') === 'admin' || (($e['created_by'] ?? '') !== '' && ($e['created_by'] ?? '') === ($u['username'] ?? ''));
}

/**
 * Agenda individual: cada pessoa vê os eventos que criou e aqueles em que foi mencionada
 * ("Pessoas escolhidas", ou "Todos" / setor no formato antigo). Evento sem dono (importado) continua visível a todos.
 */
function event_visible_to(array $u, array $e): bool {
    $owner = strtolower((string)($e['created_by'] ?? ''));
    if ($owner === '') return true;
    $me = strtolower((string)($u['username'] ?? ''));
    if ($me === '') return false;
    if ($owner === $me) return true;
    foreach ((array)($e['declined'] ?? []) as $d) { // quem negou o evento não o vê mais
        if (strtolower((string)($d['username'] ?? '')) === $me) return false;
    }
    $mode = (string)($e['notify_mode'] ?? '');
    $group = (string)($e['notify_group'] ?? ''); // formato antigo (v2.6)
    if ($mode === '' && $group !== '') $mode = $group === '*' ? 'all' : 'sector';
    if ($mode === 'all') return true;
    if ($mode === 'sector') return (string)($u['sector'] ?? '') === $group;
    if ($mode === 'people') return in_array($me, array_map('strtolower', (array)($e['notify_users'] ?? [])), true);
    return false;
}

function clean_list($v, int $max = 60, int $limit = 60): array {
    $out = [];
    foreach (is_array($v) ? $v : [] as $x) {
        $t = clean_text($x, $max);
        if ($t !== '' && !in_array(strtolower($t), array_map('strtolower', $out), true)) $out[] = $t;
        if (count($out) >= $limit) break;
    }
    return $out;
}

/** Mensagem segura para o usuário final quando o AD não validou o login. */
function login_error_message(array $r): string {
    return match ($r['code'] ?? '') {
        'invalid', 'empty' => (string)($r['error'] ?? 'Usuário ou senha inválidos.'),
        'disabled' => 'Usuário ou senha inválidos.',
        default => 'Não foi possível validar o login no Active Directory. Avise o TI.',
    };
}

function route_login(): never {
    require_post();
    $in = input_json();
    $raw = clean_text($in['username'] ?? '', 200);
    $password = (string)($in['password'] ?? '');
    if ($raw === '' || $password === '') throw new ApiError('Informe usuário e senha.', 422);

    $ip = client_ip();
    $key = normalize_ldap_username($raw);
    $wait = login_throttle_remaining($key, $ip);
    if ($wait > 0) {
        throw new ApiError('Muitas tentativas. Aguarde ' . (int)ceil($wait / 60) . ' minuto(s) e tente novamente.', 429, 'throttled');
    }

    $user = null;
    $source = 'ldap';
    $message = 'Usuário ou senha inválidos.';

    if (is_local_account_name($raw)) {
        // Conta local de emergência: não passa pelo AD (não gera tentativa falha em conta do domínio).
        $source = 'local';
        $user = authenticate_local($raw, $password);
    } else {
        $r = ldap_authenticate($raw, $password);
        if ($r['ok']) {
            $user = upsert_user_from_login($r);
            if (empty($user['active'])) {
                auth_log('login_blocked_inactive', ['user' => $key, 'ip' => $ip]);
                throw new ApiError('Este usuário está desativado na Cen Agenda.', 403);
            }
        } else {
            $message = login_error_message($r);
            if (!in_array($r['code'] ?? '', ['invalid', 'empty', 'disabled'], true)) {
                log_error('LDAP login indisponível (' . ($r['code'] ?? '?') . '): ' . ($r['error'] ?? ''));
            }
            // Falha de infraestrutura (AD fora do ar, extensão ausente) não deve contar contra o usuário.
            $countFailure = in_array($r['code'] ?? '', ['invalid', 'empty'], true);
            auth_log('login_failed', ['user' => $key, 'ip' => $ip, 'code' => $r['code'] ?? '']);
            if ($countFailure) login_register_failure($key, $ip);
            throw new ApiError($message, in_array($r['code'] ?? '', ['invalid', 'empty', 'disabled'], true) ? 401 : 503, 'login_failed');
        }
    }

    if (!$user) {
        auth_log('login_failed', ['user' => $key, 'ip' => $ip, 'code' => 'local_invalid']);
        login_register_failure($key, $ip);
        throw new ApiError($message, 401, 'login_failed');
    }

    login_register_success($key);
    $stamp = date('c');
    json_update(function (array $s) use ($user, $stamp) {
        $i = find_user_index_by_id($s, (string)$user['id']);
        if ($i !== null) $s['users'][$i]['last_login'] = $stamp;
        return $s;
    });
    begin_session_for($user);
    $public = public_user($user);
    audit($source === 'ldap' ? 'login_ldap' : 'login_local', $public);
    json_response(['ok' => true, 'user' => $public]);
}

function route_events_list(): never {
    $me = require_login();
    $today = date('Y-m-d');
    $fromRaw = clean_text($_GET['from'] ?? '', 10);
    $toRaw = clean_text($_GET['to'] ?? '', 10);
    if (!valid_date($fromRaw)) $fromRaw = date('Y-m-01');
    if (!valid_date($toRaw)) $toRaw = date('Y-m-t', strtotime('+1 month') ?: time());
    $from = new DateTimeImmutable($fromRaw . ' 00:00');
    $to = new DateTimeImmutable($toRaw . ' 23:59');
    if ($to < $from) $to = $from->modify('+1 day');
    if ($to > $from->modify('+400 days')) $to = $from->modify('+400 days'); // limite de segurança
    $events = [];
    foreach (json_read()['events'] as $event) {
        if (!event_visible_to($me, $event)) continue;
        foreach (event_occurrences($event, $from, $to) as $occ) $events[] = event_for_viewer($me, $occ);
    }
    usort($events, fn($a, $b) => strcmp($a['occurrence_start'], $b['occurrence_start']));
    $u = current_user();
    json_response(['ok' => true, 'today' => $today, 'events' => $events, 'can_edit' => ($u['profile'] ?? 'user') === 'admin']);
}

function route_event_create(): never {
    $u = require_login();
    require_post();
    $fields = parse_event_input(input_json());
    $event = ['id' => bin2hex(random_bytes(8))] + $fields + [
        'created_by' => $u['username'], 'created_by_name' => $u['name'],
        'created_at' => date('c'), 'updated_at' => date('c'),
    ];
    json_update(function (array $s) use ($event) { $s['events'][] = $event; return $s; });
    audit('event_created', $u, ['event_id' => $event['id'], 'title' => $event['title']]);
    try { queue_event_announcement($event); } catch (Throwable $e) { /* falha na fila nunca impede de salvar */ }
    json_response(['ok' => true, 'event' => $event], 201);
}

function route_event_update(): never {
    $u = require_login();
    require_post();
    $in = input_json();
    $id = clean_text($in['id'] ?? '', 100);
    if ($id === '') throw new ApiError('Evento inválido.', 422);
    $updated = null;
    $before = null;
    json_update(function (array $s) use ($in, $id, $u, &$updated, &$before) {
        foreach ($s['events'] as $i => $e) {
            if (($e['id'] ?? '') !== $id || !event_visible_to($u, $e)) continue;
            if (!can_edit_event($u, $e)) throw new ApiError('Você só pode alterar eventos criados por você.', 403);
            $before = $e;
            $merged = array_merge($e, parse_event_input($in, $e), ['updated_at' => date('c')]);
            if (($merged['notify_mode'] ?? '') === 'people' && !empty($merged['declined'])) {
                $keep = array_map('strtolower', (array)($merged['notify_users'] ?? []));
                $merged['declined'] = array_values(array_filter((array)$merged['declined'], fn($d) => in_array(strtolower((string)($d['username'] ?? '')), $keep, true)));
            }
            $s['events'][$i] = $merged;
            $updated = $merged;
            break;
        }
        return $s;
    });
    if (!$updated) throw new ApiError('Evento não encontrado.', 404);
    audit('event_updated', $u, ['event_id' => $id, 'title' => $updated['title']]);
    try { announce_change($before, $updated, $u); } catch (Throwable $e) { /* e-mail nunca impede de salvar */ }
    json_response(['ok' => true, 'event' => $updated]);
}

function route_event_decline(): never {
    $u = require_login();
    require_post();
    $id = clean_text(input_json()['id'] ?? '', 100);
    $target = null;
    json_update(function (array $s) use ($id, $u, &$target) {
        foreach ($s['events'] as $i => $e) {
            if (($e['id'] ?? '') !== $id || !event_visible_to($u, $e)) continue;
            $owner = strtolower((string)($e['created_by'] ?? ''));
            if ($owner === '' || $owner === strtolower((string)$u['username'])) throw new ApiError('Você criou este evento. Para tirá-lo da agenda, use Excluir.', 422);
            $dec = array_values((array)($e['declined'] ?? []));
            $dec[] = ['username' => $u['username'], 'name' => $u['name'] ?? $u['username'], 'at' => date('c')];
            $e['declined'] = $dec;
            $s['events'][$i] = $e;
            $target = $e;
            break;
        }
        return $s;
    });
    if (!$target) throw new ApiError('Evento não encontrado.', 404);
    audit('event_declined', $u, ['event_id' => $id, 'title' => $target['title'] ?? '']);
    try { announce_decline($target, $u); } catch (Throwable $e) { /* e-mail nunca impede de negar */ }
    json_response(['ok' => true]);
}

function route_event_delete(): never {
    $u = require_login();
    require_post();
    $id = clean_text(input_json()['id'] ?? '', 100);
    $deleted = null;
    json_update(function (array $s) use ($id, $u, &$deleted) {
        foreach ($s['events'] as $i => $e) {
            if (($e['id'] ?? '') === $id && event_visible_to($u, $e)) {
                if (!can_edit_event($u, $e)) throw new ApiError('Você só pode excluir eventos criados por você.', 403);
                $deleted = $e;
                array_splice($s['events'], $i, 1);
                break;
            }
        }
        return $s;
    });
    if (!$deleted) throw new ApiError('Evento não encontrado.', 404);
    audit('event_deleted', $u, ['event_id' => $id, 'title' => $deleted['title'] ?? '']);
    try { announce_cancel($deleted, $u); } catch (Throwable $e) { /* idem */ }
    json_response(['ok' => true]);
}

function route_settings_save(): never {
    $u = require_admin();
    require_post();
    $in = input_json() + json_read()['settings']; // o que não vier no corpo mantém o valor atual
    $theme = in_array($in['theme'], ['light', 'dark', 'midnight'], true) ? $in['theme'] : 'light';
    $name = clean_text($in['system_name'], 80);
    $settings = [
        'system_name' => $name !== '' ? $name : APP_NAME,
        'theme' => $theme,
        'accent' => normalize_color((string)$in['accent']),
        'first_day' => ((int)$in['first_day'] === 0 ? 0 : 1),
        'default_duration' => max(5, min(480, (int)$in['default_duration'])),
        'default_reminder' => max(0, min(10080, (int)$in['default_reminder'])),
        'time_start' => max(0, min(23, (int)$in['time_start'])),
        'time_end' => max(1, min(23, (int)$in['time_end'])),
        'notifications' => !empty($in['notifications']),
        'units' => clean_list($in['units']),
        'sectors' => clean_list($in['sectors']),
        'show_holidays' => !empty($in['show_holidays'] ?? true),
        'sectors_disabled' => clean_list($in['sectors_disabled'] ?? []),
        'sectors_deleted' => clean_list($in['sectors_deleted'] ?? [], 60, 300),
    ];
    if ($settings['time_end'] <= $settings['time_start']) $settings['time_end'] = min(23, $settings['time_start'] + 1);
    json_update(function (array $s) use ($settings) { $s['settings'] = $settings; return $s; });
    audit('settings_updated', $u);
    json_response(['ok' => true, 'settings' => $settings]);
}

function route_dashboard(): never {
    $me = require_login();
    $s = json_read();
    $s['events'] = array_values(array_filter($s['events'], fn($e) => event_visible_to($me, $e)));
    $today = date('Y-m-d');
    $nowStamp = date('Y-m-d H:i');
    $from = new DateTimeImmutable($today . ' 00:00');
    $to = $from->modify('+60 days');
    $todayEvents = [];
    $upcoming = [];
    foreach ($s['events'] as $e) {
        foreach (event_occurrences($e, $from, $to) as $o) {
            $o = event_for_viewer($me, $o);
            if (substr($o['occurrence_start'], 0, 10) === $today) $todayEvents[] = $o;
            if ($o['occurrence_start'] >= $nowStamp) $upcoming[] = $o;
        }
    }
    $byStart = fn($a, $b) => strcmp($a['occurrence_start'], $b['occurrence_start']);
    usort($todayEvents, $byStart);
    usort($upcoming, $byStart);
    json_response([
        'ok' => true, 'today' => $today, 'today_events' => $todayEvents,
        'upcoming' => array_slice($upcoming, 0, 8), 'total_events' => count($s['events']),
    ]);
}

function route_users_update(): never {
    $actor = require_admin();
    require_post();
    $in = input_json();
    $id = clean_text($in['id'] ?? '', 100);
    $profile = array_key_exists('profile', $in) ? (string)$in['profile'] : null;
    $active = array_key_exists('active', $in) ? (bool)$in['active'] : null;
    $sector = array_key_exists('sector', $in) ? clean_text($in['sector'], 60) : null;
    $coord = array_key_exists('coordinator', $in) ? (bool)$in['coordinator'] : null;
    $emailManual = array_key_exists('email_manual', $in) ? strtolower(trim(clean_text($in['email_manual'], 320))) : null;
    if ($emailManual !== null && $emailManual !== '' && !filter_var($emailManual, FILTER_VALIDATE_EMAIL)) throw new ApiError('E-mail inválido.', 422);
    if ($profile !== null && !in_array($profile, ['admin', 'user'], true)) throw new ApiError('Perfil inválido.', 422);
    if ($id === ($actor['id'] ?? '') && ($profile !== null || $active !== null || $sector !== null)) throw new ApiError('Você não pode alterar o seu próprio perfil ou status.', 400);

    $changes = [];
    $target = null;
    json_update(function (array $s) use ($id, $profile, $active, $sector, $emailManual, $coord, &$changes, &$target) {
        $i = find_user_index_by_id($s, $id);
        if ($i === null) throw new ApiError('Usuário não encontrado.', 404);
        $u = $s['users'][$i];
        if ($profile !== null && $profile !== ($u['profile'] ?? 'user')) {
            $u['profile'] = $profile;
            $u['profile_source'] = 'manual'; // daqui em diante o AD não muda mais este perfil
            $changes['profile'] = $profile;
        }
        if ($sector !== null && $sector !== (string)($u['sector'] ?? '')) {
            $u['sector'] = $sector === '' ? null : $sector;
            $u['sector_source'] = 'manual'; // o AD não sobrescreve mais o setor
            $changes['sector'] = $sector;
        }
        if ($active !== null && $active !== !empty($u['active'])) {
            $u['active'] = $active;
            $changes['active'] = $active;
        }
        if ($coord !== null && $coord !== !empty($u['coordinator'])) { // pasta "Coordenadores": a pessoa continua no seu setor
            if ($coord) $u['coordinator'] = true; else unset($u['coordinator']);
            $changes['coordinator'] = $coord;
        }
        if ($emailManual !== null && $emailManual !== (string)($u['email_manual'] ?? '')) {
            if ($emailManual === '') unset($u['email_manual']); else $u['email_manual'] = $emailManual;
            $changes['email_manual'] = $emailManual;
        }
        $u['updated_at'] = date('c');
        $s['users'][$i] = $u;
        $admins = 0;
        foreach ($s['users'] as $x) if (($x['profile'] ?? '') === 'admin' && !empty($x['active'])) $admins++;
        if ($admins < 1) throw new ApiError('É necessário manter ao menos um administrador ativo.', 400);
        $target = $u;
        return $s;
    });
    if ($changes) audit('user_updated', $actor, ['target' => $target['username'], 'changes' => $changes]);
    json_response(['ok' => true, 'user' => admin_user_view($target)]);
}

function route_users_create(): never {
    $actor = require_admin();
    require_post();
    $in = input_json();
    $name = clean_text($in['name'] ?? '', 200);
    $username = strtolower(clean_text($in['username'] ?? '', 120));
    if ($username !== '' && !str_contains($username, '@')) $username .= LOCAL_ACCOUNT_SUFFIX;
    $password = (string)($in['password'] ?? '');
    $profile = ($in['profile'] ?? 'user') === 'admin' ? 'admin' : 'user';
    $sector = clean_text($in['sector'] ?? '', 60);
    if ($name === '') throw new ApiError('Informe o nome.', 422);
    if (!is_local_account_name($username) || strlen($username) <= strlen(LOCAL_ACCOUNT_SUFFIX)) throw new ApiError('O usuário local deve terminar com ' . LOCAL_ACCOUNT_SUFFIX . '.', 422);
    validate_new_password($password);
    $new = null;
    json_update(function (array $s) use ($name, $username, $password, $profile, $sector, &$new) {
        if (find_user_index($s, $username) !== null) throw new ApiError('Já existe um usuário com este nome.', 409);
        $now = date('c');
        $new = [
            'id' => bin2hex(random_bytes(8)), 'username' => $username, 'name' => $name, 'email' => $username,
            'profile' => $profile, 'profile_source' => 'manual', 'active' => true, 'source' => 'local',
            'password_hash' => password_hash($password, PASSWORD_DEFAULT), 'must_change_password' => true,
            'ldap_groups' => [], 'sector' => $sector !== '' ? $sector : null, 'sector_source' => 'manual',
            'created_at' => $now, 'updated_at' => $now,
        ];
        $s['users'][] = $new;
        return $s;
    });
    audit('user_created', $actor, ['target' => $username, 'profile' => $profile]);
    json_response(['ok' => true, 'user' => admin_user_view($new)], 201);
}

/** Lista enxuta (sem e-mail) para escolher destinatários de lembrete; qualquer usuário logado pode ver. */
function route_users_directory(): never {
    $me = require_login();
    $seeCoord = ($me['profile'] ?? 'user') === 'admin' || !empty($me['coordinator']);
    $out = [];
    foreach (json_read()['users'] ?? [] as $u) {
        if (empty($u['active']) || !empty($u['ad_disabled'])) continue;
        $out[] = ['id' => $u['id'], 'username' => $u['username'], 'name' => $u['name'], 'sector' => $u['sector'] ?? null, 'has_mail' => user_mail($u) !== ''] + ($seeCoord ? ['coordinator' => !empty($u['coordinator'])] : []);
    }
    usort($out, fn($x, $y) => strcasecmp($x['name'], $y['name']));
    json_response(['ok' => true, 'users' => $out]);
}

/** Setores só da agenda: adicionar, ativar/desativar e excluir (nada é alterado no AD). */
function route_sectors_manage(): never {
    $actor = require_admin();
    require_post();
    $in = input_json();
    $action = (string)($in['action'] ?? '');
    $name = clean_text($in['name'] ?? '', 60);
    if (!in_array($action, ['add', 'toggle', 'delete'], true) || $name === '') throw new ApiError('Setor inválido.', 422);
    $without = fn(array $l) => array_values(array_filter($l, fn($x) => strcasecmp((string)$x, $name) !== 0));
    $has = fn(array $l) => count($l) !== count($without($l));
    $cleared = 0;
    json_update(function (array $s) use ($action, $name, $in, $without, $has, &$cleared) {
        $sectors = $s['settings']['sectors'] ?? [];
        $off = $s['settings']['sectors_disabled'] ?? [];
        $del = $s['settings']['sectors_deleted'] ?? [];
        if ($action === 'add') {
            if (!$has($sectors)) $sectors[] = $name;
            $del = $without($del); // cadastrar de novo libera o nome
        } elseif ($action === 'toggle') {
            $off = $without($off);
            if (empty($in['active'])) $off[] = $name;
            if (!$has($sectors)) $sectors[] = $name; // setor vindo do AD passa a ser gerenciado aqui
        } else {
            $sectors = $without($sectors);
            $off = $without($off);
            if (!$has($del)) $del[] = $name;
            foreach ($s['users'] as $i => $u) {
                if (strcasecmp((string)($u['sector'] ?? ''), $name) === 0) {
                    $s['users'][$i]['sector'] = null;
                    $s['users'][$i]['sector_source'] = 'manual';
                    $cleared++;
                }
            }
        }
        $s['settings']['sectors'] = $sectors;
        $s['settings']['sectors_disabled'] = $off;
        $s['settings']['sectors_deleted'] = $del;
        return $s;
    });
    audit('sector_' . $action, $actor, ['sector' => $name, 'users_cleared' => $cleared]);
    json_response(['ok' => true, 'settings' => json_read()['settings'], 'cleared' => $cleared]);
}

function route_backup_list(): never {
    require_admin();
    json_response(['ok' => true, 'backups' => array_slice(backup_list(), 0, 60)]);
}

function route_backup_create(): never {
    $u = require_admin();
    require_post();
    try { $name = backup_create('manual'); } catch (Throwable $e) { throw new ApiError($e->getMessage(), 500); }
    audit('backup_created', $u, ['name' => $name]);
    json_response(['ok' => true, 'name' => $name]);
}

function route_backup_download(): never {
    require_admin();
    $name = (string)($_GET['name'] ?? '');
    $file = backup_dir() . DIRECTORY_SEPARATOR . $name;
    if (!backup_valid_name($name) || !is_file($file)) throw new ApiError('Backup não encontrado.', 404);
    header('Content-Type: ' . (str_ends_with($name, '.html') ? 'text/html' : 'application/json') . '; charset=utf-8');
    header('Content-Disposition: ' . (isset($_GET['view']) ? 'inline' : 'attachment') . '; filename="' . $name . '"');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
}

function route_backup_delete(): never {
    $u = require_admin();
    require_post();
    $name = (string)(input_json()['name'] ?? '');
    try { backup_delete($name); } catch (Throwable $e) { throw new ApiError($e->getMessage(), 422); }
    audit('backup_deleted', $u, ['name' => $name]);
    json_response(['ok' => true]);
}

function route_backup_restore(): never {
    $u = require_admin();
    require_post();
    $in = input_json(64 * 1024 * 1024); // arquivo de backup inteiro (o limite padrão de 256 KB cortava backups reais)
    $name = (string)($in['name'] ?? '');
    try { backup_restore($name, isset($in['content']) ? (string)$in['content'] : null); } catch (Throwable $e) { throw new ApiError($e->getMessage(), 422); }
    audit('backup_restored', $u, ['name' => $name !== '' ? $name : 'arquivo enviado']);
    json_response(['ok' => true]);
}

function route_mail_test(): never {
    require_admin();
    require_post();
    $to = parse_emails(input_json()['to'] ?? '');
    if (!$to) throw new ApiError('Informe um e-mail válido para o teste.', 422);
    try {
        smtp_send([$to[0]], 'Teste da Cen Agenda', "Se você recebeu esta mensagem, os alertas por e-mail da Cen Agenda estão funcionando.\n\n— Cen Agenda");
    } catch (Throwable $e) {
        throw new ApiError($e->getMessage(), 502);
    }
    json_response(['ok' => true]);
}

function route_change_password(): never {
    $u = require_login(true);
    require_post();
    if (($u['source'] ?? '') !== 'local') throw new ApiError('A senha de contas do Active Directory é alterada pelo Windows/AD.', 400);
    $in = input_json();
    $current = (string)($in['current'] ?? '');
    $new = (string)($in['new'] ?? '');
    if ($new !== (string)($in['confirm'] ?? '')) throw new ApiError('A confirmação não confere com a nova senha.', 422);
    validate_new_password($new);
    if ($new === $current) throw new ApiError('A nova senha deve ser diferente da atual.', 422);
    json_update(function (array $s) use ($u, $current, $new) {
        $i = find_user_index_by_id($s, (string)$u['id']);
        if ($i === null) throw new ApiError('Usuário não encontrado.', 404);
        if (!password_verify($current, (string)($s['users'][$i]['password_hash'] ?? ''))) throw new ApiError('Senha atual incorreta.', 403);
        $s['users'][$i]['password_hash'] = password_hash($new, PASSWORD_DEFAULT);
        $s['users'][$i]['updated_at'] = date('c');
        unset($s['users'][$i]['must_change_password']);
        return $s;
    });
    session_regenerate_id(true);
    audit('password_changed', $u);
    json_response(['ok' => true]);
}

function handle_api_request(): never {
    send_security_headers();
    $route = trim((string)($_GET['route'] ?? ''));
    try {
        switch ($route) {
            case 'auth/status':
                $cfg = ldap_cfg();
                json_response([
                    'ok' => true,
                    'authenticated' => (bool)current_user(),
                    'user' => current_user(),
                    'csrf' => csrf_token(),
                    'ldap' => ['enabled' => (bool)$cfg['enabled'], 'php_extension' => ldap_extension_loaded()],
                ]);
            case 'auth/login':
                route_login();
            case 'auth/logout':
                require_post();
                $u = current_user();
                if ($u) audit('logout', $u);
                $_SESSION = [];
                session_destroy();
                json_response(['ok' => true]);
            case 'auth/change-password':
                route_change_password();

            case 'events/list': route_events_list();
            case 'events/create': route_event_create();
            case 'events/update': route_event_update();
            case 'events/delete': route_event_delete();
            case 'events/decline': route_event_decline();
            case 'dashboard': route_dashboard();

            case 'settings/get':
                $u = require_login();
                json_response(['ok' => true, 'settings' => json_read()['settings'], 'can_edit' => ($u['profile'] ?? 'user') === 'admin']);
            case 'settings/save': route_settings_save();

            case 'users/list':
                require_admin();
                $store = json_read();
                $users = array_map('admin_user_view', $store['users']);
                usort($users, fn($a, $b) => strcasecmp((string)$a['name'], (string)$b['name']));
                json_response(['ok' => true, 'users' => $users, 'sync' => $store['meta']['last_ldap_sync'] ?? null]);
            case 'users/update': route_users_update();
            case 'users/create': route_users_create();
            case 'mail/test': route_mail_test();
            case 'backup/list': route_backup_list();
            case 'backup/create': route_backup_create();
            case 'backup/download': route_backup_download();
            case 'backup/restore': route_backup_restore();
            case 'backup/delete': route_backup_delete();
            case 'sectors/manage': route_sectors_manage();
            case 'users/directory': route_users_directory();

            case 'ldap/status':
                require_admin();
                $cfg = ldap_cfg();
                json_response(['ok' => true, 'ldap' => [
                    'enabled' => (bool)$cfg['enabled'], 'php_extension' => ldap_extension_loaded(),
                    'server' => $cfg['server'], 'server_name' => $cfg['server_name'], 'domain' => $cfg['domain'],
                    'base_dn' => $cfg['base_dn'], 'port' => $cfg['port'], 'use_ssl' => (bool)$cfg['use_ssl'],
                    'bind_user' => $cfg['bind_user'], 'service_configured' => ldap_service_configured(),
                    'admin_groups' => $cfg['admin_groups'],
                    'last_sync' => json_read()['meta']['last_ldap_sync'] ?? null,
                ]]);
            case 'ldap/test':
                require_admin();
                json_response(ldap_diagnose());
            case 'ldap/sync':
                $u = require_admin();
                require_post();
                try {
                    $r = sync_ldap_users($u);
                } catch (ApiError $e) {
                    throw $e;
                } catch (RuntimeException $e) {
                    throw new ApiError($e->getMessage(), 502, 'ldap');
                }
                audit('ldap_sync', $u, $r);
                json_response(['ok' => true] + $r);

            default:
                json_response(['ok' => false, 'error' => 'Rota não encontrada.'], 404);
        }
    } catch (ApiError $e) {
        $payload = ['ok' => false, 'error' => $e->getMessage()];
        if ($e->errorCode !== '') $payload['code'] = $e->errorCode;
        json_response($payload, $e->status);
    } catch (Throwable $e) {
        log_error($e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
        json_response(['ok' => false, 'error' => 'Erro interno do servidor. Detalhes em logs/errors.log.'], 500);
    }
}
