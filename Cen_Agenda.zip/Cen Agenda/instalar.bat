@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>&1
title Cen Agenda - Instalador
cd /d "%~dp0"
color 0B
cls

echo ============================================================
echo                    CEN AGENDA
echo ============================================================
echo.

echo [1/6] Procurando PHP...
where php >nul 2>nul
if not errorlevel 1 goto PHP_FOUND

echo PHP nao foi encontrado no PATH.
where winget >nul 2>nul
if errorlevel 1 (
  echo.
  echo ERRO: winget nao esta disponivel.
  echo Instale PHP 8.2+ e execute este instalador novamente.
  pause
  exit /b 1
)

echo Tentando instalar PHP 8.4 pelo Windows Package Manager...
winget install -e --id PHP.PHP.8.4 --accept-package-agreements --accept-source-agreements
where php >nul 2>nul
if errorlevel 1 (
  echo.
  echo O PHP foi instalado, mas ainda nao esta no PATH desta janela.
  echo Feche e abra o Prompt de Comando e execute instalar.bat novamente.
  pause
  exit /b 1
)

:PHP_FOUND
for /f "delims=" %%V in ('php -r "echo PHP_VERSION;"') do set "PHPVER=%%V"
echo PHP detectado: %PHPVER%
php -r "if(version_compare(PHP_VERSION,'8.2.0','<')){fwrite(STDERR,'PHP 8.2+ e necessario.'.PHP_EOL);exit(2);}"
if errorlevel 1 (
  echo ERRO: sua versao do PHP e antiga.
  pause
  exit /b 1
)

echo.
echo [2/6] Habilitando a extensao LDAP do PHP...
php tools\habilitar_ldap.php
if errorlevel 1 (
  echo.
  echo AVISO: a extensao LDAP nao ficou ativa. A Cen Agenda abre, mas o login pelo
  echo Active Directory so funciona depois de resolver isto. Rode instalar.bat de novo depois de resolver.
)

echo.
echo [3/6] Preparando arquivos...
if not exist data mkdir data
if not exist logs mkdir logs
if not exist .env if exist .env.example copy /Y .env.example .env >nul
schtasks /Delete /TN "Cen Agenda Lembretes" /F >nul 2>&1
schtasks /Delete /TN "Cen Agenda Backup" /F >nul 2>&1
php tools\init.php
set "INITCODE=%ERRORLEVEL%"
if "%INITCODE%"=="0" goto STEP4
if "%INITCODE%"=="10" goto STEP4
echo ERRO ao preparar a Cen Agenda.
pause
exit /b 1

:STEP4
echo.
echo [4/6] Firewall: liberando a porta 5080...
netsh advfirewall firewall add rule name="Cen Agenda 5080" dir=in action=allow protocol=TCP localport=5080 >nul 2>&1
if errorlevel 1 echo AVISO: nao foi possivel criar a regra de firewall automaticamente (execute como administrador).

echo.
echo [5/6] Conta local de emergencia
if "%INITCODE%"=="10" goto ASKNEW
echo Ja existe uma conta local de emergencia.
set "RESETADM="
set /p RESETADM=Redefinir a senha dela agora? (S/N): 
if /I "%RESETADM%"=="S" call :MKADMIN
goto STEP6
:ASKNEW
set "MKADMIN="
set /p MKADMIN=Criar agora a conta local de emergencia? (S/N): 
if /I "%MKADMIN%"=="S" call :MKADMIN

:STEP6
echo.
echo [6/6] Concluido.
echo.
echo ============================================================
echo INSTALACAO CONCLUIDA
echo ============================================================
echo.
echo Proximo passo: abra o arquivo .env e preencha as senhas (AD e e-mail).
echo.
set "TESTLDAP="
set /p TESTLDAP=Testar agora a conexao com o Active Directory? (S/N): 
if /I "%TESTLDAP%"=="S" php testar_ldap.php
echo.
echo Para abrir o sistema: iniciar.bat
echo.
pause
endlocal
exit /b 0

:MKADMIN
echo.
echo === CONTA LOCAL DE EMERGENCIA ===
echo Use apenas se o Active Directory estiver fora do ar. O usuario termina com @cenagenda.local
echo (ex.: admin = admin@cenagenda.local). Minimo de 8 caracteres na senha.
powershell -NoProfile -ExecutionPolicy Bypass -File "tools\com_senha.ps1" -Script "tools\criar_admin.php" -UserPrompt "Usuario local" -UserDefault "admin" -Confirm
exit /b 0
