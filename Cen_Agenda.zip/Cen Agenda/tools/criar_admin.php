<?php
declare(strict_types=1);
// Cria ou redefine a conta local de emergência (equivalente à conta "val" da Intranet).
// Dados vêm de variáveis de ambiente definidas por tools/com_senha.ps1 — a senha nunca fica em arquivo.
require_once __DIR__ . '/../backend.php';

$user = strtolower(trim((string)getenv('CEN_INPUT_USER')));
$pass = (string)getenv('CEN_INPUT_PASS');
$pass2 = (string)getenv('CEN_INPUT_PASS2');

if ($user === '') $user = 'admin';
if (!str_contains($user, '@')) $user .= LOCAL_ACCOUNT_SUFFIX;
if ($pass === '' || $pass !== $pass2) {
    fwrite(STDERR, "ERRO: senha vazia ou a confirmação não confere.\n");
    exit(1);
}

try {
    ensure_storage();
    run_migrations();
    $r = create_or_reset_local_admin($user, 'Administrador Local', $pass);
    echo ($r['created'] ? "Conta criada" : "Senha redefinida") . ": {$r['username']}\n";
    echo "Entre na Cen Agenda digitando exatamente esse usuário (conta local, não passa pelo AD).\n";
    exit(0);
} catch (Throwable $e) {
    fwrite(STDERR, 'ERRO: ' . $e->getMessage() . "\n");
    exit(1);
}
