<?php
declare(strict_types=1);
// Habilita a extensão LDAP do PHP no Windows (php_ldap.dll).
// Causa mais comum do erro "A extensão LDAP do PHP não está habilitada": o PHP instalado pelo winget
// vem sem php.ini, então nada era carregado.

if (extension_loaded('ldap')) {
    echo "LDAP: a extensão já está ativa. Nada a fazer.\n";
    exit(0);
}
if (stripos(PHP_OS_FAMILY, 'Windows') === false) {
    echo "Neste sistema instale o pacote do PHP com LDAP (ex.: sudo apt install php-ldap) e reinicie.\n";
    exit(2);
}

$phpDir = dirname(PHP_BINARY);
$extDir = $phpDir . DIRECTORY_SEPARATOR . 'ext';
$dll = $extDir . DIRECTORY_SEPARATOR . 'php_ldap.dll';
if (!is_file($dll)) {
    echo "ERRO: php_ldap.dll não encontrado em $extDir\n";
    echo "Instale o PHP completo (zip \"Thread Safe\"/NTS de windows.php.net) ou reinstale pelo winget.\n";
    exit(4);
}

$ini = php_ini_loaded_file();
if ($ini === false || $ini === '') {
    $target = $phpDir . DIRECTORY_SEPARATOR . 'php.ini';
    $template = null;
    foreach (['php.ini-development', 'php.ini-production'] as $t) {
        if (is_file($phpDir . DIRECTORY_SEPARATOR . $t)) { $template = $phpDir . DIRECTORY_SEPARATOR . $t; break; }
    }
    if ($template === null) { echo "ERRO: não há php.ini nem modelo (php.ini-development) em $phpDir\n"; exit(3); }
    if (!is_file($target) && !@copy($template, $target)) { echo "ERRO: sem permissão para criar $target (execute como administrador).\n"; exit(3); }
    $ini = $target;
    echo "php.ini criado a partir de " . basename($template) . ".\n";
}

$text = (string)@file_get_contents($ini);
if ($text === '') { echo "ERRO: não foi possível ler $ini\n"; exit(3); }
$original = $text;

// extension_dir absoluto (o valor relativo "ext" nem sempre é resolvido pelo caminho do php.exe)
$line = 'extension_dir = "' . $extDir . '"';
if (preg_match('/^[ \t]*extension_dir[ \t]*=[ \t]*"?([^"\r\n;]*)"?/mi', $text, $m)) {
    $current = trim($m[1]);
    if (!preg_match('/^[A-Za-z]:[\\\\\/]/', $current)) {
        $text = preg_replace_callback('/^[ \t]*extension_dir[ \t]*=[^\r\n]*/mi', fn() => $line, $text, 1) ?? $text;
    }
} else {
    $count = 0;
    $text = preg_replace_callback('/^[ \t]*;[ \t]*extension_dir[ \t]*=[ \t]*"ext"[ \t]*\r?$/mi', function () use ($line) { return $line; }, $text, 1, $count) ?? $text;
    if ($count === 0) $text = rtrim($text) . PHP_EOL . $line . PHP_EOL;
}

// extension=ldap
if (!preg_match('/^[ \t]*extension[ \t]*=[ \t]*(?:php_)?ldap(?:\.dll)?[ \t]*\r?$/mi', $text)) {
    $count = 0;
    $text = preg_replace('/^[ \t]*;[ \t]*(extension[ \t]*=[ \t]*(?:php_)?ldap(?:\.dll)?)[ \t]*\r?$/mi', '$1', $text, 1, $count) ?? $text;
    if ($count === 0) $text = rtrim($text) . PHP_EOL . 'extension=ldap' . PHP_EOL;
}

if ($text !== $original) {
    @copy($ini, $ini . '.bak-cenagenda');
    if (@file_put_contents($ini, $text) === false) { echo "ERRO: sem permissão para gravar $ini (execute como administrador).\n"; exit(3); }
    echo "php.ini atualizado: $ini\n";
}

// Confere em um novo processo (o atual já carregou a configuração antiga).
$out = [];
@exec('"' . PHP_BINARY . '" -m 2>&1', $out);
$mods = array_map(fn($l) => strtolower(trim((string)$l)), $out);
if (in_array('ldap', $mods, true)) {
    echo "OK: extensão LDAP habilitada. Reinicie a Cen Agenda (iniciar.bat).\n";
    exit(0);
}
echo "A extensão ainda não carregou. Mensagens do PHP:\n";
foreach ($out as $l) if (stripos((string)$l, 'warning') !== false || stripos((string)$l, 'ldap') !== false) echo "  " . trim((string)$l) . "\n";
echo "Se citar DLL ausente (libsasl/libssl), instale o Microsoft Visual C++ Redistributable x64 e tente de novo.\n";
exit(5);
