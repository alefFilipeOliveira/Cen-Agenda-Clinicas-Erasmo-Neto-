<?php
declare(strict_types=1);
// Tarefa interna da Cen Agenda: envia lembretes por e-mail e faz o backup diário.
// Iniciada pelo iniciar.bat na mesma janela do servidor (não abre janelas extras).
require_once __DIR__ . '/../backend.php';

ensure_storage();
set_time_limit(0);
$last = '';
$lastReminder = 0;
$log = function (string $m) use (&$last) { if ($m !== $last) echo date('c') . ' ' . $m . "\n"; $last = $m; };
echo date('c') . " tarefa interna iniciada (lembretes e backup)\n";
while (true) {
    try { if ($b = backup_if_due()) echo date('c') . " backup: {$b}\n"; } catch (Throwable $e) { $log('backup ERRO ' . $e->getMessage()); }
    try {
        $q = process_queued_announcements();
        if ($q['sent']) echo date('c') . ' avisos imediatos enviados: ' . $q['sent'] . "\n";
        foreach ($q['errors'] as $er) $log('e-mail imediato ERRO ' . $er);
    } catch (Throwable $e) { $log('fila de e-mails ERRO ' . $e->getMessage()); }
    try {
        if (mail_configured() && time() - $lastReminder >= 60) {
            $lastReminder = time();
            $r = send_due_reminders();
            if ($r['sent']) echo date('c') . ' lembretes enviados: ' . $r['sent'] . "\n";
            foreach ($r['errors'] as $er) $log('lembrete ERRO ' . $er);
        }
    } catch (Throwable $e) { $log('lembretes ERRO ' . $e->getMessage()); }
    sleep(2);
}
