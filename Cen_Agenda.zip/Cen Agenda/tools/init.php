<?php
declare(strict_types=1);
require_once __DIR__ . '/../backend.php';

ensure_storage();
run_migrations();

$cfg = ldap_cfg();
echo "Cen Agenda " . APP_VERSION . " preparada.\n";
echo "Fuso horário : " . date_default_timezone_get() . "\n";
echo "LDAP         : " . ($cfg['enabled'] ? 'ativado' : 'desativado');
if ($cfg['enabled']) {
    echo ' (' . $cfg['server'] . ', ' . $cfg['domain'] . ')';
    if (!ldap_extension_loaded()) echo "\n  AVISO: extensão LDAP do PHP não habilitada. Execute instalar.bat.";
    elseif (!ldap_service_configured()) echo "\n  AVISO: senha da conta de serviço ausente no .env (login funciona, sincronização não).";
}
echo "\n";

// Código 10 = ainda não existe conta local de emergência (os .bat oferecem criar_admin).
if (count_active_local_admins() === 0) {
    echo "Conta local de emergência: NÃO configurada.\n";
    exit(10);
}
echo "Conta local de emergência: configurada.\n";
exit(0);
