# Pede usuário/senha de forma segura (senha oculta) e executa um script PHP com os dados
# em variáveis de ambiente apenas deste processo. Nada é gravado em arquivo.
param(
    [Parameter(Mandatory = $true)][string]$Script,
    [string]$UserPrompt = 'Usuario',
    [string]$UserDefault = '',
    [switch]$Confirm
)
$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)

function Read-Secret([string]$Prompt) {
    $secure = Read-Host -Prompt $Prompt -AsSecureString
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

$label = $UserPrompt
if ($UserDefault -ne '') { $label = "$UserPrompt [$UserDefault]" }
$u = Read-Host -Prompt $label
if ([string]::IsNullOrWhiteSpace($u)) { $u = $UserDefault }
$p = Read-Secret 'Senha'
$p2 = ''
if ($Confirm) { $p2 = Read-Secret 'Confirme a senha' }

$env:CEN_INPUT_USER = $u
$env:CEN_INPUT_PASS = $p
$env:CEN_INPUT_PASS2 = $p2
& php $Script
exit $LASTEXITCODE
