<?php
declare(strict_types=1);
// Diagnóstico LDAP da Cen Agenda (chamado pelo instalar.bat).
// Se CEN_INPUT_USER/CEN_INPUT_PASS estiverem definidos (via tools/com_senha.ps1), também testa o login do usuário.
require_once __DIR__ . '/backend.php';

$cfg = ldap_cfg();
echo "=============================================\n";
echo "       CEN AGENDA | DIAGNOSTICO LDAP\n";
echo "=============================================\n\n";
echo "Servidor : {$cfg['server']} ({$cfg['server_name']})\n";
echo "Dominio  : {$cfg['domain']}  (NetBIOS {$cfg['netbios']})\n";
echo "Base DN  : {$cfg['base_dn']}\n";
echo "Porta    : {$cfg['port']}   SSL: " . ($cfg['use_ssl'] ? 'sim' : 'nao') . "\n";
echo "Servico  : {$cfg['bind_user']} (senha " . (ldap_service_configured() ? 'configurada' : 'AUSENTE') . ")\n";
echo "Admins   : " . implode('; ', $cfg['admin_groups']) . "\n\n";

$diag = ldap_diagnose();
foreach ($diag['checks'] as $c) {
    echo ($c['ok'] ? '[OK]   ' : '[ERRO] ') . $c['label'] . ($c['detail'] !== '' ? '  ->  ' . $c['detail'] : '') . "\n";
}
echo "\nRESULTADO DA CONEXAO: " . ($diag['ok'] ? 'LDAP OK' : 'LDAP FALHOU') . " - {$diag['message']}\n";

$user = (string)getenv('CEN_INPUT_USER');
$pass = (string)getenv('CEN_INPUT_PASS');
if ($user !== '') {
    echo "\n--- Teste de login do usuario ---\n";
    $r = ldap_authenticate($user, $pass);
    echo "RESULTADO: " . ($r['ok'] ? 'LOGIN OK' : 'LOGIN FALHOU') . "\n";
    if ($r['ok']) {
        echo "Usuario : {$r['username']}\n";
        echo "Nome    : {$r['name']}\n";
        echo "E-mail  : " . ($r['email'] !== '' ? $r['email'] : '-') . "\n";
        echo "Setor   : " . ($r['sector'] ?? '-') . "\n";
        echo "Perfil  : " . (!empty($r['is_admin_group']) ? 'Administrador (grupo do AD)' : 'Usuario') . "\n";
        echo "Grupos  : " . ($r['groups'] ? implode(', ', $r['groups']) : ($r['groups_known'] ? '(nenhum)' : '(sem permissao de leitura no diretorio)')) . "\n";
    } else {
        echo "Codigo  : {$r['code']}\n";
        echo "Detalhe : {$r['error']}\n";
    }
}
exit($diag['ok'] ? 0 : 1);
