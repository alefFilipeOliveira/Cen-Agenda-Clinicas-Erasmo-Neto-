@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>&1
title Cen Agenda
cd /d "%~dp0"
set "OCULTO="
if /I "%~1"=="oculto" set "OCULTO=1"
color 0B
cls

set "PORT=5080"
where php >nul 2>nul
if errorlevel 1 (
  echo.
  echo [CEN AGENDA] PHP nao foi encontrado.
  echo Execute instalar.bat primeiro.
  if not defined OCULTO pause
  exit /b 1
)
if not exist logs mkdir logs

rem Remove tarefas antigas do Agendador do Windows (eram elas que faziam janelas piscarem).
schtasks /Delete /TN "Cen Agenda Lembretes" /F >nul 2>&1
schtasks /Delete /TN "Cen Agenda Backup" /F >nul 2>&1

php tools\init.php >nul
set "INITCODE=%ERRORLEVEL%"
if "%INITCODE%"=="0" goto INIT_OK
if "%INITCODE%"=="10" goto INIT_OK
echo.
echo ERRO ao preparar os dados. Rode instalar.bat.
if not defined OCULTO pause
exit /b 1

:INIT_OK
netstat -ano | findstr ":%PORT%" | findstr "LISTENING" >nul 2>&1
if not errorlevel 1 (
  start "" "http://127.0.0.1:%PORT%"
  exit /b 0
)

echo ============================================================
echo                       CEN AGENDA
echo ============================================================
echo.
echo  Endereco : http://127.0.0.1:%PORT%   (na rede: http://IP_DESTE_PC:%PORT%)
echo  Tarefas  : lembretes por e-mail e backup diario ativos
echo  Registros: pasta logs
echo.
if "%INITCODE%"=="10" echo  AVISO: nao ha conta local de emergencia. Rode instalar.bat.
echo.
echo  Deixe esta janela aberta enquanto o sistema estiver em uso.
echo  Para encerrar a Cen Agenda, feche esta janela.
echo ============================================================

rem Tudo roda nesta mesma janela (sem abrir outras).
start "" /B php -S 0.0.0.0:%PORT% -t public >nul 2>> logs\servidor.log
start "" /B php tools\worker.php >> logs\tarefas.log 2>&1
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:%PORT%"

:ESPERA
timeout /t 3600 /nobreak >nul
goto ESPERA
