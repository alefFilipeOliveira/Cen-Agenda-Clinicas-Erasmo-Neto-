<?php
declare(strict_types=1);
/**
 * Backups em HTML visual: o arquivo mostra eventos, usuários e setores de forma legível
 * (abre no navegador, dá para imprimir) e carrega, escondidos, os dados para restaurar.
 * Automático (diário), manual e de segurança antes de restaurar. Retenção: 30 dias.
 */

function backup_dir(): string {
    $d = dirname(DATA_FILE) . DIRECTORY_SEPARATOR . 'backups';
    if (!is_dir($d)) @mkdir($d, 0775, true);
    return $d;
}

function backup_valid_name(string $n): bool {
    return (bool)preg_match('/^cen_agenda_\d{8}_\d{6}(_[a-z]+)?\.(html|json)$/', $n);
}

function backup_html(array $store): string {
    $h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $day = function ($s) { try { return (new DateTimeImmutable((string)$s))->format('d/m/Y'); } catch (Throwable) { return (string)$s; } };
    $hour = function ($s) { try { return (new DateTimeImmutable((string)$s))->format('H:i'); } catch (Throwable) { return ''; } };
    $names = [];
    foreach ($store['users'] ?? [] as $u) $names[$u['username'] ?? ''] = $u['name'] ?? ($u['username'] ?? '');
    $rec = ['none' => 'Não repete', 'daily' => 'Todo dia', 'weekly' => 'Toda semana', 'monthly' => 'Todo mês', 'yearly' => 'Todo ano'];

    $events = $store['events'] ?? [];
    usort($events, fn($a, $b) => strcmp((string)($a['start'] ?? ''), (string)($b['start'] ?? '')));
    $rows = '';
    foreach ($events as $e) {
        $r = $e['recurrence']['type'] ?? 'none';
        $rows .= '<tr><td><b>' . $h($e['title'] ?? '') . '</b></td><td>' . $h($day($e['start'] ?? '')) . '</td><td>' . $h($hour($e['start'] ?? '') . ' – ' . $hour($e['end'] ?? ''))
            . '</td><td>' . $h($e['location'] ?? '—') . '</td><td>' . $h($rec[$r] ?? $r) . '</td><td>' . $h($names[$e['created_by'] ?? ''] ?? ($e['created_by'] ?? '—')) . '</td></tr>';
    }
    $groups = [];
    foreach ($store['users'] ?? [] as $u) $groups[($u['sector'] ?? '') !== '' ? $u['sector'] : 'Sem setor'][] = $u;
    ksort($groups);
    $folders = '';
    foreach ($groups as $sector => $list) {
        $folders .= '<h3>📁 ' . $h($sector) . ' <span>' . count($list) . '</span></h3><table><tr><th>Nome</th><th>Usuário</th><th>E-mail dos avisos</th><th>Perfil</th><th>Origem</th><th>Situação</th></tr>';
        foreach ($list as $u) {
            $folders .= '<tr><td><b>' . $h($u['name'] ?? '') . '</b></td><td>' . $h($u['username'] ?? '') . '</td><td>' . $h(function_exists('user_mail') ? (user_mail($u) ?: '—') : ($u['email'] ?? '—')) . '</td><td>' . (($u['profile'] ?? '') === 'admin' ? 'Administrador' : 'Usuário')
                . '</td><td>' . (($u['source'] ?? '') === 'ldap' ? 'Active Directory' : 'Local') . '</td><td>' . (!empty($u['active']) ? 'Ativo' : 'Inativo') . '</td></tr>';
        }
        $folders .= '</table>';
    }
    $units = implode(', ', array_map($h, $store['settings']['units'] ?? []));
    $data = base64_encode((string)json_encode($store, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    $when = date('d/m/Y \à\s H:i');
    return '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Backup Cen Agenda - ' . $h(date('d/m/Y H:i')) . '</title><style>'
        . 'body{font-family:Segoe UI,Arial,sans-serif;background:#f4f7fb;color:#152033;margin:0;padding:32px}.w{max-width:1000px;margin:auto}'
        . 'header{background:linear-gradient(135deg,#3156d8,#233b9e);color:#fff;border-radius:20px;padding:28px}header h1{margin:0 0 6px;font-size:26px}header p{margin:0;opacity:.85}'
        . '.cards{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0}.c{flex:1;min-width:140px;background:#fff;border:1px solid #e3e8f0;border-radius:16px;padding:16px}.c b{display:block;font-size:28px}.c small{color:#6b778c}'
        . 'section{background:#fff;border:1px solid #e3e8f0;border-radius:16px;padding:20px;margin-bottom:16px;overflow-x:auto}h2{margin:0 0 12px}h3{margin:18px 0 8px}h3 span{background:#e8edff;color:#3156d8;border-radius:99px;padding:2px 9px;font-size:12px}'
        . 'table{width:100%;border-collapse:collapse;font-size:13px}th,td{text-align:left;padding:9px 10px;border-bottom:1px solid #e3e8f0}th{font-size:11px;text-transform:uppercase;color:#6b778c}'
        . '.n{background:#fff8e6;border:1px solid #f3dd9b;border-radius:12px;padding:12px 14px;font-size:13px;line-height:1.5}@media print{body{padding:0;background:#fff}header{color:#000;background:#fff;border:1px solid #ccc}}'
        . '</style></head><body><div class="w"><header><h1>Backup da Cen Agenda</h1><p>Gerado em ' . $h($when) . ' · versão ' . $h(APP_VERSION) . '</p></header>'
        . '<div class="cards"><div class="c"><b>' . count($events) . '</b><small>eventos</small></div><div class="c"><b>' . count($store['users'] ?? []) . '</b><small>usuários</small></div><div class="c"><b>' . count($groups) . '</b><small>setores</small></div></div>'
        . '<section><h2>Eventos</h2>' . ($rows !== '' ? '<table><tr><th>Evento</th><th>Data</th><th>Horário</th><th>Unidade</th><th>Repetição</th><th>Criado por</th></tr>' . $rows . '</table>' : '<p>Nenhum evento cadastrado.</p>') . '</section>'
        . '<section><h2>Pessoas e setores</h2>' . $folders . '<p><b>Unidades:</b> ' . ($units !== '' ? $units : '—') . '</p></section>'
        . '<div class="n"><b>Como restaurar:</b> na Cen Agenda, abra <b>Configurações › Backups</b> e escolha este backup na lista, ou clique em <b>Restaurar de um arquivo</b> e selecione este arquivo.<br>'
        . '<b>Guarde com cuidado:</b> este arquivo contém os dados de todos os usuários da agenda.</div>'
        . '<script type="application/octet-stream" id="cen-data">' . $data . '</script></div></body></html>';
}

function backup_create(string $tag = ''): string {
    $name = 'cen_agenda_' . date('Ymd_His') . ($tag !== '' ? '_' . $tag : '') . '.html';
    if (file_put_contents(backup_dir() . DIRECTORY_SEPARATOR . $name, backup_html(json_read()), LOCK_EX) === false) {
        throw new RuntimeException('Não foi possível gravar o backup (verifique a permissão da pasta data/backups).');
    }
    backup_prune();
    return $name;
}

/** Remove backups com mais de 30 dias, mantendo sempre os 5 mais recentes. */
function backup_prune(int $days = 30, int $keep = 5): void {
    foreach (array_slice(backup_list(), $keep) as $b) {
        if ($b['mtime'] < time() - $days * 86400) @unlink(backup_dir() . DIRECTORY_SEPARATOR . $b['name']);
    }
}

function backup_list(): array {
    $out = [];
    foreach (glob(backup_dir() . DIRECTORY_SEPARATOR . 'cen_agenda_*.*') ?: [] as $f) {
        if (!backup_valid_name(basename($f))) continue;
        $out[] = ['name' => basename($f), 'size' => (int)filesize($f), 'mtime' => (int)filemtime($f), 'created' => date('c', (int)filemtime($f))];
    }
    usort($out, fn($a, $b) => $b['mtime'] <=> $a['mtime']);
    return $out;
}

/** Cria o backup automático se o último AUTOMÁTICO tiver mais de $hours horas (backups manuais não adiam o diário). */
function backup_if_due(int $hours = 20): ?string {
    foreach (backup_list() as $b) {
        if (!preg_match('/_auto\.(html|json)$/', $b['name'])) continue;
        if ($b['mtime'] > time() - $hours * 3600) return null;
        break;
    }
    return backup_create('auto');
}

/** Lê um backup (.html novo ou .json antigo) e devolve os dados, validando a estrutura. */
function backup_parse(string $raw): array {
    $raw = ltrim($raw, "\xEF\xBB\xBF \t\r\n");
    if ($raw !== '' && $raw[0] !== '{') {
        $p = strpos($raw, 'id="cen-data"');
        $s = $p === false ? false : strpos($raw, '>', $p);
        $e = $s === false ? false : strpos($raw, '</script>', $s);
        if ($e === false) throw new RuntimeException('Este arquivo não é um backup da Cen Agenda.');
        $raw = (string)base64_decode(preg_replace('/\s+/', '', substr($raw, $s + 1, $e - $s - 1)), true);
    }
    $data = json_decode($raw, true);
    if (!is_array($data) || !is_array($data['users'] ?? null) || !is_array($data['events'] ?? null) || !is_array($data['settings'] ?? null)) {
        throw new RuntimeException('Arquivo de backup inválido ou corrompido.');
    }
    return normalize_store($data);
}

/** Apaga um backup da lista (só arquivos com nome de backup válido dentro de data/backups). */
function backup_delete(string $name): void {
    $file = backup_dir() . DIRECTORY_SEPARATOR . $name;
    if (!backup_valid_name($name) || !is_file($file)) throw new RuntimeException('Backup não encontrado.');
    if (!@unlink($file)) throw new RuntimeException('Não foi possível apagar o backup (verifique a permissão da pasta data/backups).');
}

function backup_restore(string $name, ?string $content = null): void {
    if ($content === null) {
        $file = backup_dir() . DIRECTORY_SEPARATOR . $name;
        if (!backup_valid_name($name) || !is_file($file)) throw new RuntimeException('Backup não encontrado.');
        $content = (string)file_get_contents($file);
    }
    $data = backup_parse($content);
    backup_create('antes'); // segurança: guarda o estado atual antes de substituir
    json_update(fn(array $cur) => $data);
}
