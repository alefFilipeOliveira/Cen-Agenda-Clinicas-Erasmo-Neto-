<?php
declare(strict_types=1);

const APP_NAME = 'Cen Agenda';
const APP_VERSION = '2.15.1';
const STORE_VERSION = 3;
const DATA_FILE = __DIR__ . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . 'cen_agenda.json';
const LOG_DIR = __DIR__ . DIRECTORY_SEPARATOR . 'logs';
const SESSION_NAME = 'cen_agenda_session';
const SESSION_IDLE_SECONDS = 8 * 3600;      // expira após 8h sem uso
const SESSION_ABSOLUTE_SECONDS = 14 * 3600; // e no máximo 14h após o login
const DEFAULT_PORT = 5080;

function app_env(string $key, string $default = ''): string {
    $v = getenv($key);
    if ($v === false) return $default;
    return trim((string)$v);
}

function env_bool(string $value, bool $default = false): bool {
    $v = strtolower(trim($value));
    if ($v === '') return $default;
    return in_array($v, ['1', 'true', 'sim', 'yes', 'on', 's'], true);
}

function load_local_env(): void {
    static $loaded = false;
    if ($loaded) return;
    $loaded = true;
    $path = __DIR__ . DIRECTORY_SEPARATOR . '.env';
    if (!is_file($path)) return;
    $lines = @file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!$lines) return;
    foreach ($lines as $i => $line) {
        // O Bloco de Notas do Windows costuma salvar com BOM; sem isto a 1ª variável é ignorada.
        if ($i === 0) $line = preg_replace('/^\xEF\xBB\xBF/', '', $line) ?? $line;
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
        [$key, $value] = explode('=', $line, 2);
        $key = trim($key);
        $value = trim(trim($value), "\"'");
        if ($key !== '' && getenv($key) === false) {
            putenv($key . '=' . $value);
            $_ENV[$key] = $value;
        }
    }
}
load_local_env();

// Horários dos eventos são "relógio de parede". Sem fuso configurado o PHP usa UTC e o
// "Hoje"/"Próximos" viram o dia 3h antes (em Salvador). Padrão: America/Bahia.
$__tz = app_env('CEN_AGENDA_TIMEZONE', 'America/Bahia');
if (!@date_default_timezone_set($__tz)) date_default_timezone_set('America/Bahia');
unset($__tz);

function app_secret(): string {
    $env = app_env('CEN_AGENDA_SECRET_KEY', '');
    if ($env !== '') return $env;
    $path = __DIR__ . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . '.secret';
    if (is_file($path)) {
        $s = trim((string)@file_get_contents($path));
        if ($s !== '') return $s;
    }
    $s = bin2hex(random_bytes(32));
    if (!is_dir(dirname($path))) @mkdir(dirname($path), 0775, true);
    @file_put_contents($path, $s, LOCK_EX);
    return $s;
}

function default_store(): array {
    return [
        'meta' => ['version' => STORE_VERSION, 'created_at' => date('c')],
        'settings' => [
            'system_name' => APP_NAME,
            'theme' => 'light',
            'accent' => '#3156d8',
            'first_day' => 1,
            'default_duration' => 60,
            'default_reminder' => 15,
            'time_start' => 7,
            'time_end' => 20,
            'notifications' => true,
            'units' => ['ERASMO', 'NACEN', 'NACEN+'],
            'sectors' => [],
            'sectors_disabled' => [],
            'show_holidays' => true,
            'sectors_deleted' => [], // removidos aqui: a sincronização do AD não recria
        ],
        'users' => [],
        'events' => [],
        'audit' => [],
    ];
}

function normalize_store(array $data): array {
    $base = default_store();
    foreach ($base as $key => $value) {
        if (!array_key_exists($key, $data)) $data[$key] = $value;
    }
    if (!is_array($data['meta'])) $data['meta'] = $base['meta'];
    if (!is_array($data['users'])) $data['users'] = [];
    if (!is_array($data['events'])) $data['events'] = [];
    if (!is_array($data['audit'])) $data['audit'] = [];
    if (!is_array($data['settings'])) $data['settings'] = $base['settings'];
    foreach ($base['settings'] as $k => $v) {
        if (!array_key_exists($k, $data['settings'])) $data['settings'][$k] = $v;
    }
    return $data;
}

function ensure_storage(): void {
    if (!is_dir(dirname(DATA_FILE))) @mkdir(dirname(DATA_FILE), 0775, true);
    if (!is_dir(LOG_DIR)) @mkdir(LOG_DIR, 0775, true);
    if (!is_file(DATA_FILE) || filesize(DATA_FILE) === 0) {
        $store = default_store();
        file_put_contents(DATA_FILE, json_encode($store, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
    }
}

function json_read(): array {
    ensure_storage();
    $fp = @fopen(DATA_FILE, 'rb');
    if (!$fp) return default_store();
    if (!@flock($fp, LOCK_SH)) { fclose($fp); return default_store(); }
    $raw = stream_get_contents($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    $data = json_decode((string)$raw, true);
    if (!is_array($data)) {
        log_error('cen_agenda.json ilegível; restaure data/cen_agenda.json.bak se necessário.');
        return default_store();
    }
    return normalize_store($data);
}

/**
 * Lê, altera e grava o armazenamento sob bloqueio exclusivo.
 * Se o arquivo existir mas estiver corrompido, NÃO sobrescreve (evita perder todos os dados).
 */
function json_update(callable $mutator): array {
    ensure_storage();
    $fp = @fopen(DATA_FILE, 'c+');
    if (!$fp) throw new RuntimeException('Não foi possível abrir o armazenamento da Cen Agenda.');
    try {
        if (!@flock($fp, LOCK_EX)) throw new RuntimeException('Não foi possível bloquear o armazenamento.');
        rewind($fp);
        $raw = (string)stream_get_contents($fp);
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            if (trim($raw) !== '') {
                throw new RuntimeException('O arquivo de dados está corrompido. Restaure data/cen_agenda.json.bak.');
            }
            $data = default_store();
        } else {
            // Cópia de segurança rolante (no máximo 1 a cada 5 minutos).
            $bak = DATA_FILE . '.bak';
            if (!is_file($bak) || (time() - (int)@filemtime($bak)) > 300) @file_put_contents($bak, $raw, LOCK_EX);
        }
        $data = normalize_store($data);
        $result = $mutator($data);
        if (!is_array($result)) $result = $data;
        $encoded = json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($encoded === false) throw new RuntimeException('Falha ao serializar os dados.');
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, $encoded);
        fflush($fp);
        return $result;
    } finally {
        @flock($fp, LOCK_UN);
        fclose($fp);
    }
}

function log_error(string $message): void {
    if (!is_dir(LOG_DIR)) @mkdir(LOG_DIR, 0775, true);
    @file_put_contents(LOG_DIR . DIRECTORY_SEPARATOR . 'errors.log', '[' . date('c') . '] ' . $message . PHP_EOL, FILE_APPEND | LOCK_EX);
}

function audit(string $action, ?array $user = null, array $extra = []): void {
    json_update(function (array $s) use ($action, $user, $extra) {
        $s['audit'][] = [
            'id' => bin2hex(random_bytes(8)),
            'action' => $action,
            'user' => $user['username'] ?? 'system',
            'name' => $user['name'] ?? 'Sistema',
            'at' => date('c'),
            'extra' => $extra,
        ];
        if (count($s['audit']) > 1000) $s['audit'] = array_slice($s['audit'], -1000);
        return $s;
    });
}
